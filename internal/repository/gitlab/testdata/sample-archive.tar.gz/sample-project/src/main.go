package main

import "fmt"

func main() {
	fmt.Println("Hello from test project!")
}