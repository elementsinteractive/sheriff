plugins {
    id("podwalks.android.feature")
    id("dagger.hilt.android.plugin")
    id("kotlin-parcelize")
}

android {

    namespace = "nl.elements.podwalks.details"
}

dependencies {
    implementation(libs.bundles.mavericks)
    implementation(libs.bundles.navigationFragment)
    implementation(libs.bundles.compose)

    implementation(libs.mobilization.loggingApi)

    debugImplementation("androidx.compose.ui:ui-tooling:1.2.0-rc03")
    implementation("androidx.compose.ui:ui-tooling-preview:1.2.0-rc03")

    implementation(libs.dagger.hilt.compose)
    implementation(libs.dagger.hilt.base)
    ksp(libs.dagger.hilt.compiler)
}
