package nl.elements.podwalks.details.mapper

import nl.elements.podwalks.details.Constants
import nl.elements.podwalks.details.DetailsViewState.Tour
import nl.elements.podwalks.details.compose.download.DownloadButtonState.DownloadPodwalk
import nl.elements.podwalks.details.compose.download.DownloadButtonState.DownloadingPodwalk
import nl.elements.podwalks.details.compose.download.DownloadButtonState.RemovePodwalk
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.podwalk.Checkpoint
import nl.elements.podwalks.domain.podwalk.DownloadState
import nl.elements.podwalks.domain.podwalk.Podwalk
import nl.elements.podwalks.domain.podwalk.StatusBarColor
import nl.elements.podwalks.domain.podwalk.downloaded
import nl.elements.podwalks.domain.podwalk.progress

fun Tour.toDownloadButtonState() = when (val downloadState = downloadState) {
    Tour.DownloadState.Downloaded -> RemovePodwalk
    is Tour.DownloadState.Downloading -> DownloadingPodwalk(downloadState.progress)
    Tour.DownloadState.NotDownloaded -> DownloadPodwalk
}

fun combineToViewModel(
    podwalk: Podwalk,
    downloadState: DownloadState,
    isDownloading: Boolean,
    checkpoints: List<Checkpoint>,
    startLocation: Coordinate,
) =
    Tour(
        name = podwalk.name.value,
        description = podwalk.description.value,
        images = podwalk.images.map {
            Tour.Image(
                it.statusBarColor == StatusBarColor.LIGHT,
                imageUrl = it.url.value,
            )
        },
        duration = podwalk.length.duration,
        lengthInKm = podwalk.length.distance.value.toDouble() / Constants.KM_MULTIPLIER,
        downloadState = when {
            downloadState.downloaded -> Tour.DownloadState.Downloaded
            isDownloading -> Tour.DownloadState.Downloading(downloadState.progress)
            else -> Tour.DownloadState.NotDownloaded
        },
        tags = podwalk.tags.map { it.value },
        startLocation = Tour.StartLocation(
            coordinate = startLocation.latitude.value to startLocation.longitude.value,
            address = podwalk.startAddress.value,
        ),
        firstChapter = checkpoints.first().let { startChapter ->
            Tour.Chapter(
                index = startChapter.index.value,
                latitude = startChapter.coordinates.latitude.value,
                longitude = startChapter.coordinates.longitude.value,
                triggerRadiusInMeters = startChapter.triggerRadius.value,
            )
        },
        chapterPreviews = checkpoints
            .take(Constants.PREVIEW_COUNT)
            .map {
                Tour.PreviewChapter(
                    index = it.index.value,
                    title = it.name.value,
                    audioFileUrl = it.track.url.value,
                )
            },
    )
