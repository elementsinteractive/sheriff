package nl.elements.podwalks.details.compose.location

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.details.DetailsViewState
import nl.elements.podwalks.presentation.compose.location.StartLocationWindow
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.theme.onSurfaceHighlight
import nl.elements.podwalks.presentation.compose.theme.surfaceHighlight
import nl.elements.podwalks.sdk.ui.components.maps.chapter.Chapter
import nl.elements.podwalks.sdk.ui.components.walk.location.StartLocationCard
import nl.elements.podwalks.shared.resources.R

@Composable
fun StartLocationSection(
    modifier: Modifier = Modifier,
    tour: DetailsViewState.Tour,
    onStartLocationClick: () -> Unit,
) {
    StartLocationSection(
        modifier = modifier,
        chapter = tour.firstChapter,
        startLocationAddress = tour.startLocation.address,
        onStartLocationClick = onStartLocationClick,
    )
}

@Composable
fun StartLocationSection(
    modifier: Modifier = Modifier,
    chapter: DetailsViewState.Tour.Chapter,
    startLocationAddress: String,
    onStartLocationClick: () -> Unit,
) {
    Column(modifier) {
        Text(
            text = stringResource(id = R.string.home_start_location_section_heading),
            style = MaterialTheme.typography.subtitle2,
        )

        Spacer(modifier = Modifier.height(16.dp))

        StartLocationWindow(
            modifier = Modifier.fillMaxWidth(),
            chapter = Chapter(
                index = chapter.index,
                latitude = chapter.latitude,
                longitude = chapter.longitude,
                triggerRadiusInMeters = chapter.triggerRadiusInMeters,
            ),
        )

        Spacer(modifier = Modifier.height(16.dp))

        StartLocationCard(
            modifier = Modifier.fillMaxWidth(),
            address = startLocationAddress,
            onClick = onStartLocationClick,
            backgroundColor = MaterialTheme.colors.surfaceHighlight,
            contentColor = MaterialTheme.colors.onSurfaceHighlight,
        )
    }
}

@Preview(widthDp = 380)
@Composable
fun StartLocationSectionPreview() {
    AppTheme {
        StartLocationSection(
            chapter = DetailsViewState.Tour.Chapter(
                index = 0,
                latitude = 0.0,
                longitude = 0.0,
                triggerRadiusInMeters = 10,
            ),
            startLocationAddress = "Stationplein, 1012 AB Amsterdam",
        ) {}
    }
}
