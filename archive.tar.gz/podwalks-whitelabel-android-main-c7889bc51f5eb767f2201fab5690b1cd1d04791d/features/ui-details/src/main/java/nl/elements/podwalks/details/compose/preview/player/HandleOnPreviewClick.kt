package nl.elements.podwalks.details.compose.preview.player

import nl.elements.podwalks.details.compose.preview.PodwalkAudioPreview

fun handleOnPreviewClick(
    previewPlayer: PreviewPlayer,
    previews: List<PodwalkAudioPreview>,
    clickedPreviewIndex: Int,
) {
    val state = previewPlayer.state.value

    if (state == null) {
        previewPlayer.playClickedPreview(clickedPreviewIndex, previews)
    } else {
        with(previewPlayer) {
            when (state) {
                PreviewPlayer.State.Idle ->
                    playClickedPreview(clickedPreviewIndex, previews)
                is PreviewPlayer.State.Loading -> Unit
                is PreviewPlayer.State.PlayingPreview ->
                    togglePlaybackOrPlayOtherPreview(
                        state = state,
                        clickedPreviewIndex = clickedPreviewIndex,
                        previews = previews,
                    )
            }
        }
    }
}

private fun PreviewPlayer.togglePlaybackOrPlayOtherPreview(
    state: PreviewPlayer.State.PlayingPreview,
    clickedPreviewIndex: Int,
    previews: List<PodwalkAudioPreview>,
) {
    if (isPlayingClickedPreview(state, clickedPreviewIndex)) {
        togglePlayback()
    } else {
        playClickedPreview(clickedPreviewIndex, previews)
    }
}

private fun isPlayingClickedPreview(
    state: PreviewPlayer.State.PlayingPreview,
    clickedPreviewIndex: Int,
) = state.chapterIndex == clickedPreviewIndex

private fun PreviewPlayer.playClickedPreview(
    clickedPreviewIndex: Int,
    previews: List<PodwalkAudioPreview>,
) {
    play(
        chapterIndex = clickedPreviewIndex,
        url = getClickedPreviewUrl(previews, clickedPreviewIndex),
    )
}

private fun getClickedPreviewUrl(
    previews: List<PodwalkAudioPreview>,
    clickedPreview: Int,
): String = previews.first { it.index == clickedPreview }.audioTrackUrl
