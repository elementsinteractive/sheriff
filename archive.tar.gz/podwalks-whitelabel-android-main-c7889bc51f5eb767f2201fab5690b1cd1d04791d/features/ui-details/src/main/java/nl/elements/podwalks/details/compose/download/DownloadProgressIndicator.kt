package nl.elements.podwalks.details.compose.download

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
@Suppress("MagicNumber")
fun DownloadProgressIndicator(
    modifier: Modifier = Modifier,
    progress: Float,
    color: Color,
) {
    val animatedProgress = remember { Animatable(0f) }

    LaunchedEffect(progress) {
        animatedProgress.animateTo(progress)
    }

    Box(modifier = modifier.size(22.dp)) {
        Canvas(modifier = Modifier.fillMaxSize(), onDraw = {
            val rect = Rect(
                topLeft = Offset.Zero,
                bottomRight = Offset(size.width, size.height),
            )

            val path = Path().apply {
                if (animatedProgress.value == 1f) {
                    addOval(rect)
                } else {
                    arcTo(
                        rect = rect,
                        startAngleDegrees = -90f,
                        sweepAngleDegrees = 360f * animatedProgress.value,
                        forceMoveTo = false,
                    )
                }
            }

            drawPath(path = path, color = color, style = Stroke(width = 2f))
        })
    }
}
