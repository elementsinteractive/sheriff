package nl.elements.podwalks.details.compose.preview

data class SelectedAudioPreview(
    val index: Int,
    val isPlaying: Boolean,
)

data class PodwalkAudioPreview(
    val index: Int,
    val chapterTitle: String,
    val audioTrackUrl: String,
)
