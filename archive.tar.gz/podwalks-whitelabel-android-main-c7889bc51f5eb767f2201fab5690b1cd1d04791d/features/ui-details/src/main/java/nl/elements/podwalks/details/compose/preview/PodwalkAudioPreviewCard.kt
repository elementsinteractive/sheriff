package nl.elements.podwalks.details.compose.preview

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.Card
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.Icon
import androidx.compose.material.LocalContentColor
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.onSurfaceHighlight
import nl.elements.podwalks.presentation.compose.theme.surfaceHighlight
import nl.elements.podwalks.sdk.ui.theme.PodwalkTheme
import nl.elements.podwalks.shared.resources.R

@Composable
private fun backgroundColorForSelected(isSelected: Boolean) =
    if (isSelected) MaterialTheme.colors.surfaceHighlight else MaterialTheme.colors.surface

@Composable
private fun contentColorForSelected(isSelected: Boolean) =
    if (isSelected) MaterialTheme.colors.onSurfaceHighlight else MaterialTheme.colors.onSurface

private fun isPreviewSelected(
    preview: PodwalkAudioPreview,
    selectedPreview: SelectedAudioPreview?,
) = preview.index == selectedPreview?.index

private fun isPreviewPlaying(
    isSelected: Boolean,
    selectedPreview: SelectedAudioPreview?,
) = isSelected && selectedPreview?.isPlaying ?: false

private fun isNotLastPreview(
    index: Int,
    previews: List<PodwalkAudioPreview>,
) = index != previews.size - 1

@Composable
fun AudioPreviewCards(
    modifier: Modifier = Modifier,
    previews: List<PodwalkAudioPreview>,
    selectedPreview: SelectedAudioPreview?,
    onPreviewClick: (Int) -> Unit,
) {
    Column(modifier) {
        previews.forEachIndexed { index, preview ->

            val isSelected = isPreviewSelected(preview, selectedPreview)
            val isPlaying = isPreviewPlaying(isSelected, selectedPreview)

            PodwalkAudioPreviewCard(
                preview = preview,
                isSelected = isSelected,
                isPlaying = isPlaying,
                onPreviewClick = onPreviewClick,
            )

            if (isNotLastPreview(index, previews)) {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
@OptIn(ExperimentalMaterialApi::class)
fun PodwalkAudioPreviewCard(
    modifier: Modifier = Modifier,
    preview: PodwalkAudioPreview,
    isSelected: Boolean,
    isPlaying: Boolean,
    onPreviewClick: (Int) -> Unit,
) {
    Card(
        modifier = modifier,
        onClick = { onPreviewClick(preview.index) },
        backgroundColor = backgroundColorForSelected(isSelected),
        shape = PodwalkTheme.shapes.card,
    ) {
        CompositionLocalProvider(LocalContentColor provides contentColorForSelected(isSelected)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PreviewChapterPin(
                    chapterIndex = preview.index,
                    isPlaying = isSelected,
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    modifier = Modifier.weight(1f),
                    text = preview.chapterTitle,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    style = MaterialTheme.typography.body1,
                )

                Spacer(modifier = Modifier.width(8.dp))

                AnimatedVisibility(visible = isSelected) {
                    val painter = painterResource(id = R.drawable.ic_equalizer)
                    Icon(painter = painter, contentDescription = null)
                }

                Spacer(modifier = Modifier.width(8.dp))

                val playIconPainter =
                    painterResource(id = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)

                Icon(painter = playIconPainter, contentDescription = null)
            }
        }
    }
}
