@file:Suppress("MatchingDeclarationName")

package nl.elements.podwalks.details.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import kotlinx.serialization.Serializable
import nl.elements.podwalks.details.compose.DetailsScreen

@Serializable
data class WalkDetails(
    val podwalkId: String,
)

fun NavController.navigateToDetails(
    podwalkId: String,
    navOptions: NavOptions? = null,
) = navigate(
    route = WalkDetails(podwalkId),
    navOptions = navOptions,
)

fun NavGraphBuilder.detailsScreen(
    onBackClick: () -> Unit,
    onAboutClick: (podwalkId: String) -> Unit,
    onPodwalkStartClick: (podwalkId: String) -> Unit,
) {
    composable<WalkDetails> { backStackEntry ->
        val details: WalkDetails = backStackEntry.toRoute()

        DetailsScreen(
            podwalkId = details.podwalkId,
            onBackClick = onBackClick,
            onAboutClick = onAboutClick,
            onPodwalkStartClick = {
                onPodwalkStartClick(details.podwalkId)
            },
        )
    }
}
