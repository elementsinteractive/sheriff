package nl.elements.podwalks.details

internal object Constants {
    const val KM_MULTIPLIER = 1000
    const val PREVIEW_COUNT = 3
}
