package nl.elements.podwalks.details.compose.start

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.sdk.ui.theme.PodwalkTheme
import nl.elements.podwalks.shared.resources.R

@Composable
fun StartPodwalkCard(
    modifier: Modifier = Modifier,
    isEnabled: Boolean = true,
    onStartPodwalkClick: () -> Unit,
) {
    Card(
        modifier = modifier,
        backgroundColor = MaterialTheme.colors.background,
        shape = PodwalkTheme.shapes.startPodwalkCard,
    ) {
        Box(
            modifier = Modifier
                .padding(16.dp)
                .navigationBarsPadding(),
        ) {
            PrimaryButton(
                modifier = Modifier.fillMaxWidth(),
                isEnabled = isEnabled,
                onClick = onStartPodwalkClick,
            ) {
                Text(
                    text = stringResource(R.string.details_button_start_podwalk),
                )
            }
        }
    }
}
