package nl.elements.podwalks.details.compose.download

sealed interface DownloadButtonState {
    object DownloadPodwalk : DownloadButtonState
    data class DownloadingPodwalk(val progress: Float) : DownloadButtonState
    object RemovePodwalk : DownloadButtonState
}
