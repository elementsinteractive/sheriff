package nl.elements.podwalks.details.compose.header

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun CarouselImagePageIndicator(
    modifier: Modifier = Modifier,
    selectedPageColor: Color,
    unselectedPageColor: Color,
    pages: Int,
    currentPage: Int,
) {
    val indicatorShape = CircleShape

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        repeat(pages) { i ->

            val isLastPage = i == pages - 1
            val isSelected = currentPage == i
            val targetColor = if (isSelected) selectedPageColor else unselectedPageColor
            val indicatorColor by animateColorAsState(targetColor)

            Box(
                Modifier
                    .background(indicatorColor, indicatorShape)
                    .size(8.dp),
            )

            if (!isLastPage) {
                Spacer(modifier = Modifier.width(10.dp))
            }
        }
    }
}
