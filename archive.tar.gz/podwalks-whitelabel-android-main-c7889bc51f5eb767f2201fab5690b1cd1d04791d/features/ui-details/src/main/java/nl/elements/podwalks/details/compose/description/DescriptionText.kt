package nl.elements.podwalks.details.compose.description

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.shared.resources.R

@Composable
fun DescriptionText(
    modifier: Modifier = Modifier,
    tourDescription: String,
) {
    Column(modifier) {
        Text(
            text = stringResource(id = R.string.home_description_section_heading),
            style = MaterialTheme.typography.subtitle2,
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = tourDescription,
            style = MaterialTheme.typography.body1,
        )
    }
}
