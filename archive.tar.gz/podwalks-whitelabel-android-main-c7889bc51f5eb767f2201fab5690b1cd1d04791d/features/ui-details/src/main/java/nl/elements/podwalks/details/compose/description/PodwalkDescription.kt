package nl.elements.podwalks.details.compose.description

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.details.DetailsViewState

@Composable
fun PodwalkDescription(
    modifier: Modifier = Modifier,
    tour: DetailsViewState.Tour,
) {
    Column(modifier = modifier) {
        DescriptionText(tourDescription = tour.description)

        Spacer(modifier = Modifier.height(16.dp))

        PodwalkTags(
            modifier = Modifier.fillMaxWidth(),
            tags = tour.tags,
        )
    }
}
