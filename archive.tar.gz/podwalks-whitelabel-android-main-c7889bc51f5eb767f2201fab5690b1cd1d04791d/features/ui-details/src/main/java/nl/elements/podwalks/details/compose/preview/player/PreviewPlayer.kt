package nl.elements.podwalks.details.compose.preview.player

import android.media.AudioAttributes
import android.media.MediaPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PreviewPlayer(
    private val coroutineScope: CoroutineScope,
) {

    private val _state = MutableStateFlow<State?>(null)
    val state: StateFlow<State?> = _state

    private val mediaPlayer: MediaPlayer by lazy {
        MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build(),
            )
        }
    }

    init {
        mediaPlayer.setOnCompletionListener {
            _state.value = State.Idle
        }
    }

    fun play(chapterIndex: Int, url: String) {
        if (state.value is State.Loading) return

        coroutineScope.launch(Dispatchers.IO) {
            // Reset the media player in case it is already prepared
            mediaPlayer.reset()

            // Prepare the player with (new) URL
            _state.value = State.Loading(chapterIndex)
            mediaPlayer.setDataSource(url)
            mediaPlayer.prepare()

            // Once prepared, start playing
            mediaPlayer.start()
            _state.value = State.PlayingPreview(
                chapterIndex = chapterIndex,
                isPlaying = mediaPlayer.isPlaying,
            )
        }
    }

    fun togglePlayback() {
        if (mediaPlayer.isPlaying) {
            mediaPlayer.pause()
        } else {
            mediaPlayer.start()
        }

        val stateValue = _state.value
        if (stateValue is State.PlayingPreview) {
            _state.value = stateValue.copy(isPlaying = mediaPlayer.isPlaying)
        }
    }

    fun close() {
        mediaPlayer.stop()
    }

    sealed interface State {

        object Idle : State

        data class Loading(val chapterIndex: Int) : State

        data class PlayingPreview(
            val chapterIndex: Int,
            val isPlaying: Boolean,
        ) : State
    }
}
