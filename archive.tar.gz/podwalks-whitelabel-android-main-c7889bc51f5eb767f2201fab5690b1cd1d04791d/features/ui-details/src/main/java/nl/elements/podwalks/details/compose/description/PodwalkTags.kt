package nl.elements.podwalks.details.compose.description

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.LocalContentColor
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.onSurfaceHighlight
import nl.elements.podwalks.presentation.compose.theme.surfaceHighlight

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PodwalkTags(
    modifier: Modifier = Modifier,
    tags: List<String>,
) {
    val tagSpacing = 8.dp

    FlowRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(tagSpacing),
        verticalArrangement = Arrangement.spacedBy(tagSpacing),
    ) {
        tags.forEach { PodwalkTag(Modifier, it) }
    }
}

@Composable
@Suppress("MagicNumber")
fun PodwalkTag(
    modifier: Modifier = Modifier,
    name: String,
) {
    Box(
        modifier = modifier
            .background(MaterialTheme.colors.surfaceHighlight, shape = RoundedCornerShape(100))
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        CompositionLocalProvider(
            LocalContentColor provides MaterialTheme.colors.onSurfaceHighlight,
        ) {
            Text(
                text = name,
                style = MaterialTheme.typography.caption,
            )
        }
    }
}
