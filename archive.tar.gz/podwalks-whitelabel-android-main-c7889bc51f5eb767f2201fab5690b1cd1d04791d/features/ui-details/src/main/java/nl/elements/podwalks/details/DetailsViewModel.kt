package nl.elements.podwalks.details

import com.airbnb.mvrx.MavericksViewModel
import com.airbnb.mvrx.MavericksViewModelFactory
import com.airbnb.mvrx.hilt.AssistedViewModelFactory
import com.airbnb.mvrx.hilt.hiltMavericksViewModelFactory
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.details.DetailsViewState.Tour.DownloadState.Downloaded
import nl.elements.podwalks.details.DetailsViewState.Tour.DownloadState.Downloading
import nl.elements.podwalks.details.DetailsViewState.Tour.DownloadState.NotDownloaded
import nl.elements.podwalks.details.mapper.combineToViewModel
import nl.elements.podwalks.domain.Name
import nl.elements.podwalks.domain.podwalk.DeleteProgress
import nl.elements.podwalks.domain.podwalk.GetCheckpoints
import nl.elements.podwalks.domain.podwalk.GetDownloadState
import nl.elements.podwalks.domain.podwalk.GetPodwalkById
import nl.elements.podwalks.domain.podwalk.GetWaypoints
import nl.elements.podwalks.domain.podwalk.Id
import nl.elements.podwalks.domain.storage.PodwalkFileRemover
import nl.elements.podwalks.domain.tasks.PodwalkTasks

class DetailsViewModel @AssistedInject constructor(
    @Assisted initialState: DetailsViewState,
    getCheckpoints: GetCheckpoints,
    getWaypoints: GetWaypoints,
    getDownloadState: GetDownloadState,
    private val getPodwalkById: GetPodwalkById,
    private val logger: Logger,
    private val podwalkFileRemover: PodwalkFileRemover,
    private val podwalkTasks: PodwalkTasks,
    private val deleteProgress: DeleteProgress,
) : MavericksViewModel<DetailsViewState>(initialState) {
    private val podwalkId = initialState.podwalkId

    private val podwalkDeleteExceptionHandler = CoroutineExceptionHandler { _, throwable ->
        logger.e(throwable, "Failed to delete podwalk files.")
    }

    private val podwalk =
        combine(
            getPodwalkById.get(Id(podwalkId)).filterNotNull(),
            getCheckpoints.get(Id(podwalkId)),
            getWaypoints.get(Id(podwalkId)),
            getDownloadState.get(Id(podwalkId)),
            stateFlow.map { it.isDownloading },
        ) { podwalk, checkpoints, waypoints, downloadState, downloading ->
            combineToViewModel(
                podwalk = podwalk,
                checkpoints = checkpoints,
                downloadState = downloadState,
                isDownloading = downloading,
                startLocation = waypoints.first(),
            )
        }

    fun setup() {
        viewModelScope.launch {
            podwalk.collectLatest { setState { copy(tour = it) } }
        }

        viewModelScope.launch {
            podwalkTasks.isDownloadingPodwalk(Id(podwalkId))
                .collectLatest {
                    setState { copy(isDownloading = it) }
                }
        }
    }

    fun downloadPodwalk() = withState { state ->

        if (state.tour == null) return@withState

        when (state.tour.downloadState) {
            Downloaded -> setState { copy(confirmDeletePodwalk = true) }
            is Downloading -> Unit
            NotDownloaded -> podwalkTasks.downloadPodwalk(Id(podwalkId), Name(state.tour.name))
        }
    }

    fun resetConfirmDeletePodwalk() {
        setState { copy(confirmDeletePodwalk = false) }
    }

    fun deletePodwalk() {
        resetConfirmDeletePodwalk()
        viewModelScope.launch(podwalkDeleteExceptionHandler) {
            getPodwalkById.get(Id(podwalkId)).first()
                ?.let { podwalk -> podwalkFileRemover.delete(podwalk) }

            deleteProgress.delete(Id(podwalkId))
        }
    }

    fun showDownloadDialog() = setState { copy(isDownloadDialogShown = true) }

    fun dismissDownloadDialog() = setState {
        copy(isDownloadDialogShown = false)
    }

    @AssistedFactory
    interface Factory : AssistedViewModelFactory<DetailsViewModel, DetailsViewState> {
        override fun create(state: DetailsViewState): DetailsViewModel
    }

    companion object : MavericksViewModelFactory<DetailsViewModel, DetailsViewState> by hiltMavericksViewModelFactory()
}
