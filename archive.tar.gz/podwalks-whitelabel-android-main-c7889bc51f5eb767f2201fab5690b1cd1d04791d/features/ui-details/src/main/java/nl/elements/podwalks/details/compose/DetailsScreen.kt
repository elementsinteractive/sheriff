@file:Suppress("LongMethod")

package nl.elements.podwalks.details.compose

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalOverscrollConfiguration
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.airbnb.mvrx.compose.collectAsState
import com.airbnb.mvrx.compose.mavericksViewModel
import nl.elements.podwalks.details.DetailsArguments
import nl.elements.podwalks.details.DetailsViewModel
import nl.elements.podwalks.details.DetailsViewState
import nl.elements.podwalks.details.DetailsViewState.Tour.DownloadState
import nl.elements.podwalks.details.compose.dialog.ConfirmDeletePodwalkDialog
import nl.elements.podwalks.details.compose.dialog.DownloadPodwalkDialog
import nl.elements.podwalks.details.compose.header.DetailsHeader
import nl.elements.podwalks.details.compose.start.StartPodwalkCard
import nl.elements.podwalks.details.compose.tooling.previewDetailsViewState
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.intent.startGoogleMapsIntent

@Composable
fun DetailsScreen(
    modifier: Modifier = Modifier,
    podwalkId: String,
    onBackClick: () -> Unit,
    onAboutClick: (podwalkId: String) -> Unit,
    onPodwalkStartClick: () -> Unit,
    viewModel: DetailsViewModel = mavericksViewModel(
        argsFactory = {
            DetailsArguments(podwalkId)
        },
    ),
) {
    val state by viewModel.collectAsState()
    val isDownloaded = state.tour?.downloadState is DownloadState.Downloaded
    val context = LocalContext.current

    LaunchedEffect(key1 = null) {
        viewModel.setup()
    }

    DetailsScreen(
        modifier = modifier,
        state = state,
        onPodwalkDownloadClick = viewModel::downloadPodwalk,
        onBackClick = onBackClick,
        onHelpClick = {
            onAboutClick(podwalkId)
        },
        onStartLocationClick = {
            state.tour?.startLocation?.let { podwalk ->

                val (lat, lng) = podwalk.coordinate
                val address = podwalk.address

                startGoogleMapsIntent(context, lat, lng, address)
            }
        },
        onStartPodwalkClick = {
            if (isDownloaded) {
                onPodwalkStartClick()
            } else {
                viewModel.showDownloadDialog()
            }
        },
        onDownloadDialogClick = {
            viewModel.dismissDownloadDialog()
            viewModel.downloadPodwalk()
        },
        onDismissDialogClick = viewModel::dismissDownloadDialog,
    )

    ConfirmDeletePodwalkDialog(
        isVisible = state.confirmDeletePodwalk,
        onConfirmClicked = viewModel::deletePodwalk,
        onDismissClicked = viewModel::resetConfirmDeletePodwalk,
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DetailsScreen(
    modifier: Modifier = Modifier,
    state: DetailsViewState,
    onPodwalkDownloadClick: () -> Unit,
    onBackClick: () -> Unit,
    onHelpClick: () -> Unit,
    onStartLocationClick: () -> Unit,
    onStartPodwalkClick: () -> Unit,
    onDismissDialogClick: () -> Unit,
    onDownloadDialogClick: () -> Unit,
) {
    CompositionLocalProvider(
        LocalOverscrollConfiguration provides null,
    ) {
        Box(modifier = modifier.fillMaxSize()) {
            if (state.isDownloadDialogShown) {
                DownloadPodwalkDialog(
                    onDismissClicked = onDismissDialogClick,
                    onDownloadClicked = onDownloadDialogClick,
                )
            }

            var startPodwalkCardSize by remember { mutableStateOf(IntSize.Zero) }

            Surface(
                modifier = Modifier
                    .verticalScroll(rememberScrollState()),
                color = MaterialTheme.colors.background,
            ) {
                Column(Modifier.fillMaxWidth()) {
                    DetailsHeader(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f, false)
                            .height(369.dp),
                        carouselImages = state.tour?.images ?: emptyList(),
                        onBackClick = onBackClick,
                        onHelpClick = onHelpClick,
                    )

                    Spacer(modifier = Modifier.height(22.dp))

                    if (state.tour != null) {
                        DetailsScreenBody(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            tour = state.tour,
                            onPodwalkDownloadClick = onPodwalkDownloadClick,
                            onStartLocationClick = onStartLocationClick,
                        )
                    }

                    Spacer(
                        Modifier
                            .height(
                                LocalDensity.current.run {
                                    startPodwalkCardSize.height.toDp()
                                },
                            ),
                    )
                }
            }

            StartPodwalkCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .onSizeChanged {
                        // This card floats over the body of the page and covers the bottom content on this screen.
                        // To account for this, onSizeChanged collects size changes of the start Podwalk card
                        // that houses the start-Podwalk-button. When the size changes this callback telegraphs the new
                        // size through a MutableState which in turn is used for the bottom Spacer above.
                        //
                        // Please note that there's a potential performance impact with this approach seeing as
                        // Compose has to render the screen twice: once without the card size known and for a second
                        // time with the value known.
                        startPodwalkCardSize = it
                    },
                onStartPodwalkClick = onStartPodwalkClick,
                isEnabled = !state.isDownloading,
            )
        }
    }
}

@Preview
@Composable
@Suppress("MagicNumber")
fun DetailsScreenPreview() {
    AppTheme {
        var state by remember {
            mutableStateOf(previewDetailsViewState)
        }

        DetailsScreen(
            modifier = Modifier.fillMaxWidth(),
            state = state,
            onPodwalkDownloadClick = {
                val currentState = state
                state = currentState.copy(
                    tour = currentState.tour?.copy(
                        downloadState = when (currentState.tour.downloadState) {
                            DownloadState.Downloaded -> DownloadState.NotDownloaded
                            is DownloadState.Downloading -> DownloadState.Downloaded
                            DownloadState.NotDownloaded -> DownloadState.Downloading(66.0f)
                        },
                    ),
                )
            },
            onBackClick = {},
            onHelpClick = {},
            onStartLocationClick = {},
            onStartPodwalkClick = {},
            onDismissDialogClick = {},
            onDownloadDialogClick = {},
        )
    }
}
