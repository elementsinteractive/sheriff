package nl.elements.podwalks.details.compose.preview.player

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner

@Composable
fun rememberPreviewPlayer(
    onDispose: ((previewPlayer: PreviewPlayer) -> Unit)? = null,
): PreviewPlayer {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val previewPlayer = remember(context) {
        PreviewPlayer(scope)
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        onDispose {
            onDispose?.let { it(previewPlayer) }
        }
    }

    return previewPlayer
}
