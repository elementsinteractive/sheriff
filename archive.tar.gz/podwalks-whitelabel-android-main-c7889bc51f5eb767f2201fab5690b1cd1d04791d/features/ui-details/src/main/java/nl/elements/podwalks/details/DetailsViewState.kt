package nl.elements.podwalks.details

import android.os.Parcelable
import com.airbnb.mvrx.MavericksState
import kotlinx.parcelize.Parcelize
import kotlin.time.Duration

data class SelectedPodwalkPreviewChapter(
    val index: Int,
    val isPlaying: Boolean,
)

data class DetailsViewState(
    val podwalkId: String,
    val loading: Boolean = true,
    val isDownloading: Boolean = false,
    val isDownloadDialogShown: Boolean = false,
    val tour: Tour? = null,
    val confirmDeletePodwalk: Boolean = false,
) : MavericksState {

    constructor(args: DetailsArguments) : this(args.podwalkId)

    data class Tour(
        val name: String,
        val description: String,
        val images: List<Image>,
        val duration: Duration,
        val lengthInKm: Double,
        val downloadState: DownloadState,
        val tags: List<String>,
        val startLocation: StartLocation,
        val firstChapter: Chapter,
        val chapterPreviews: List<PreviewChapter>,
    ) {

        data class Chapter(
            val index: Int,
            val latitude: Double,
            val longitude: Double,
            val triggerRadiusInMeters: Int,
        )

        data class Image(
            val useLightStatusBarIcons: Boolean,
            val imageUrl: String,
        )

        data class StartLocation(val coordinate: Pair<Double, Double>, val address: String)

        data class PreviewChapter(val index: Int, val title: String, val audioFileUrl: String)

        sealed interface DownloadState {
            object NotDownloaded : DownloadState
            data class Downloading(val progress: Float) : DownloadState
            object Downloaded : DownloadState
        }
    }
}

@Parcelize
data class DetailsArguments(
    val podwalkId: String,
) : Parcelable
