package nl.elements.podwalks.details.compose.header

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.details.DetailsViewState
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.theme.unselectedPage
import nl.elements.podwalks.presentation.compose.updateStatusBar
import nl.elements.podwalks.presentation.constant.MarginConstants.cornerButtonEdgeMarginInDp
import nl.elements.podwalks.sdk.ui.components.buttons.BackButton
import nl.elements.podwalks.sdk.ui.components.buttons.HelpButton
import nl.elements.podwalks.shared.resources.R

@Composable
@Suppress("LongMethod")
fun DetailsHeader(
    modifier: Modifier = Modifier,
    carouselImages: List<DetailsViewState.Tour.Image>,
    onBackClick: () -> Unit,
    onHelpClick: () -> Unit,
) {
    val context = LocalContext.current as ComponentActivity
    val buttonEdgeMargin = cornerButtonEdgeMarginInDp.dp

    Box(modifier) {
        val pagerState = rememberPagerState(
            pageCount = {
                carouselImages.size
            },
        )
        val pagerIndex by remember {
            derivedStateOf {
                pagerState.currentPage
            }
        }

        val firstImage = carouselImages.firstOrNull()
        LaunchedEffect(firstImage) {
            if (firstImage != null) {
                val lightIcons = firstImage.useLightStatusBarIcons

                context.updateStatusBar(!lightIcons)
            }
        }

        DisposableEffect(pagerIndex) {
            val image = carouselImages.getOrNull(pagerIndex)
            if (image != null) {
                val lightIcons = image.useLightStatusBarIcons

                context.updateStatusBar(!lightIcons)
            }

            onDispose { }
        }

        ImageCarousel(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(),
            carouselImageUrls = carouselImages.map { it.imageUrl },
            pagerState = pagerState,
        )

        ImageCarouselGradient(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .fillMaxHeight(),
        )

        CarouselImagePageIndicator(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp),
            selectedPageColor = MaterialTheme.colors.primary,
            unselectedPageColor = MaterialTheme.colors.unselectedPage,
            pages = carouselImages.size,
            currentPage = pagerState.currentPage,
        )

        BackButton(
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(
                    start = buttonEdgeMargin,
                    top = buttonEdgeMargin,
                ),
            contentDescription = stringResource(id = R.string.acc_navigation_back_button),
            onClick = onBackClick,
        )

        HelpButton(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(
                    end = buttonEdgeMargin,
                    top = buttonEdgeMargin,
                ),
            contentDescription = stringResource(R.string.acc_navigation_help_button),
            onClick = onHelpClick,
        )
    }
}

@Preview(widthDp = 428, heightDp = 369, showBackground = true, backgroundColor = 0xFFFFFFFF)
@Composable
fun DetailsHeaderPreview() {
    AppTheme {
        DetailsHeader(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(),
            carouselImages = listOf(
                DetailsViewState.Tour.Image(false, ""),
                DetailsViewState.Tour.Image(false, ""),
                DetailsViewState.Tour.Image(false, ""),
            ),
            onBackClick = {},
            onHelpClick = {},
        )
    }
}
