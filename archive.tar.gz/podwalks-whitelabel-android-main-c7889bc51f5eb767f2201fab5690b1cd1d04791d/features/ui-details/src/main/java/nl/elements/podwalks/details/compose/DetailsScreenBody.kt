package nl.elements.podwalks.details.compose

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.details.DetailsViewState
import nl.elements.podwalks.details.compose.description.PodwalkDescription
import nl.elements.podwalks.details.compose.download.DownloadPodwalkButton
import nl.elements.podwalks.details.compose.location.StartLocationSection
import nl.elements.podwalks.details.compose.preview.PodwalkAudioPreview
import nl.elements.podwalks.details.compose.preview.PodwalkAudioPreviewSection
import nl.elements.podwalks.details.compose.tooling.previewDetailsViewStateTour
import nl.elements.podwalks.details.mapper.toDownloadButtonState
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.components.attributes.PodwalkLengthAttribute
import nl.elements.podwalks.sdk.ui.components.attributes.PodwalkTimeAttribute

@Composable
fun DetailsScreenBody(
    modifier: Modifier = Modifier,
    tour: DetailsViewState.Tour,
    onPodwalkDownloadClick: () -> Unit,
    onStartLocationClick: () -> Unit,
) {
    Column(modifier) {
        Text(
            text = tour.name,
            style = MaterialTheme.typography.h1,
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row {
            PodwalkTimeAttribute(
                duration = tour.duration,
            )

            Spacer(modifier = Modifier.width(16.dp))

            PodwalkLengthAttribute(
                lengthInKm = tour.lengthInKm,
            )
        }

        DownloadPodwalkButton(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 36.dp),
            downloadState = tour.toDownloadButtonState(),
            onClick = onPodwalkDownloadClick,
        )

        PodwalkDescription(tour = tour)

        Spacer(modifier = Modifier.height(36.dp))

        StartLocationSection(
            tour = tour,
            onStartLocationClick = onStartLocationClick,
        )

        Spacer(modifier = Modifier.height(36.dp))

        PodwalkAudioPreviewSection(
            modifier = Modifier.fillMaxWidth(),
            previews = tour.chapterPreviews.map {
                PodwalkAudioPreview(it.index, it.title, it.audioFileUrl)
            },
        )

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Preview(heightDp = 1200, showBackground = true, backgroundColor = 0xFFFFFFFF)
@Composable
fun DetailsScreenBodyPreview() {
    AppTheme {
        DetailsScreenBody(
            tour = previewDetailsViewStateTour,
            onStartLocationClick = {},
            onPodwalkDownloadClick = {},
        )
    }
}
