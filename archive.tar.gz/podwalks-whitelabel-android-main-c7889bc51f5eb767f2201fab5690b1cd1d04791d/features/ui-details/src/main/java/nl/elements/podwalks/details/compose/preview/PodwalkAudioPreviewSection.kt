package nl.elements.podwalks.details.compose.preview

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.details.compose.preview.player.PreviewPlayer
import nl.elements.podwalks.details.compose.preview.player.handleOnPreviewClick
import nl.elements.podwalks.details.compose.preview.player.rememberPreviewPlayer
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.shared.resources.R

private fun PreviewPlayer.State.toSelectedPreview() =
    when (this) {
        PreviewPlayer.State.Idle -> null
        is PreviewPlayer.State.Loading ->
            SelectedAudioPreview(chapterIndex, false)
        is PreviewPlayer.State.PlayingPreview ->
            SelectedAudioPreview(chapterIndex, isPlaying)
    }

@Composable
fun PodwalkAudioPreviewSection(
    modifier: Modifier = Modifier,
    previews: List<PodwalkAudioPreview>,
) {
    val previewPlayer = rememberPreviewPlayer {
        it.close()
    }

    val selectedPreview: SelectedAudioPreview? by remember {
        previewPlayer.state
            .map { playerState -> playerState?.toSelectedPreview() }
    }.collectAsState(initial = null)

    Column(modifier) {
        Text(
            text = stringResource(id = R.string.home_preview_section_heading),
            style = MaterialTheme.typography.subtitle2,
        )

        Spacer(modifier = Modifier.height(16.dp))

        AudioPreviewCards(
            modifier = Modifier.fillMaxWidth(),
            previews = previews,
            selectedPreview = selectedPreview,
            onPreviewClick = { index ->
                handleOnPreviewClick(previewPlayer, previews, index)
            },
        )
    }
}

@Preview(widthDp = 380, showBackground = true, backgroundColor = 0xFFFFFFFF)
@Composable
fun PodwalkAudioPreviewSectionPreview() {
    AppTheme {
        PodwalkAudioPreviewSection(
            modifier = Modifier.fillMaxWidth(),
            previews = listOf(
                PodwalkAudioPreview(0, "United East India Company arrives", ""),
                PodwalkAudioPreview(1, "Beer and Cheese", ""),
                PodwalkAudioPreview(2, "Batavia", ""),
            ),
        )
    }
}
