package nl.elements.podwalks.details.compose.preview

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import nl.elements.podwalks.sdk.ui.components.pin.PlayingChapterPin
import nl.elements.podwalks.sdk.ui.components.pin.UnvisitedChapterPin

@Composable
fun PreviewChapterPin(
    modifier: Modifier = Modifier,
    chapterIndex: Int,
    isPlaying: Boolean,
) {
    if (isPlaying) {
        PlayingChapterPin(modifier, chapterIndex)
    } else {
        UnvisitedChapterPin(modifier, chapterIndex)
    }
}
