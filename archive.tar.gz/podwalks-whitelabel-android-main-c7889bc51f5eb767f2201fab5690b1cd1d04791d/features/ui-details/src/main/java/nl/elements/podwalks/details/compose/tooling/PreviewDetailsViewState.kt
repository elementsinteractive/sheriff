package nl.elements.podwalks.details.compose.tooling

import nl.elements.podwalks.details.DetailsViewState
import kotlin.time.Duration.Companion.minutes

internal val previewDetailsViewStateTour
    get() = DetailsViewState.Tour(
        name = "Amsterdam in the Golden Ages",
        description = "Discover Amsterdam in the 1700s. During this period, Amsterdam’s " +
            "famous canals were created.",
        images = listOf(
            DetailsViewState.Tour.Image(false, ""),
            DetailsViewState.Tour.Image(false, ""),
            DetailsViewState.Tour.Image(false, ""),
        ),
        duration = 45.minutes,
        lengthInKm = 4.5,
        downloadState = DetailsViewState.Tour.DownloadState.NotDownloaded,
        tags = listOf(
            "Wheelchair accessible",
            "City walk",
            "History",
            "Activity",
            "Educational",
            "Suitable for kids",
        ),
        firstChapter = DetailsViewState.Tour.Chapter(
            index = 0,
            latitude = 0.0,
            longitude = 0.0,
            triggerRadiusInMeters = 20,
        ),
        startLocation = DetailsViewState.Tour.StartLocation(
            coordinate = 0.0 to 0.0,
            address = "Stationplein, 1012 AB Amsterdam",
        ),
        chapterPreviews = listOf(
            DetailsViewState.Tour.PreviewChapter(1, "United East India Company arrives", ""),
            DetailsViewState.Tour.PreviewChapter(2, "Beer and Cheese", ""),
            DetailsViewState.Tour.PreviewChapter(3, "Batavia", ""),
        ),
    )

internal val previewDetailsViewState
    get() = DetailsViewState(
        podwalkId = "1",
        tour = previewDetailsViewStateTour,
    )
