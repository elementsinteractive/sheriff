package nl.elements.podwalks.info.compose.data

import nl.elements.podwalks.shared.resources.R

val helpItems
    get() = listOf(
        HelpItem(
            question = R.string.info_help_question_01,
            description = R.string.info_help_answer_01,
        ),
        HelpItem(
            question = R.string.info_help_question_02,
            description = R.string.info_help_answer_02,
        ),
        HelpItem(
            question = R.string.info_help_question_03,
            description = R.string.info_help_answer_03,
        ),
        HelpItem(
            question = R.string.info_help_question_04,
            description = R.string.info_help_answer_04,
        ),
        HelpItem(
            question = R.string.info_help_question_05,
            description = R.string.info_help_answer_05,
        ),
        HelpItem(
            question = R.string.info_help_question_06,
            description = R.string.info_help_answer_06,
        ),
        HelpItem(
            question = R.string.info_help_question_07,
            description = R.string.info_help_answer_07,
        ),
        HelpItem(
            question = R.string.info_help_question_08,
            description = R.string.info_help_answer_08,
        ),
        HelpItem(
            question = R.string.info_help_question_09,
            description = R.string.info_help_answer_09,
        ),
    )
