package nl.elements.podwalks.info.analytics

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import nl.elements.podwalks.info.sources.ExtraInfoSource

@Module
@InstallIn(SingletonComponent::class)
abstract class AnalyticsBinds {
    @Binds
    @IntoSet
    abstract fun vrtAnalyticsDebuggerBinds(bind: AnalyticsInfoSource): ExtraInfoSource
}
