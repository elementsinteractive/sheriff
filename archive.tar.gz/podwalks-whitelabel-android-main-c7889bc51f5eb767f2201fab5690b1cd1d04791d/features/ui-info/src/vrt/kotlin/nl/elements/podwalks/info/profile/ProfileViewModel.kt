package nl.elements.podwalks.info.profile

import be.vrt.consents.VrtConsents
import be.vrt.login.core.VrtLogin
import be.vrt.login.core.model.Result
import com.airbnb.mvrx.MavericksViewModel
import com.airbnb.mvrx.MavericksViewModelFactory
import com.airbnb.mvrx.hilt.AssistedViewModelFactory
import com.airbnb.mvrx.hilt.hiltMavericksViewModelFactory
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.launch

class ProfileViewModel @AssistedInject constructor(
    @Assisted initialState: ProfileViewState,
) : MavericksViewModel<ProfileViewState>(initialState) {

    fun setUp() = fetchLoginState()

    private fun fetchLoginState() {
        viewModelScope.launch {
            when (VrtLogin.getUserAndTokens(refreshTokensIfExpired = true)) {
                is Result.LoginComplete -> {
                    val profilePageUrl = VrtLogin.profilePageUrl()
                    setState {
                        copy(
                            profileUrl = profilePageUrl,
                            isLoggedIn = true,
                        )
                    }
                }
                else -> {
                    setState {
                        copy(
                            profileUrl = "",
                            isLoggedIn = false,
                        )
                    }
                }
            }
        }
    }

    fun fetchProfile() {
        viewModelScope.launch {
            val profilePageUrl = VrtLogin.profilePageUrl()
            setState {
                copy(
                    profileUrl = profilePageUrl,
                    isLoggedIn = true,
                )
            }
        }
    }

    fun showConsentScreen() {
        viewModelScope.launch {
            VrtConsents.showConsentsScreen()
        }
    }

    fun logout() {
        viewModelScope.launch {
            VrtLogin.logout()
            setState {
                copy(
                    profileUrl = "",
                    isLoggedIn = false,
                )
            }
        }
    }

    @AssistedFactory
    interface Factory : AssistedViewModelFactory<ProfileViewModel, ProfileViewState> {
        override fun create(state: ProfileViewState): ProfileViewModel
    }

    companion object :
        MavericksViewModelFactory<ProfileViewModel, ProfileViewState> by hiltMavericksViewModelFactory()
}
