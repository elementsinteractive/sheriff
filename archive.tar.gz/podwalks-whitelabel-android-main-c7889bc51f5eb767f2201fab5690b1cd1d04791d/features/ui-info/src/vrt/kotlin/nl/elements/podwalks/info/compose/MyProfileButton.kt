package nl.elements.podwalks.info.compose

import android.annotation.SuppressLint
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import androidx.browser.customtabs.CustomTabsIntent.SHARE_STATE_OFF
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.shared.resources.R

@SuppressLint("WrongConstant")
@Composable
internal fun MyProfileButton(
    modifier: Modifier = Modifier,
    isLoggedIn: Boolean,
    profileUrl: String,
    onLoginClick: () -> Unit,
) {
    val context = LocalContext.current

    val onClickAction: () -> Unit = {
        if (isLoggedIn && profileUrl.isNotBlank()) {
            val intent = CustomTabsIntent.Builder().apply {
                setShareState(SHARE_STATE_OFF)
                setShowTitle(true)
            }.build()
            intent.launchUrl(context, Uri.parse(profileUrl))
        } else {
            onLoginClick()
        }
    }

    PrimaryButton(
        modifier = modifier.fillMaxWidth(),
        onClick = onClickAction,
    ) {
        Text(
            text = stringResource(id = R.string.info_profile_my_profile_button),
            style = MaterialTheme.typography.button,
        )
    }
}
