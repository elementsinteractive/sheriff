package nl.elements.podwalks.info.analytics

import be.vrt.eba.plugins.DebuggerPlugin
import nl.elements.podwalks.info.sources.ExtraInfoSource
import javax.inject.Inject

class AnalyticsInfoSource @Inject constructor() : ExtraInfoSource {

    var usageCount: Int = 0
    var debuggerCode: String? = null
    override fun extraData(): Pair<Int, String?> {
        return if (debuggerCode != null) {
            Pair(1, "EBA debugger code: $debuggerCode")
        } else {
            Pair(1, null)
        }
    }

    override fun onHiddenAction() {
        usageCount++
        if (usageCount == 5) {
            DebuggerPlugin.setDebugging(true)
            debuggerCode = DebuggerPlugin.getSessionInstance()
        }
    }
}
