package nl.elements.podwalks.info.profile

import com.airbnb.mvrx.MavericksState

data class ProfileViewState(
    val profileUrl: String = "",
    val isLoggedIn: Boolean = false,
) : MavericksState
