package nl.elements.podwalks.info.profile

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import be.vrt.login.core.model.Result
import be.vrt.login.ui.VrtLoginActivity
import com.airbnb.mvrx.compose.collectAsState
import com.airbnb.mvrx.compose.mavericksViewModel
import nl.elements.podwalks.info.compose.MyProfileButton
import nl.elements.podwalks.info.compose.ProfileLogoutButton
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.shared.resources.R

@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    viewModel: ProfileViewModel = mavericksViewModel(),
) {
    val state by viewModel.collectAsState()

    LaunchedEffect(true) {
        viewModel.setUp()
    }

    ProfileScreen(
        modifier = modifier,
        state = state,
        onConsentClick = viewModel::showConsentScreen,
        onLogoutClick = viewModel::logout,
        onLoginSuccess = viewModel::fetchProfile,
    )
}

@Composable
internal fun ProfileScreen(
    modifier: Modifier = Modifier,
    state: ProfileViewState,
    onConsentClick: () -> Unit,
    onLogoutClick: () -> Unit,
    onLoginSuccess: () -> Unit,
) {
    val context = LocalContext.current
    val launcher =
        rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { activityResult ->
            val resultCode = activityResult.resultCode
            val data = activityResult.data
            if (resultCode == Activity.RESULT_OK && data != null) {
                val result: Result? = data.getParcelableExtra<Result>(VrtLoginActivity.EXTRA_RESULT)

                if (result is Result.LoginComplete) {
                    onLoginSuccess()
                }
            }
        }

    val onLoginClick: () -> Unit = {
        launcher.launch(VrtLoginActivity.startIntent(context))
    }

    Column(
        modifier = modifier
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        MyProfileButton(
            isLoggedIn = state.isLoggedIn,
            profileUrl = state.profileUrl,
            onLoginClick = onLoginClick,
        )

        PrimaryButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = onConsentClick,
        ) {
            Text(
                text = stringResource(id = R.string.info_profile_cookie_button),
                style = MaterialTheme.typography.button,
            )
        }

        ProfileLogoutButton(
            isLoggedIn = state.isLoggedIn,
            onLoginClick = onLoginClick,
            onLogoutClick = onLogoutClick,
        )
    }
}

@Preview
@Composable
internal fun ProfileScreenPreviews() {
    AppTheme {
        ProfileScreen(
            state = ProfileViewState(),
            onConsentClick = {},
            onLogoutClick = {},
            onLoginSuccess = {},
        )
    }
}
