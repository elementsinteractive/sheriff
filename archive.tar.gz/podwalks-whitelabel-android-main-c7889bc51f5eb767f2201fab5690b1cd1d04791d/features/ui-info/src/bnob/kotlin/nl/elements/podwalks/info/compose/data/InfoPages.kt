package nl.elements.podwalks.info.compose.data

val infoPages
    get() = listOf(
        InfoPageType.APP,
        InfoPageType.HELP,
        InfoPageType.LEGAL,
        InfoPageType.LICENSES,
    )
