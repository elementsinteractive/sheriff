package nl.elements.podwalks.info.sources

import javax.inject.Inject

class InfoSources @Inject constructor(
    val extraSources: Set<@JvmSuppressWildcards ExtraInfoSource>,
) : ExtraInfoSource {

    override fun extraData(): Pair<Int, String?> = Pair(
        0,
        extraSources
            .map { it.extraData() }
            .sortedBy { it.first }
            .fold<Pair<Int, String?>, String?>(null) { initial, result ->
                if (result.second == null) {
                    initial
                } else if (initial == null) {
                    result.second
                } else {
                    "$initial\n${result.second}"
                }
            },
    )

    override fun onHiddenAction() {
        extraSources.forEach {
            it.onHiddenAction()
        }
    }
}
