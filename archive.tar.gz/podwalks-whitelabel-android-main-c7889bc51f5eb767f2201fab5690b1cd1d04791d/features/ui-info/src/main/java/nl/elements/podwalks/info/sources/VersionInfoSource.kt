package nl.elements.podwalks.info.sources

import nl.elements.podwalks.data.config.AppConfiguration
import javax.inject.Inject

class VersionInfoSource @Inject constructor(
    private val appConfiguration: AppConfiguration,
) : ExtraInfoSource {
    override fun extraData(): Pair<Int, String?> {
        return Pair(0, appConfiguration.versionName)
    }

    override fun onHiddenAction() = Unit
}
