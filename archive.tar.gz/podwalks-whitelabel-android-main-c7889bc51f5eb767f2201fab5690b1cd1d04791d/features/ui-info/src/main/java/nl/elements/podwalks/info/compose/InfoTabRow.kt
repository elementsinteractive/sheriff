package nl.elements.podwalks.info.compose

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDp
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.updateTransition
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.material.ScrollableTabRow
import androidx.compose.material.Tab
import androidx.compose.material.TabPosition
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import nl.elements.podwalks.info.compose.data.infoPages
import nl.elements.podwalks.info.compose.data.labelRes

@Composable
fun InfoTabRow(
    modifier: Modifier = Modifier,
    selectedTabIndex: Int,
    onTabClicked: (Int) -> Unit,
) {
    ScrollableTabRow(
        modifier = modifier,
        selectedTabIndex = selectedTabIndex,
        backgroundColor = Color.Transparent,
        edgePadding = 16.dp,
        indicator = { tabPositions ->
            TabIndicator(
                tabPositions = tabPositions,
                index = selectedTabIndex,
            )
        },
        divider = {},
    ) {
        infoPages.forEachIndexed { index, title ->
            Tab(
                modifier = Modifier.zIndex(1f),
                selected = selectedTabIndex == index,
                onClick = { onTabClicked(index) },
                text = {
                    Text(
                        text = stringResource(id = title.labelRes),
                        style = MaterialTheme.typography.body1,
                        fontWeight = FontWeight.SemiBold,
                    )
                },
                selectedContentColor = MaterialTheme.colors.background,
                unselectedContentColor = MaterialTheme.colors.primary,
            )
        }
    }
}

@Composable
fun TabIndicator(
    modifier: Modifier = Modifier,
    tabPositions: List<TabPosition>,
    index: Int,
) {
    val transition = updateTransition(targetState = index, label = "")
    val leftIndicator by transition.animateDp(
        label = "",
        transitionSpec = { spring(stiffness = Spring.StiffnessMedium) },
    ) { tabPositions[it].left }
    val rightIndicator by transition.animateDp(
        label = "",
        transitionSpec = { spring(stiffness = Spring.StiffnessMedium) },
    ) { tabPositions[it].right }
    Box(
        modifier
            .wrapContentSize(Alignment.BottomStart)
            .offset(x = leftIndicator)
            .width(rightIndicator - leftIndicator)
            .padding(4.dp)
            .fillMaxSize()
            .background(
                MaterialTheme.colors.primary,
                RoundedCornerShape(16.dp),
            ),
    )
}
