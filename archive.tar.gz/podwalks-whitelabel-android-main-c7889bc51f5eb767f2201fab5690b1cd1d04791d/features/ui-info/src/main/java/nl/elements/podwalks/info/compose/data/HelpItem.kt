package nl.elements.podwalks.info.compose.data

import androidx.annotation.StringRes

data class HelpItem(
    @StringRes val question: Int,
    @StringRes val description: Int,
)
