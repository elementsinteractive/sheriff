package nl.elements.podwalks.info

import android.content.Intent
import android.provider.Settings
import androidx.activity.ComponentActivity
import com.airbnb.mvrx.MavericksViewModel
import com.airbnb.mvrx.MavericksViewModelFactory
import com.airbnb.mvrx.hilt.AssistedViewModelFactory
import com.airbnb.mvrx.hilt.hiltMavericksViewModelFactory
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.launch
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.info.sources.InfoSources
import nl.elements.podwalks.notifications.PushNotificationController
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import timber.log.Timber

class InfoViewModel @AssistedInject constructor(
    @Assisted initialState: InfoViewState,
    private val dispatchers: AppCoroutineDispatchers,
    private val infoSources: InfoSources,
    private val analyticsTracker: AnalyticsTracker,
    private val notificationController: PushNotificationController,
) : MavericksViewModel<InfoViewState>(initialState) {

    init {
        viewModelScope.launch(dispatchers.io) {
            setState {
                copy(
                    appVersionName = infoSources.extraData().second ?: "",
                    notificationSwitch = if (notificationController.isPushSupported()) {
                        notificationController.isPushEnabled()
                    } else {
                        null
                    },
                )
            }
        }
    }

    fun trackCallToAction() {
        analyticsTracker.track(AnalyticsEvent.CallToAction)
    }

    fun triggerHiddenButton() {
        viewModelScope.launch(dispatchers.io) {
            infoSources.onHiddenAction()
            setState {
                copy(
                    appVersionName = infoSources.extraData().second ?: "",
                )
            }
        }
    }

    @SuppressWarnings("TooGenericExceptionCaught")
    fun toggleNotification(state: Boolean, context: ComponentActivity) {
        viewModelScope.launch {
            if (!notificationController.isPushPermissionGranted(context)) {
                if (!notificationController.requestPushPermission(context)) {
                    // permission denied (silently?), open settings
                    val settingsIntent: Intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)

                    try {
                        context.startActivity(settingsIntent)
                    } catch (e: Exception) {
                        Timber.e(e)
                    }
                }
            }

            if (notificationController.isPushPermissionGranted(context)) {
                notificationController.setPushEnabled(state)
                setState {
                    copy(
                        notificationSwitch = state,
                    )
                }
            }
        }
    }

    @AssistedFactory
    interface Factory : AssistedViewModelFactory<InfoViewModel, InfoViewState> {
        override fun create(state: InfoViewState): InfoViewModel
    }

    companion object :
        MavericksViewModelFactory<InfoViewModel, InfoViewState> by hiltMavericksViewModelFactory()
}
