package nl.elements.podwalks.info.compose.pages

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.info.compose.data.helpItems
import nl.elements.podwalks.info.compose.item.HelpRow
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.shared.resources.R

@Composable
fun InfoHelpPage(
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(
                state = rememberScrollState(),
            ),
    ) {
        for (helpItem in helpItems) {
            HelpRow(
                question = stringResource(id = helpItem.question),
                description = stringResource(id = helpItem.description),
            )
        }

        Text(
            modifier = Modifier
                .padding(24.dp),
            text = stringResource(id = R.string.info_help_contact),
            style = MaterialTheme.typography.body1,
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFF)
@Composable
fun HelpRowPreview() {
    AppTheme {
        InfoHelpPage()
    }
}
