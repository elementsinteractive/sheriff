package nl.elements.podwalks.info.compose.data

import androidx.annotation.StringRes
import nl.elements.podwalks.shared.resources.R

enum class InfoPageType {
    APP,
    PROFILE,
    HELP,
    LEGAL,
    LICENSES,
}

internal val InfoPageType.labelRes: Int
    @StringRes
    get() = when (this) {
        InfoPageType.APP -> R.string.info_app
        InfoPageType.PROFILE -> R.string.info_profile
        InfoPageType.HELP -> R.string.info_help
        InfoPageType.LEGAL -> R.string.info_legal
        InfoPageType.LICENSES -> R.string.info_licenses
    }
