package nl.elements.podwalks.info

import com.mikepenz.aboutlibraries.entity.Library

internal fun Library.toInfoLibrary(): InfoViewState.Library =
    InfoViewState.Library(
        name = name,
        version = artifactVersion ?: "",
        website = website ?: "",
        license = licenses.joinToString("<br>") {
            it.licenseContent ?: ""
        },
        licenseDescription = description,
    )
