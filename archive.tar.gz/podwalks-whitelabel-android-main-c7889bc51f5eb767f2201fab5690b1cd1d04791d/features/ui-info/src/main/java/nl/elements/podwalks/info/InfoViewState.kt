package nl.elements.podwalks.info

import com.airbnb.mvrx.MavericksState

data class InfoViewState(
    val appVersionName: String = "",
    val notificationSwitch: Boolean? = null, // null = absent
) : MavericksState {
    data class Library(
        val name: String,
        val version: String,
        val website: String,
        val license: String?,
        val licenseDescription: String?,
    )
}
