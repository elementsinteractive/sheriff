package nl.elements.podwalks.info.compose

import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.Divider
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.airbnb.mvrx.compose.collectAsState
import com.airbnb.mvrx.compose.mavericksViewModel
import kotlinx.coroutines.launch
import nl.elements.podwalks.info.InfoViewModel
import nl.elements.podwalks.info.InfoViewState
import nl.elements.podwalks.info.compose.data.InfoPageType
import nl.elements.podwalks.info.compose.data.infoPages
import nl.elements.podwalks.info.compose.pages.InfoAppPage
import nl.elements.podwalks.info.compose.pages.InfoHelpPage
import nl.elements.podwalks.info.compose.pages.InfoLegalPage
import nl.elements.podwalks.info.compose.pages.InfoLicencesPage
import nl.elements.podwalks.info.compose.pages.InfoProfilePage
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.shared.resources.R

@Composable
fun InfoScreen(
    modifier: Modifier = Modifier,
    onCloseClicked: () -> Unit,
    onOpenCallToAction: () -> Unit,
    viewModel: InfoViewModel = mavericksViewModel(),
) {
    val state by viewModel.collectAsState()
    val context = LocalContext.current

    BackHandler {
        onCloseClicked()
    }

    InfoScreen(
        modifier = modifier.systemBarsPadding(),
        state = state,
        onCloseClicked = onCloseClicked,
        onCallToActionClick = {
            viewModel.trackCallToAction()

            onOpenCallToAction()
        },
        onHiddenButtonClick = viewModel::triggerHiddenButton,
        onSetNotificationState = { state ->
            viewModel.toggleNotification(
                state,
                context as ComponentActivity,
            )
        },
    )
}

@Composable
fun InfoScreen(
    modifier: Modifier = Modifier,
    state: InfoViewState,
    onCloseClicked: () -> Unit,
    onCallToActionClick: () -> Unit,
    onHiddenButtonClick: () -> Unit,
    onSetNotificationState: (Boolean) -> Unit,
) {
    val scope = rememberCoroutineScope()

    val context = LocalContext.current

    Surface(
        modifier = modifier,
        color = MaterialTheme.colors.background,
    ) {
        Column {
            val pagerState = rememberPagerState(
                pageCount = {
                    infoPages.size
                },
            )

            InfoTopBar(
                title = stringResource(id = R.string.info_top_bar_title),
                onCloseClicked = onCloseClicked,
            )

            InfoTabRow(
                selectedTabIndex = pagerState.currentPage,
                onTabClicked = { index ->
                    scope.launch { pagerState.scrollToPage(index) }
                },
            )

            Divider(Modifier.padding(top = 12.dp))

            HorizontalPager(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                state = pagerState,
                verticalAlignment = Alignment.Top,
            ) { currentPage: Int ->
                Column(Modifier.fillMaxSize()) {
                    when (infoPages[currentPage]) {
                        InfoPageType.APP -> InfoAppPage(
                            versionName = state.appVersionName,
                            notificationState = state.notificationSwitch,
                            onCallToAction = onCallToActionClick,
                            onHiddenAction = onHiddenButtonClick,
                            onSetNotificationState = onSetNotificationState,
                        )
                        InfoPageType.PROFILE -> InfoProfilePage()
                        InfoPageType.HELP -> InfoHelpPage()
                        InfoPageType.LEGAL -> InfoLegalPage()
                        InfoPageType.LICENSES -> InfoLicencesPage(
                            onOpenLibraryWebsite = {
                                context.startActivity(Intent(Intent.ACTION_VIEW, it))
                            },
                        )
                    }
                }
            }
        }
    }
}

@Preview
@Composable
internal fun InfoScreenPreview() {
    AppTheme {
        val state by remember {
            mutableStateOf(
                InfoViewState(
                    appVersionName = "1.0.0",
                    notificationSwitch = true,
                ),
            )
        }

        InfoScreen(
            modifier = Modifier.fillMaxSize(),
            state = state,
            onCloseClicked = {},
            onCallToActionClick = {},
            onHiddenButtonClick = {},
            onSetNotificationState = {},
        )
    }
}
