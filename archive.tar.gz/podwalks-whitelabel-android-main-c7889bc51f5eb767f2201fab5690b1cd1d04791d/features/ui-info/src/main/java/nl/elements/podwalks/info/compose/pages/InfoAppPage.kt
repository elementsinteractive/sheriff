package nl.elements.podwalks.info.compose.pages

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Switch
import androidx.compose.material.SwitchDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.google.accompanist.drawablepainter.rememberDrawablePainter
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.shared.resources.R

@Composable
fun InfoAppPage(
    modifier: Modifier = Modifier,
    versionName: String,
    notificationState: Boolean?,
    onCallToAction: () -> Unit,
    onHiddenAction: () -> Unit,
    onSetNotificationState: (Boolean) -> Unit,
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(60.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            modifier = Modifier.fillMaxWidth(),
            text = stringResource(R.string.info_app_description),
            style = MaterialTheme.typography.body1,
        )

        notificationState?.let {
            InfoAppNotificationSwitch(
                notificationState = it,
                onSetNotificationState = onSetNotificationState,
            )
        }

        InfoAppBrandView(
            versionName = versionName,
            onClick = onHiddenAction,
        )

        PrimaryButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = onCallToAction,
        ) {
            Text(
                text = stringResource(R.string.info_app_button_call_to_action),
                style = MaterialTheme.typography.button,
            )
        }
    }
}

@Composable
fun InfoAppBrandView(
    modifier: Modifier = Modifier,
    versionName: String,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val context = LocalContext.current
        val appIconDrawable = remember(context) {
            context.run {
                packageManager
                    .getApplicationIcon(packageName)
            }
        }

        Image(
            modifier = Modifier.size(110.dp),
            painter = rememberDrawablePainter(drawable = appIconDrawable),
            contentDescription = stringResource(id = R.string.acc_info_app_icon),
            contentScale = ContentScale.Fit,
        )

        Text(
            modifier = Modifier.clickable { onClick() },
            text = stringResource(R.string.info_app_version, versionName),
            style = MaterialTheme.typography.caption,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colors.onSecondary,
        )
    }
}

@Composable
fun InfoAppNotificationSwitch(
    modifier: Modifier = Modifier,
    notificationState: Boolean,
    onSetNotificationState: (Boolean) -> Unit,
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stringResource(R.string.info_notification_switch_title),
                style = MaterialTheme.typography.button,
            )
            Spacer(modifier = Modifier.weight(1f))
            Switch(
                checked = notificationState,
                onCheckedChange = onSetNotificationState,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colors.primary,
                    checkedTrackColor = MaterialTheme.colors.primary.copy(alpha = 0.5f),
                    uncheckedThumbColor = MaterialTheme.colors.onBackground,
                    uncheckedTrackColor = MaterialTheme.colors.onBackground.copy(alpha = 0.5f),
                ),
            )
        }
        Text(text = stringResource(R.string.info_notification_switch_text))
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFF)
@Composable
fun InfoAppPage() {
    AppTheme {
        InfoAppPage(
            versionName = "1.0.0",
            notificationState = true,
            onCallToAction = { },
            onHiddenAction = { },
            onSetNotificationState = { },
        )
    }
}
