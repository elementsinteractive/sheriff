package nl.elements.podwalks.info.compose.item

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.theme.subtitle3

@Composable
fun LegalSection(
    modifier: Modifier = Modifier,
    title: String,
    description: String,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            modifier = Modifier,
            text = title,
            style = MaterialTheme.typography.subtitle3,
        )
        Text(
            modifier = Modifier,
            text = description,
            style = MaterialTheme.typography.body1,
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFF)
@Composable
fun LegalSectionPreviews() {
    AppTheme {
        LegalSection(
            modifier = Modifier
                .padding(
                    horizontal = 24.dp,
                    vertical = 16.dp,
                ),
            title = "Terms",
            description = """
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Phasellus facilisis a ligula sed accumsan.
                Nulla et iaculis velit. Nulla interdum orci a condimentum ultrices.
                Curabitur non consectetur nisl.
            """.trimIndent(),
        )
    }
}
