package nl.elements.podwalks.info.sources

interface ExtraInfoSource {
    fun extraData(): Pair<Int, String?>
    fun onHiddenAction()
}
