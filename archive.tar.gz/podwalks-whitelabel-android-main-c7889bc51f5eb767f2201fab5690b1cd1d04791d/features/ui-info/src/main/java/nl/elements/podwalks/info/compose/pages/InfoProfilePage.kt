package nl.elements.podwalks.info.compose.pages

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import nl.elements.podwalks.info.profile.ProfileScreen
import nl.elements.podwalks.presentation.compose.theme.AppTheme

@Composable
fun InfoProfilePage(
    modifier: Modifier = Modifier,
) {
    ProfileScreen(modifier = modifier)
}

@Preview(showBackground = true, backgroundColor = 0xFFF)
@Composable
fun InfoProfilePagePreviews() {
    AppTheme {
        InfoProfilePage()
    }
}
