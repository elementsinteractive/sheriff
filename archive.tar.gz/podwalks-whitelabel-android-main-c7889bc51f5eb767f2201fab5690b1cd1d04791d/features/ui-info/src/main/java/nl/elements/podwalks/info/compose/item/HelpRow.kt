package nl.elements.podwalks.info.compose.item

import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.collapse
import androidx.compose.ui.semantics.expand
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.theme.subtitle3
import nl.elements.podwalks.shared.resources.R

@OptIn(ExperimentalAnimationApi::class, ExperimentalFoundationApi::class)
@Composable
fun HelpRow(
    modifier: Modifier = Modifier,
    question: String,
    description: String,
) {
    var isExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .clickable { isExpanded = !isExpanded }
            .clearAndSetSemantics {
                if (isExpanded) {
                    collapse {
                        isExpanded = false
                        return@collapse true
                    }
                } else {
                    expand {
                        isExpanded = true
                        return@expand true
                    }
                }

                stateDescription = if (isExpanded) "$question $description" else question
            },
    ) {
        InfoHelpRowHeader(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            question = question,
            icon = if (isExpanded) R.drawable.ic_line else R.drawable.ic_plus,
        )

        AnimatedContent(isExpanded) {
            AnimatedVisibility(visible = isExpanded) {
                Text(
                    modifier = Modifier
                        .padding(horizontal = 24.dp)
                        .padding(top = 8.dp, bottom = 16.dp),
                    text = description,
                    style = MaterialTheme.typography.body1,
                )
            }
        }
    }
}

@Composable
fun InfoHelpRowHeader(
    modifier: Modifier = Modifier,
    question: String,
    @DrawableRes icon: Int,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            modifier = Modifier.weight(1f),
            text = question,
            style = MaterialTheme.typography.subtitle3,
        )

        Icon(
            modifier = Modifier.padding(vertical = 8.dp),
            painter = painterResource(id = icon),
            contentDescription = null,
            tint = MaterialTheme.colors.onSurface,
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFF)
@Composable
fun HelpRowPreview() {
    AppTheme {
        HelpRow(
            question = "Why do I need to enable location permissions?",
            description = """
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Phasellus facilisis a ligula sed accumsan.
                Nulla et iaculis velit. Nulla interdum orci a condimentum ultrices.
                Curabitur non consectetur nisl.
            """.trimIndent(),
        )
    }
}
