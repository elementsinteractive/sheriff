package nl.elements.podwalks.info.inject

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import nl.elements.podwalks.info.sources.ExtraInfoSource
import nl.elements.podwalks.info.sources.VersionInfoSource

@Module
@InstallIn(SingletonComponent::class)
abstract class InfoBinds {
    @Binds
    @IntoSet
    abstract fun versionInfo(bind: VersionInfoSource): ExtraInfoSource
}
