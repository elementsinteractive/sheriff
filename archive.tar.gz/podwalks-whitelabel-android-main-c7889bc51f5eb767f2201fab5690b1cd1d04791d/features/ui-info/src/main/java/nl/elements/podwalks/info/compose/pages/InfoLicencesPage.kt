package nl.elements.podwalks.info.compose.pages

import android.net.Uri
import android.widget.TextView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.text.HtmlCompat
import com.mikepenz.aboutlibraries.ui.compose.LibrariesContainer
import nl.elements.podwalks.info.InfoViewState
import nl.elements.podwalks.info.toInfoLibrary
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.components.dialog.AlertDialog
import nl.elements.podwalks.shared.resources.R

@Composable
fun InfoLicencesPage(
    modifier: Modifier = Modifier,
    onOpenLibraryWebsite: (Uri) -> Unit,
) {
    var showDialogForLibrary by remember { mutableStateOf<InfoViewState.Library?>(null) }

    val library = showDialogForLibrary

    if (library != null) {
        InfoLicensesAlertDialog(
            libraryName = library.name,
            license = library.license,
            licenseDescription = library.licenseDescription,
            onDismissDialog = {
                showDialogForLibrary = null
            },
            onOpenWebsiteClicked = {
                onOpenLibraryWebsite(Uri.parse(library.website))
                showDialogForLibrary = null
            },
        )
    }

    InfoLicenseColumn(
        modifier = modifier
            .padding(top = 16.dp)
            .fillMaxSize(),
        onOpenLicense = {
            showDialogForLibrary = it
        },
    )
}

@Composable
private fun InfoLicensesAlertDialog(
    libraryName: String,
    license: String?,
    licenseDescription: String?,
    onDismissDialog: () -> Unit,
    onOpenWebsiteClicked: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismissDialog,
        title = { Text(text = libraryName, style = MaterialTheme.typography.h4) },
        positiveButton = {
            Button(onClick = onDismissDialog) {
                Text(text = stringResource(id = R.string.info_licenses_dialog_close))
            }
        },
        neutralButton = {
            Button(onClick = onOpenWebsiteClicked) {
                Text(text = stringResource(id = R.string.info_licenses_dialog_open_website))
            }
        },
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(state = rememberScrollState())
                .weight(1f),
        ) {
            AndroidView(
                factory = { context ->
                    TextView(context)
                },
                modifier = Modifier.padding(16.dp),
                update = {
                    it.text = HtmlCompat.fromHtml(
                        "${licenseDescription ?: ""}<br><br>$license",
                        HtmlCompat.FROM_HTML_MODE_LEGACY,
                    )
                },
            )
        }
    }
}

@Composable
private fun InfoLicenseColumn(
    modifier: Modifier = Modifier,
    onOpenLicense: (InfoViewState.Library) -> Unit,
) {
    LibrariesContainer(
        modifier = modifier.fillMaxSize(),
        onLibraryClick = { lib ->
            onOpenLicense(lib.toInfoLibrary())
        },
    )
}

@Preview(showBackground = true, backgroundColor = 0xFFF)
@Composable
fun InfoLicencesPagePreview() {
    AppTheme {
        InfoLicencesPage(
            onOpenLibraryWebsite = { },
        )
    }
}
