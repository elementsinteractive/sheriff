package nl.elements.podwalks.info.compose.pages

import android.text.method.LinkMovementMethod
import android.widget.TextView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.text.HtmlCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import nl.elements.podwalks.sdk.ui.theme.PodwalkTheme
import nl.elements.podwalks.shared.resources.R

@Suppress("TooGenericExceptionCaught", "SwallowedException")
@Composable
fun InfoLegalPage(
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(
                state = rememberScrollState(),
            ),
    ) {
        val onSurface = PodwalkTheme.colors.onSurface

        val context = LocalContext.current
        var legalText by remember { mutableStateOf("") }

        LaunchedEffect(Unit) {
            try {
                withContext(Dispatchers.IO) {
                    legalText = context.resources.openRawResource(R.raw.legal)
                        .use { it.bufferedReader().readText() }
                }
            } catch (throwable: Throwable) {
                // Ignore
            }
        }

        AndroidView(
            factory = { TextView(it) },
            modifier = Modifier
                .padding(horizontal = 24.dp, vertical = 16.dp),
            update = {
                it.apply {
                    text = HtmlCompat.fromHtml(
                        legalText,
                        HtmlCompat.FROM_HTML_MODE_LEGACY,
                    )
                    movementMethod = LinkMovementMethod.getInstance()
                    setTextColor(onSurface.toArgb())
                    setTextIsSelectable(true)
                }
            },
        )
    }
}
