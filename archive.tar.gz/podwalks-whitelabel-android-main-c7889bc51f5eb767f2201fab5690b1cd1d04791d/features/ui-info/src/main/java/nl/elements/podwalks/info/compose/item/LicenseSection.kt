package nl.elements.podwalks.info.compose.item

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.theme.subtitle3
import nl.elements.podwalks.shared.resources.R

@Composable
fun LicenseSection(
    modifier: Modifier = Modifier,
    libraryName: String,
    libraryVersion: String,
    license: String?,
    onOpenLicense: () -> Unit,
) {
    val description = license?.let {
        stringResource(
            id = R.string.info_licenses_and_version,
            license,
            libraryVersion,
        )
    } ?: stringResource(
        id = R.string.info_app_version,
        libraryVersion,
    )

    Row(
        modifier = modifier
            .clickable(onClick = onOpenLicense)
            .semantics(mergeDescendants = true) {},
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = libraryName,
                style = MaterialTheme.typography.subtitle3,
            )

            Text(
                text = description,
                style = MaterialTheme.typography.body1,
            )
        }

        Icon(
            modifier = Modifier
                .size(24.dp)
                .padding(4.dp),
            painter = painterResource(id = R.drawable.ic_browse),
            contentDescription = stringResource(id = R.string.acc_info_licenses_share),
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFF)
@Composable
fun LicenseSectionPreview() {
    AppTheme {
        LicenseSection(
            libraryName = "Activity",
            libraryVersion = "1.10",
            license = "Apache 2.0",
            onOpenLicense = {},
        )
    }
}
