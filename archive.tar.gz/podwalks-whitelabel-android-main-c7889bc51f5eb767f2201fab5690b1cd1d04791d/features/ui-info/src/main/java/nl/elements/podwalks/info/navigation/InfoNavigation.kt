@file:Suppress("MatchingDeclarationName")

package nl.elements.podwalks.info.navigation

import android.net.Uri
import androidx.annotation.Keep
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.activity
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import kotlinx.serialization.Serializable
import nl.elements.podwalks.info.compose.InfoScreen

@Serializable
data class Info(
    val fromScreen: BackScreen,
    val podwalkId: String? = null,
)

@Keep
enum class BackScreen {
    LIST,
    DETAILS,
    WALK,
}

@Serializable
data object CallToAction

fun NavController.navigateToInfo(
    fromScreen: BackScreen,
    podwalkId: String? = null,
    navOptions: NavOptions? = null,
) = navigate(
    route = Info(
        fromScreen = fromScreen,
        podwalkId = podwalkId,
    ),
    navOptions = navOptions,
)

fun NavController.navigateToCallToAction(navOptions: NavOptions? = null) = navigate(
    route = CallToAction,
    navOptions = navOptions,
)

fun NavGraphBuilder.infoScreen(
    callToActionUrl: String,
    onCloseClicked: (route: BackScreen, podwalkId: String?) -> Unit,
    onOpenCallToAction: () -> Unit,
) {
    composable<Info> { backStackEntry ->
        val info: Info = backStackEntry.toRoute()

        InfoScreen(
            onCloseClicked = {
                onCloseClicked(info.fromScreen, info.podwalkId)
            },
            onOpenCallToAction = onOpenCallToAction,
        )
    }

    activity<CallToAction> {
        action = "android.intent.action.VIEW"
        data = Uri.parse(callToActionUrl)
    }
}
