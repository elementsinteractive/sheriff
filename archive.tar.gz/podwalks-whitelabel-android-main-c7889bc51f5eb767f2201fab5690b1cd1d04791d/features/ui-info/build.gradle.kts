import nl.elements.podwalks.PodwalkFlavor

plugins {
    id("podwalks.android.feature")
    id("dagger.hilt.android.plugin")
}

val customInfoFlavors = listOf(PodwalkFlavor.waalre, PodwalkFlavor.vrt, PodwalkFlavor.bnob, PodwalkFlavor.gelderland)

android {

    namespace = "nl.elements.podwalks.info"

    @Suppress("UnstableApiUsage")
    sourceSets {
        PodwalkFlavor.values()
            .filterNot { customInfoFlavors.contains(it) }
            .forEach {
                getByName(it.name) {
                    java.srcDirs("src/default/java")
                }
            }
    }
}

dependencies {
    implementation(project(":shared:analytics"))
    implementation(project(":shared:notifications"))

    implementation(libs.bundles.mavericks)
    implementation(libs.bundles.navigationFragment)
    implementation(libs.bundles.compose)

    implementation(libs.accompanist.drawablePainter)

    implementation(libs.mobilization.loggingApi)

    api(libs.bundles.aboutLibraries)

    implementation(libs.androidx.browser)

    debugImplementation(libs.androidx.compose.uiTooling)
    implementation(libs.androidx.compose.uiToolingPreview)

    implementation(libs.dagger.hilt.compose)
    implementation(libs.dagger.hilt.base)
    ksp(libs.dagger.hilt.compiler)
}

// VRT dependencies
dependencies {
    vrtImplementation(libs.vrt.login)
    vrtImplementation(libs.vrt.consents.core)
}

