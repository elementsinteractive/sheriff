plugins {
    id("podwalks.android.feature")
    id("dagger.hilt.android.plugin")
}

android {

    namespace = "nl.elements.podwalks.onboarding"
}

dependencies {
    implementation(project(":domain"))
    implementation(project(":shared:resources"))
    implementation(project(":shared:presentation"))
    implementation(project(":shared:notifications"))

    implementation(libs.bundles.compose)
    debugImplementation(libs.androidx.compose.uiTooling)
    implementation(libs.androidx.compose.uiToolingPreview)

    implementation(libs.dagger.hilt.base)
    implementation(libs.dagger.hilt.compose)
    ksp(libs.dagger.hilt.compiler)
}
