package nl.elements.podwalks.onboarding.compose

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import nl.elements.podwalks.onboarding.data.OnboardingPage

@Composable
@OptIn(ExperimentalFoundationApi::class)
internal fun OnboardingPager(
    modifier: Modifier,
    pagerState: PagerState,
    pagerPages: List<OnboardingPage>,
) {
    HorizontalPager(
        modifier = modifier,
        state = pagerState,
        verticalAlignment = Alignment.Top,
        key = { index -> pagerPages[index].type },
    ) { page ->
        OnboardingPageItem(
            modifier = Modifier.fillMaxSize(),
            page = pagerPages[page],
        )
    }
}
