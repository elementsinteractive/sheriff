package nl.elements.podwalks.onboarding.data

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import nl.elements.podwalks.shared.resources.R

internal data class OnboardingPage(
    val type: OnBoardingPageType,
    @DrawableRes val image: Int,
    @StringRes val heading: Int,
    @StringRes val body: Int,
    @StringRes val button: Int,
)

internal enum class OnBoardingPageType {
    ONBOARDING_1,
    ONBOARDING_2,
    ONBOARDING_3,
}

internal val onboardingPages: List<OnboardingPage>
    get() = OnBoardingPageType.values()
        .map { type ->
            OnboardingPage(
                type = type,
                image = type.imageRes,
                heading = type.headingRes,
                body = type.bodyRes,
                button = type.buttonRes,
            )
        }

private val OnBoardingPageType.imageRes: Int
    @DrawableRes
    get() = when (this) {
        OnBoardingPageType.ONBOARDING_1 -> R.drawable.onboarding_1
        OnBoardingPageType.ONBOARDING_2 -> R.drawable.onboarding_2
        OnBoardingPageType.ONBOARDING_3 -> R.drawable.onboarding_3
    }

private val OnBoardingPageType.headingRes: Int
    @StringRes
    get() = when (this) {
        OnBoardingPageType.ONBOARDING_1 -> R.string.onboarding_1_title
        OnBoardingPageType.ONBOARDING_2 -> R.string.onboarding_2_title
        OnBoardingPageType.ONBOARDING_3 -> R.string.onboarding_3_title
    }

private val OnBoardingPageType.bodyRes: Int
    @StringRes
    get() = when (this) {
        OnBoardingPageType.ONBOARDING_1 -> R.string.onboarding_1_description
        OnBoardingPageType.ONBOARDING_2 -> R.string.onboarding_2_description
        OnBoardingPageType.ONBOARDING_3 -> R.string.onboarding_3_description
    }

private val OnBoardingPageType.buttonRes: Int
    @StringRes
    get() = when (this) {
        OnBoardingPageType.ONBOARDING_3 -> R.string.onboarding_get_started_button
        else -> R.string.onboarding_next_button
    }
