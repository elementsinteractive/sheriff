package nl.elements.podwalks.onboarding.compose

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.onboarding.data.OnboardingPage
import nl.elements.podwalks.onboarding.data.onboardingPages
import nl.elements.podwalks.presentation.compose.theme.AppTheme

@Composable
internal fun OnboardingPageItem(
    modifier: Modifier = Modifier,
    page: OnboardingPage,
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .systemBarsPadding()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Image(
            modifier = Modifier
                .fillMaxWidth()
                .height(380.dp)
                .clip(RoundedCornerShape(16.dp)),
            painter = painterResource(id = page.image),
            contentDescription = null,
            contentScale = ContentScale.Crop,
        )

        Text(
            modifier = Modifier.semantics { heading() },
            text = stringResource(id = page.heading),
            style = MaterialTheme.typography.h1,
        )

        Text(
            text = stringResource(id = page.body),
            style = MaterialTheme.typography.body1,
        )
    }
}

private class OnboardingPageProvider : PreviewParameterProvider<OnboardingPage> {
    override val values: Sequence<OnboardingPage> = onboardingPages.asSequence()
}

@Preview
@Composable
internal fun OnboardingPageItemPreview(
    @PreviewParameter(OnboardingPageProvider::class) page: OnboardingPage,
) {
    AppTheme {
        Surface(color = MaterialTheme.colors.background) {
            OnboardingPageItem(
                modifier = Modifier.fillMaxSize(),
                page = page,
            )
        }
    }
}
