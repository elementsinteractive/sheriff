package nl.elements.podwalks.onboarding.compose

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.launch
import nl.elements.podwalks.onboarding.OnboardingViewModel
import nl.elements.podwalks.onboarding.data.onboardingPages
import nl.elements.podwalks.presentation.compose.StatusBar
import nl.elements.podwalks.presentation.compose.theme.AppTheme

@Composable
internal fun OnboardingScreen(
    modifier: Modifier = Modifier,
    onFinishedOnboarding: () -> Unit,
    viewModel: OnboardingViewModel = hiltViewModel(),
) {
    StatusBar(false)

    val context = LocalContext.current

    OnboardingScreen(
        modifier = modifier,
        onSelect = viewModel::onSelectPage,
        onDone = {
            viewModel.completeOnboarding(context as ComponentActivity) {
                onFinishedOnboarding()
            }
        },
    )
}

@Composable
internal fun OnboardingScreen(
    modifier: Modifier = Modifier,
    onSelect: (Int) -> Unit,
    onDone: () -> Unit,
) {
    val pagerPages = remember { onboardingPages }
    val pagerState = rememberPagerState {
        onboardingPages.size
    }
    val scope = rememberCoroutineScope()

    Surface(
        modifier = modifier,
        color = MaterialTheme.colors.background,
    ) {
        Column(Modifier.fillMaxSize().navigationBarsPadding()) {
            OnboardingPager(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                pagerState = pagerState,
                pagerPages = pagerPages,
            )

            val onClick: () -> Unit = remember {
                {
                    val nextPage = pagerState.currentPage + 1
                    if (nextPage >= pagerPages.size) {
                        onDone()
                    } else {
                        scope.launch {
                            pagerState.animateScrollToPage(nextPage)
                            onSelect(nextPage)
                        }
                    }
                }
            }

            OnboardingBottomBar(
                modifier = Modifier
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 16.dp)
                    .fillMaxWidth(),
                pages = onboardingPages,
                pagerState = pagerState,
                onButtonClick = onClick,
            )
        }
    }
}

@Preview
@Composable
internal fun OnboardingScreenPreviews() {
    AppTheme {
        OnboardingScreen(onSelect = {}, onDone = {})
    }
}
