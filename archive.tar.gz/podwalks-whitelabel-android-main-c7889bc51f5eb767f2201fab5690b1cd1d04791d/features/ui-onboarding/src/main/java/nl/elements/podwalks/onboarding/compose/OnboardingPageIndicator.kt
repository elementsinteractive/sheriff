package nl.elements.podwalks.onboarding.compose

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.theme.pagerIndicatorInactiveColor

@Composable
internal fun OnboardingPageIndicator(
    modifier: Modifier = Modifier,
    pageCount: Int,
    currentPage: Int,
    activeColor: Color = MaterialTheme.colors.primary,
    inactiveColor: Color = MaterialTheme.colors.pagerIndicatorInactiveColor,
) {
    Row(modifier = modifier) {
        repeat(pageCount) { index ->

            val targetWidth = (if (index == currentPage) 36.dp else 12.dp)

            val animatedWidth = animateDpAsState(
                targetValue = targetWidth,
                animationSpec = tween(),
                label = "Animated PageWidth for #$index",
            )

            val targetColor =
                if (index == currentPage) activeColor else inactiveColor
            val color = animateColorAsState(
                targetValue = targetColor,
                animationSpec = tween(),
                label = "Animated color for #$index",
            )

            Box(
                modifier = Modifier
                    .padding(end = if (index + 1 != pageCount) 6.dp else 0.dp)
                    .width(animatedWidth.value)
                    .height(4.dp)
                    .clip(RoundedCornerShape(100.dp))
                    .background(color.value),
            )
        }
    }
}

@Preview
@Composable
internal fun OnboardingPageIndicatorPreview() {
    AppTheme {
        OnboardingPageIndicator(
            pageCount = 3,
            currentPage = 2,
        )
    }
}
