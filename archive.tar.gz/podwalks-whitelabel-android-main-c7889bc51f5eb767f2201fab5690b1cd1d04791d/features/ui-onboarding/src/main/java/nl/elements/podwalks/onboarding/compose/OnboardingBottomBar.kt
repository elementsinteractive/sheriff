package nl.elements.podwalks.onboarding.compose

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.onboarding.data.OnboardingPage
import nl.elements.podwalks.onboarding.data.onboardingPages
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton

@Composable
@OptIn(ExperimentalFoundationApi::class)
internal fun OnboardingBottomBar(
    modifier: Modifier = Modifier,
    pages: List<OnboardingPage>,
    pagerState: PagerState,
    onButtonClick: () -> Unit,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PrimaryButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = onButtonClick,
        ) {
            Text(
                text = stringResource(id = pages[pagerState.currentPage].button),
                style = MaterialTheme.typography.button,
            )
        }

        OnboardingPageIndicator(
            pageCount = pages.size,
            currentPage = pagerState.currentPage,
        )
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
@Preview(showBackground = true, backgroundColor = 0xFFF)
internal fun BottomBarPreview() {
    AppTheme {
        OnboardingBottomBar(
            modifier = Modifier.width(800.dp),
            pages = onboardingPages,
            pagerState = rememberPagerState {
                0
            },
            onButtonClick = {},
        )
    }
}
