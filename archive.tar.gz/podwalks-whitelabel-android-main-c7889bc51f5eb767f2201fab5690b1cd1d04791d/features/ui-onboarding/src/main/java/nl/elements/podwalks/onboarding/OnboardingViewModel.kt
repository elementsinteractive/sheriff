package nl.elements.podwalks.onboarding

import androidx.activity.ComponentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsEvent.OnboardingPage
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.domain.interactors.FinishOnboarding
import nl.elements.podwalks.notifications.PushNotificationController
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val finishOnboarding: FinishOnboarding,
    private val analyticsTracker: AnalyticsTracker,
    private val notificationController: PushNotificationController,
) : ViewModel() {

    fun onSelectPage(pageIndex: Int) {
        OnboardingPage.getPageByIndex(pageIndex)?.let { pageName ->
            analyticsTracker.track(AnalyticsEvent.ScreenView("Onboarding", pageName))
        }
    }

    fun completeOnboarding(context: ComponentActivity, completion: () -> Unit) {
        viewModelScope.launch {
            if (notificationController.isPushSupported()) {
                if (notificationController.requestPushPermission(context) &&
                    notificationController.isPushPermissionGranted(context)
                ) {
                    notificationController.setPushEnabled(true)
                }
            }
            finishOnboarding()
            completion()
        }
    }
}
