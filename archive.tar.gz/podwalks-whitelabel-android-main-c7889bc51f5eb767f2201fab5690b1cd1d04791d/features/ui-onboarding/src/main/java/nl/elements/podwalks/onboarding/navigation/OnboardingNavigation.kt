@file:Suppress("MatchingDeclarationName")

package nl.elements.podwalks.onboarding.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.compose.composable
import kotlinx.serialization.Serializable
import nl.elements.podwalks.onboarding.compose.OnboardingScreen

@Serializable
data object Onboarding

fun NavController.navigateToOnboarding(
    navOptions: NavOptions? = null,
) = navigate(
    route = Onboarding,
    navOptions = navOptions,
)

fun NavGraphBuilder.onboardingScreen(
    onFinishedOnboarding: () -> Unit,
) {
    composable<Onboarding> {
        OnboardingScreen(
            onFinishedOnboarding = onFinishedOnboarding,
        )
    }
}
