import nl.elements.podwalks.PodwalkFlavor

plugins {
    id("podwalks.android.feature")
    id("dagger.hilt.android.plugin")
}

val customSplashFlavors = listOf(PodwalkFlavor.vrt)

android {
    namespace = "nl.elements.podwalks.login"

    @Suppress("UnstableApiUsage")
    sourceSets {
        PodwalkFlavor.values()
            .filterNot { customSplashFlavors.contains(it) }
            .forEach {
                getByName(it.name) {
                    java.srcDirs("src/default/java")
                }
            }
    }
}

dependencies {
    implementation(libs.bundles.mavericks)
    implementation(libs.bundles.navigationFragment)
    implementation(libs.bundles.compose)

    implementation(libs.mobilization.loggingApi)

    debugImplementation(libs.androidx.compose.uiTooling)
    implementation(libs.androidx.compose.uiToolingPreview)

    implementation(libs.dagger.hilt.compose)
    implementation(libs.dagger.hilt.base)
    ksp(libs.dagger.hilt.compiler)
}

// VRT dependencies
dependencies {
    vrtImplementation(libs.vrt.login)
}
