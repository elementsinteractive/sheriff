package nl.elements.podwalks.login.compose

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
internal fun LoginPageContent(modifier: Modifier = Modifier) {
}
