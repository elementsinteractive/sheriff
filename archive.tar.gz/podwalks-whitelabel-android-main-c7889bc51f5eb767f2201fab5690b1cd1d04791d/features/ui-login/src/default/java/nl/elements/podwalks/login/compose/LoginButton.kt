package nl.elements.podwalks.login.compose

import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.shared.resources.R

@Composable
fun LoginButton(
    modifier: Modifier = Modifier,
    onCompletion: () -> Unit,
) {
    PrimaryButton(
        modifier = modifier,
        onClick = onCompletion,
    ) {
        Text(
            text = stringResource(id = R.string.acc_onboarding_sign_in_button),
            style = MaterialTheme.typography.button,
        )
    }
}
