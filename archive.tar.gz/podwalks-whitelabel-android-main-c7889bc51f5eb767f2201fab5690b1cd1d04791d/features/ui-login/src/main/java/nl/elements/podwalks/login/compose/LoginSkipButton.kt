package nl.elements.podwalks.login.compose

import androidx.compose.foundation.border
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.sdk.ui.theme.PodwalkTheme
import nl.elements.podwalks.shared.resources.R

@Composable
fun LoginSkipButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    PrimaryButton(
        modifier = modifier
            .border(
                width = 1.dp,
                color = PodwalkTheme.colors.primary,
                shape = PodwalkTheme.shapes.primaryButton,
            ),
        colors = ButtonDefaults.buttonColors(
            backgroundColor = PodwalkTheme.colors.background,
        ),
        onClick = onClick,
    ) {
        Text(
            text = stringResource(id = R.string.acc_onboarding_skip_button),
            style = MaterialTheme.typography.button,
            color = MaterialTheme.colors.primary,
        )
    }
}
