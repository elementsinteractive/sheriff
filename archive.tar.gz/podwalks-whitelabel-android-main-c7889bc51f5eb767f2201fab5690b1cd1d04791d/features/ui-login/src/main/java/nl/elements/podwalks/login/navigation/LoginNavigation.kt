@file:Suppress("MatchingDeclarationName")

package nl.elements.podwalks.login.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.compose.composable
import kotlinx.serialization.Serializable
import nl.elements.podwalks.login.compose.LoginScreen

@Serializable
object Login

fun NavController.navigateToLogin(
    navOptions: NavOptions? = null,
) = navigate(
    route = Login,
    navOptions = navOptions,
)

fun NavGraphBuilder.loginScreen(
    onOpenOnboarding: () -> Unit,
) {
    composable<Login> {
        LoginScreen(
            onOpenOnboarding = onOpenOnboarding,
        )
    }
}
