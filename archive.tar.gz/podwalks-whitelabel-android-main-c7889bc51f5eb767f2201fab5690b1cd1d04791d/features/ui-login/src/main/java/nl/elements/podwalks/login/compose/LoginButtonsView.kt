package nl.elements.podwalks.login.compose

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
internal fun LoginButtonView(
    modifier: Modifier = Modifier,
    onCompletion: () -> Unit,
    onSkipClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .padding(horizontal = 24.dp)
            .padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        LoginButton(
            modifier = Modifier
                .fillMaxWidth(),
            onCompletion = onCompletion,
        )

        LoginSkipButton(
            modifier = Modifier
                .fillMaxWidth(),
            onClick = onSkipClick,
        )
    }
}
