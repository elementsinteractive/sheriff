package nl.elements.podwalks.login.compose

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.hilt.navigation.compose.hiltViewModel
import nl.elements.podwalks.login.LoginViewModel
import nl.elements.podwalks.presentation.compose.theme.AppTheme

@Composable
internal fun LoginScreen(
    modifier: Modifier = Modifier,
    viewModel: LoginViewModel = hiltViewModel(),
    onOpenOnboarding: () -> Unit,
) {
    LoginScreen(
        modifier = modifier,
        onCompletion = onOpenOnboarding,
        onSkipClick = onOpenOnboarding,
    )
}

@Composable
internal fun LoginScreen(
    modifier: Modifier = Modifier,
    onCompletion: () -> Unit,
    onSkipClick: () -> Unit,
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colors.background,
    ) {
        Column(Modifier.fillMaxSize().navigationBarsPadding()) {
            LoginPageContent(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
            )

            LoginButtonView(
                modifier = Modifier.fillMaxWidth(),
                onCompletion = onCompletion,
                onSkipClick = onSkipClick,
            )
        }
    }
}

@Preview
@Composable
internal fun LoginScreenPreviews() {
    AppTheme {
        LoginScreen(onCompletion = {}, onSkipClick = {})
    }
}
