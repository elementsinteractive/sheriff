package nl.elements.podwalks.login.compose

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import be.vrt.login.core.model.Result
import be.vrt.login.ui.VrtLoginActivity
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.shared.resources.R

@Composable
fun LoginButton(
    modifier: Modifier = Modifier,
    onCompletion: () -> Unit,
) {
    val context = LocalContext.current
    val launcher =
        rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { activityResult ->
            val resultCode = activityResult.resultCode
            val data = activityResult.data
            if (resultCode == Activity.RESULT_OK && data != null) {
                val result: Result? = data.getParcelableExtra<Result>(VrtLoginActivity.EXTRA_RESULT)

                if (result is Result.LoginComplete) {
                    onCompletion()
                }
            }
        }

    val onLoginClick: () -> Unit = {
        launcher.launch(VrtLoginActivity.startIntent(context))
    }

    PrimaryButton(
        modifier = modifier,
        onClick = onLoginClick,
    ) {
        Text(
            text = stringResource(id = R.string.acc_onboarding_sign_in_button),
            style = MaterialTheme.typography.button,
        )
    }
}
