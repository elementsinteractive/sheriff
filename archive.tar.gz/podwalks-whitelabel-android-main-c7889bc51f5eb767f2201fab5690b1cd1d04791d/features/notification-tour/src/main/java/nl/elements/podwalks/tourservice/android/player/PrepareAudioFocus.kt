package nl.elements.podwalks.tourservice.android.player

import android.media.AudioManager
import androidx.media3.common.util.UnstableApi

@UnstableApi
internal fun ExoTrackAudioPlayer.prepareAudioFocus(): Boolean {
    val result = audioManager.requestAudioFocus(focusRequest)

    synchronized(focusLock) {
        return when (result) {
            AudioManager.AUDIOFOCUS_REQUEST_FAILED -> false
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> true

            AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> {
                playbackDelayed = true
                false
            }

            else -> false
        }
    }
}
