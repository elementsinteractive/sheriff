package nl.elements.podwalks.tourservice.android.player

import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import nl.elements.podwalks.tourservice.android.player.PlayerConstants.BACKGROUND_TRACK_MEDIA_ID

@UnstableApi
class PodwalksPlayer(val exoPlayer: ExoPlayer) : Player by exoPlayer {
    override fun getDuration(): Long {
        return if (currentMediaItem?.mediaId == BACKGROUND_TRACK_MEDIA_ID) {
            C.TIME_UNSET
        } else {
            exoPlayer.duration
        }
    }

    override fun getAvailableCommands(): Player.Commands = exoPlayer.availableCommands.buildUpon()
        .removeAll(
            Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
            Player.COMMAND_SEEK_TO_PREVIOUS,
            Player.COMMAND_SEEK_TO_NEXT,
            Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
        )
        .build()
}
