package nl.elements.podwalks.tourservice.android.player

import nl.elements.podwalks.tourservice.android.player.PlayerConstants.NARRATOR_TRACK_MEDIA_ID_PREFIX

object PlayerConstants {

    const val BACKGROUND_TRACK_MEDIA_ID = "background_track"
    const val NARRATOR_TRACK_MEDIA_ID_PREFIX = "narrator_track_"

    const val PROGRESS_DELAY = 400L
}

fun createNarratorTrackMediaId(index: Int) = "$NARRATOR_TRACK_MEDIA_ID_PREFIX$index"
fun getIndexFromMediaId(id: String) =
    id.split(NARRATOR_TRACK_MEDIA_ID_PREFIX)
        .last()
        .toInt()
