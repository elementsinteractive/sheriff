package nl.elements.podwalks.tourservice.android.player

import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import nl.elements.podwalks.domain.podwalk.PlaybackPositionChanged

@UnstableApi
internal fun ExoTrackAudioPlayer.trackPlaybackProgress() {
    scope.launch {
        while (true) {
            val playbackProgress = withContext(dispatchers.main) {
                val currentPositionInMs = player.currentPosition
                val totalDurationInMs = player.duration
                currentPositionInMs to totalDurationInMs
            }

            if (playbackProgress.second != C.TIME_UNSET) {
                mutablePlaybackPosition.value = (
                    PlaybackPositionChanged(
                        positionInMs = playbackProgress.first,
                        durationInMs = playbackProgress.second,
                    )
                    )
            }

            delay(PlayerConstants.PROGRESS_DELAY)
        }
    }
}
