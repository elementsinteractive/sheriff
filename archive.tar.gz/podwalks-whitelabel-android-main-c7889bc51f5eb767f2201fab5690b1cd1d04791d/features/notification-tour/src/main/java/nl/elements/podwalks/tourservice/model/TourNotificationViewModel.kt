package nl.elements.podwalks.tourservice.model

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import nl.elements.podwalks.tourservice.model.TourNotificationState.Paused
import nl.elements.podwalks.tourservice.model.TourNotificationState.PlayBackgroundAudio
import nl.elements.podwalks.tourservice.model.TourNotificationState.SetupBackgroundAudio
import nl.elements.podwalks.tourservice.model.TourNotificationState.Stopped
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TourNotificationViewModel @Inject constructor(
    @ApplicationContext val context: Context,
) {
    private val stateFlow = MutableStateFlow<TourNotificationState>(TourNotificationState.Unitialized)
    val state: SharedFlow<TourNotificationState>
        get() = stateFlow

    suspend fun onStop() {
        stateFlow.emit(Stopped)
    }

    suspend fun onPlayBackground(source: String) {
        stateFlow.emit(SetupBackgroundAudio(source))
    }

    suspend fun onPlayPause() {
        if (stateFlow.value is Paused) {
            stateFlow.emit(PlayBackgroundAudio)
        } else {
            stateFlow.emit(Paused)
        }
    }
}
