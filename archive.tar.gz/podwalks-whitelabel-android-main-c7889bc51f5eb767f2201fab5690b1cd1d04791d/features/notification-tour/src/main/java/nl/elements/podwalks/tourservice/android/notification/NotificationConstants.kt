package nl.elements.podwalks.tourservice.android.notification

object NotificationConstants {
    const val NOTIFICATION_ID = 9000
    const val CHANNEL_ID = "tour_guide_location_notification"
}
