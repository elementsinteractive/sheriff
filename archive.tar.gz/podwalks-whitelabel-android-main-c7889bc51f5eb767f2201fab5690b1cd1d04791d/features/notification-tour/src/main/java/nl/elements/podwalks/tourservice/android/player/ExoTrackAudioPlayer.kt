package nl.elements.podwalks.tourservice.android.player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.annotation.RequiresApi
import androidx.core.net.toUri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.domain.podwalk.DownloadStatus
import nl.elements.podwalks.domain.podwalk.PlaybackPositionChanged
import nl.elements.podwalks.domain.podwalk.PodwalkGuide
import nl.elements.podwalks.domain.podwalk.TrackAudioPlayer
import nl.elements.podwalks.domain.podwalk.TrackAudioPlayerEvent
import nl.elements.podwalks.tourservice.android.player.PlayerConstants.BACKGROUND_TRACK_MEDIA_ID
import nl.elements.podwalks.tourservice.android.player.PlayerConstants.NARRATOR_TRACK_MEDIA_ID_PREFIX
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject

@UnstableApi
class ExoTrackAudioPlayer @Inject constructor(
    private val logger: Logger,
    @ApplicationContext private val context: Context,
    internal val dispatchers: AppCoroutineDispatchers,
) : TrackAudioPlayer, AudioManager.OnAudioFocusChangeListener {

    internal val scope = CoroutineScope(Dispatchers.Default)

    internal val player = PodwalksPlayer(
        ExoPlayer
            .Builder(context)
            .build(),
    )

    override val mediaSession = MediaSession.Builder(context, player)
        .build()

    internal val mutablePlaybackPosition = MutableStateFlow(PlaybackPositionChanged(0, 0))
    override val playbackPosition: StateFlow<PlaybackPositionChanged>
        get() = mutablePlaybackPosition

    private val _playbackEvent = MutableSharedFlow<TrackAudioPlayerEvent>()
    override val playbackEvent: SharedFlow<TrackAudioPlayerEvent>
        get() = _playbackEvent

    internal val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    internal val focusLock = Any()

    internal var playbackDelayed = false
    private var resumeOnFocusGain = false
    private val handler = Handler(Looper.getMainLooper())

    @RequiresApi(Build.VERSION_CODES.O)
    internal val focusRequest =
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).run {
            setAudioAttributes(
                AudioAttributes.Builder().run {
                    setUsage(AudioAttributes.USAGE_MEDIA)
                    setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    build()
                },
            )
            setAcceptsDelayedFocusGain(true)
            setOnAudioFocusChangeListener(this@ExoTrackAudioPlayer, handler)
            build()
        }

    private val eventsListener = object : Player.Listener {

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            scope.launch {
                _playbackEvent.emit(TrackAudioPlayerEvent.IsPlaying(isPlaying))
            }
            super.onIsPlayingChanged(isPlaying)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            super.onMediaItemTransition(mediaItem, reason)

            logger.i("ExoPlayer MediaItem changed ${mediaItem?.mediaId}.")

            if (mediaItem == null) {
                return
            }

            when {
                mediaItem.mediaId.startsWith(NARRATOR_TRACK_MEDIA_ID_PREFIX) -> {
                    // Set the repeat mode to ALL to make the player continue to the background
                    // track once the narrator track has finished playing
                    player.repeatMode = Player.REPEAT_MODE_ALL

                    scope.launch {
                        logger.i("Emitting narrator track playing event.")
                        val index = getIndexFromMediaId(mediaItem.mediaId)
                        _playbackEvent.emit(TrackAudioPlayerEvent.NarratorTrackPlaying(index))
                    }
                }

                mediaItem.mediaId == BACKGROUND_TRACK_MEDIA_ID -> {
                    // Set the repeat mode to ONE to make the player loop the background track
                    player.repeatMode = Player.REPEAT_MODE_ONE

                    scope.launch {
                        logger.i("Emitting background track playing event.")
                        _playbackEvent.emit(TrackAudioPlayerEvent.BackgroundTrackPlaying)
                    }
                }

                else -> logger.w("Unknown media ID was found: ${mediaItem.mediaId}.")
            }
        }
    }

    override fun playWhenReady(): Boolean = player.playWhenReady

    override fun onAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_GAIN ->
                if (playbackDelayed || resumeOnFocusGain) {
                    synchronized(focusLock) {
                        playbackDelayed = false
                        resumeOnFocusGain = false
                    }
                    play()
                }

            AudioManager.AUDIOFOCUS_LOSS -> {
                synchronized(focusLock) {
                    resumeOnFocusGain = false
                    playbackDelayed = false
                }
                pause()
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                synchronized(focusLock) {
                    // only resume if playback is being interrupted
                    resumeOnFocusGain = player.isPlaying
                    playbackDelayed = false
                }
                pause()
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                pause()
            }
        }
    }

    private var currentListener: Player.Listener? = null

    @UnstableApi
    @Suppress("LongMethod")
    override fun setup(podwalkGuide: PodwalkGuide) {
        player.addListener(eventsListener)
        player.clearMediaItems()

        val tmpListener = currentListener
        if (tmpListener != null) {
            player.removeListener(tmpListener)
        }

        val podwalk = podwalkGuide.podwalk
        val checkpoints = podwalkGuide.checkpoints
        val progress = podwalkGuide.progress

        val newListener = object : Player.Listener {

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int,
            ) {
                super.onPositionDiscontinuity(oldPosition, newPosition, reason)

                val mediaItemId = oldPosition.mediaItem?.mediaId ?: return
                val isNarratorTrack = mediaItemId.startsWith(NARRATOR_TRACK_MEDIA_ID_PREFIX)

                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION && isNarratorTrack) {
                    val trackIndex = getIndexFromMediaId(mediaItemId)

                    scope.launch {
                        _playbackEvent.emit(TrackAudioPlayerEvent.NarratorTrackPlayed(trackIndex, checkpoints.size))
                    }

                    if (trackIndex + 1 == checkpoints.size) {
                        // We've reach the last narrator track (and thus the end of the tour)
                        scope.launch {
                            _playbackEvent.emit(TrackAudioPlayerEvent.LastNarratorTrackPlayed)
                        }
                    }
                }
            }
        }

        currentListener = newListener

        // Listen for playback events
        player.addListener(newListener)

        val metaDataBuilder = MediaMetadata.Builder().apply {
            setArtworkUri(podwalk.images.first().url.value.toUri())
            setArtist(podwalk.name.value)
        }

        val backgroundTrack = podwalk.backgroundTrack
        val backgroundTrackDownloadStatus = backgroundTrack.downloadStatus
        val backgroundItem = if (backgroundTrackDownloadStatus is DownloadStatus.Downloaded) {
            MediaItem.Builder()
                .setUri(backgroundTrackDownloadStatus.result.file.toUri())
                .setMediaId(BACKGROUND_TRACK_MEDIA_ID)
                .setMediaMetadata(metaDataBuilder.build())
                .build()
        } else {
            null
        }

        for ((i, checkpoint) in checkpoints.withIndex()) {
            val track = checkpoint.track
            val checkpointTrackDownloadStatus = track.downloadStatus
            val narratorItem = if (checkpointTrackDownloadStatus is DownloadStatus.Downloaded) {
                MediaItem.Builder()
                    .setUri(checkpointTrackDownloadStatus.result.file.toUri())
                    .setMediaId(createNarratorTrackMediaId(i))
                    .setMediaMetadata(metaDataBuilder.setTitle(checkpoint.name.value).build())
                    .build()
            } else {
                null
            }

            if (narratorItem != null) {
                player.addMediaItem(narratorItem)
            }

            if (backgroundItem != null) {
                player.addMediaItem(backgroundItem)
            }
        }

        val canPlayNow = prepareAudioFocus()

        val indexOfNextCheckpoint = checkpoints.indexOf(progress.nextCheckpoint)

        // Nothing visited yet, i.e. indexOfNextCheckpoint is 0, play background track at index 1
        // Some visited, e.g. indexOfNextCheckpoint is 1, play background track at index 3
        // Last point visited, i.e. progress.nextCheckpoint == null, play the last background track
        val trackIndex = if (progress.nextCheckpoint != null) {
            if (indexOfNextCheckpoint != 0) {
                indexOfNextCheckpoint * 2 + 1
            } else {
                1
            }
        } else {
            player.mediaItemCount - 1
        }

        player.seekTo(trackIndex, 0)
        if (canPlayNow) {
            prepareAndPlay()
        } else {
            player.prepare()
        }

        trackPlaybackProgress()
    }

    override fun teardown() {
        player.release()
        mediaSession.release()
    }

    override fun play() = player.play()

    override fun pause() = player.pause()

    override fun seek(position: Float) {
        if (player.currentMediaItem?.mediaId == BACKGROUND_TRACK_MEDIA_ID) {
            // Don't allow seeking for background tracks
            return
        }

        val totalDurationInMs = player.duration
        val seekTimeInMs = (totalDurationInMs * position).toLong()

        player.seekTo(seekTimeInMs)

        val currentPosition = player.currentPosition

        scope.launch {
            mutablePlaybackPosition.value = PlaybackPositionChanged(currentPosition, totalDurationInMs)
            _playbackEvent.emit(TrackAudioPlayerEvent.SeekingDone)
        }
    }

    override fun playNextNarratorTrack(index: Int) {
        /**
         * The index of the narrator track in the ExoPlayer playlist needs to be
         * retrieved with a formula. This is because in between each checkpoint there's
         * a background track that's ready to be looped.
         *
         * The beginning of the playlist looks something like this:
         * 0 -> narrator track for checkpoint with index 0
         * 1 -> background track
         * 2 -> narrator track for checkpoint with index 1
         * 3 -> background track
         * 4 -> narrator track for checkpoint with index 2
         */
        val indexInPlaylist = index * 2

        // Seek to the narrator track and play it
        player.seekTo(indexInPlaylist, 0)
        prepareAndPlay()
    }

    private fun prepareAndPlay() {
        player.prepare()
        player.play()
    }
}
