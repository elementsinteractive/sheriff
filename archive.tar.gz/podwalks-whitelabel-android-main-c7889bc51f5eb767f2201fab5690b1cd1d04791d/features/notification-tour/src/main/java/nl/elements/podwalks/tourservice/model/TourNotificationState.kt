package nl.elements.podwalks.tourservice.model

sealed class TourNotificationState {
    object Unitialized : TourNotificationState()
    object Stopped : TourNotificationState()
    object Paused : TourNotificationState()

    data class SetupBackgroundAudio(val source: String) : TourNotificationState()
    object PlayBackgroundAudio : TourNotificationState()
}
