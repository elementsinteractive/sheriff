plugins {
    id("podwalks.android.library")
    id("dagger.hilt.android.plugin")
    id("podwalks.sdk")
    id("podwalks.android.library.flavors")
    id("podwalks.android.library.compose")
}

android {

    namespace = "nl.elements.podwalks.tourservice"
}

dependencies {
    implementation(project(":domain"))
    implementation(project(":shared:utils"))
    implementation(project(":shared:presentation"))
    implementation(project(":shared:resources"))

    implementation(libs.bundles.mavericks)
    implementation(libs.bundles.navigationFragment)
    implementation(libs.bundles.compose)

    implementation(libs.bundles.androidxMedia)

    implementation(libs.dagger.hilt.compose)
    implementation(libs.dagger.hilt.base)

    implementation(libs.mobilization.loggingApi)
    ksp(libs.dagger.hilt.compiler)
}
