import nl.elements.podwalks.PodwalkFlavor
import nl.elements.podwalks.configureVariants

plugins {
    id("podwalks.android.feature")
    id("dagger.hilt.android.plugin")
    id("kotlin-parcelize")
}

val customFlavors = listOf(PodwalkFlavor.waalre)

android {

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        namespace = "nl.elements.podwalks.walk"

        buildConfigField("String", "region", "UNDEFINED")
    }

    productFlavors {
        PodwalkFlavor.values().forEach { flavor ->
            getByName(flavor.name) {
                buildConfigField("String", "region", "\"" + flavor.mapRegion + "\"")
            }
        }
    }

    @Suppress("UnstableApiUsage")
    sourceSets {
        PodwalkFlavor.values()
            .filterNot { customFlavors.contains(it) }
            .forEach {
                getByName(it.name) {
                    java.srcDirs("src/default/java")
                }
            }
    }
}

dependencies {
    implementation(project(":domain"))
    implementation(project(":shared:utils"))
    implementation(project(":shared:maps"))
    implementation(project(":shared:presentation"))
    implementation(project(":shared:resources"))

    implementation(libs.bundles.mavericks)
    implementation(libs.bundles.navigationFragment)
    implementation(libs.bundles.compose)
    implementation(libs.bundles.maps)

    implementation(libs.mobilization.loggingApi)
    implementation(libs.accompanist.permissions)

    implementation(libs.google.location)
    implementation(libs.coroutines.playServices)

    implementation(libs.androidx.compose.uiToolingPreview)
    debugImplementation(libs.androidx.compose.uiTooling)

    implementation(libs.dagger.hilt.compose)
    implementation(libs.dagger.hilt.base)
    ksp(libs.dagger.hilt.compiler)
}

// Waalre dependencies
dependencies {
    waalreImplementation(libs.google.ar.core)
}

