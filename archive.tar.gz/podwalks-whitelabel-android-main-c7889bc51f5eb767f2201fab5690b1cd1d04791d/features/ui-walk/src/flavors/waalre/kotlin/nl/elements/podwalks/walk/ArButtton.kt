package nl.elements.podwalks.walk

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.google.ar.core.ArCoreApk
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.theme.onWarning
import nl.elements.podwalks.presentation.compose.theme.warning
import nl.elements.podwalks.presentation.constant.ShapeConstants
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.sdk.ui.theme.PodwalkTheme
import nl.elements.podwalks.shared.resources.R

@Composable
internal fun ArButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val context = LocalContext.current

    var isArSupported by remember {
        mutableStateOf<Boolean?>(null)
    }

    LaunchedEffect(null) {
        val isSupported = ArCoreApk.getInstance()
            .checkAvailability(context) == ArCoreApk.Availability.SUPPORTED_INSTALLED

        isArSupported = isSupported
    }

    if (isArSupported != null) {
        if (isArSupported == true) {
            StartARButton(
                modifier = modifier,
                onClick = onClick,
            )
        } else {
            ARUnsupportedError()
        }
    }
}

@Composable
internal fun StartARButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    PrimaryButton(
        modifier = modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(
            backgroundColor = PodwalkTheme.colors.startARButtonBackground,
        ),
        onClick = onClick,
    ) {
        Text(text = stringResource(id = R.string.walk_start_ar_button_title))
    }
}

@Composable
internal fun ARUnsupportedError(
    modifier: Modifier = Modifier,
) {
    val topCornerRadius = ShapeConstants.cardCornerRadiusInDp.dp

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(topCornerRadius),
        backgroundColor = MaterialTheme.colors.warning,
        contentColor = MaterialTheme.colors.onWarning,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(painter = painterResource(id = R.drawable.ic_warning), contentDescription = null)
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = stringResource(id = R.string.walk_start_ar_not_supported_error),
                style = MaterialTheme.typography.overline,
            )
        }
    }
}

@Preview
@Composable
internal fun StartARButtonPreview() {
    AppTheme {
        StartARButton(
            onClick = {},
        )
    }
}

@Preview
@Composable
internal fun ARUnsupportedErrorPreview() {
    AppTheme {
        ARUnsupportedError()
    }
}
