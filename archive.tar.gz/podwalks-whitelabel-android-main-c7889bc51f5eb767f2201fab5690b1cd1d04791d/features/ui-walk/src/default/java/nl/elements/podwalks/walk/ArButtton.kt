package nl.elements.podwalks.walk

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
internal fun ArButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    // No-op
}
