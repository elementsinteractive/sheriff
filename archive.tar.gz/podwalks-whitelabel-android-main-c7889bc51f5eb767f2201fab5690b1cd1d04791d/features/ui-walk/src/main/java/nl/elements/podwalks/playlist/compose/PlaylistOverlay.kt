package nl.elements.podwalks.playlist.compose

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun PlaylistOverlay(
    modifier: Modifier = Modifier,
    podwalkId: String?,
    visible: Boolean,
    onTranscriptionMode: Boolean,
    onDismissRequest: () -> Unit,
) {
    AnimatedVisibility(
        modifier = modifier,
        visible = visible,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it }),
    ) {
        PlaylistScreen(
            modifier = Modifier
                .fillMaxSize(),
            podwalkId = podwalkId,
            onTranscriptionMode = onTranscriptionMode,
            onCloseClicked = onDismissRequest,
        )
    }
}
