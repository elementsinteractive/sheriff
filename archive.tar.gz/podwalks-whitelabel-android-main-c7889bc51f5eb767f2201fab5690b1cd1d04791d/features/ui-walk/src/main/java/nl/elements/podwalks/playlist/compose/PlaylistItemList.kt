package nl.elements.podwalks.playlist.compose

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.sdk.ui.components.playlist.PlaylistRow
import nl.elements.podwalks.sdk.ui.components.playlist.PlaylistRowState
import nl.elements.podwalks.shared.resources.R

@Composable
fun BoxScope.PlaylistItemList(
    modifier: Modifier = Modifier,
    alreadyVisited: List<PlaylistRowState>,
    toVisit: List<PlaylistRowState>,
    bottomPadding: Dp,
    onTogglePlayback: (Int) -> Unit,
    onOpenTranscription: (PlaylistRowState) -> Unit,
) {
    LazyColumn(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(24.dp),
    ) {
        if (alreadyVisited.isNotEmpty()) {
            playlistItems(
                titleId = R.string.playlist_already_visited,
                items = alreadyVisited,
                onTogglePlayback = onTogglePlayback,
                onOpenTranscription = onOpenTranscription,
            )
        }

        playlistItems(
            titleId = R.string.playlist_to_visit,
            items = toVisit,
            onTogglePlayback = onTogglePlayback,
            onOpenTranscription = onOpenTranscription,
        )

        item {
            Spacer(modifier = Modifier.height(bottomPadding))
        }
    }
}

private fun LazyListScope.playlistItems(
    modifier: Modifier = Modifier,
    @StringRes titleId: Int,
    items: List<PlaylistRowState>,
    onTogglePlayback: (Int) -> Unit,
    onOpenTranscription: (PlaylistRowState) -> Unit,
) {
    item {
        Text(
            modifier = modifier,
            text = stringResource(id = titleId),
            style = MaterialTheme.typography.subtitle2,
        )
    }
    items(
        items = items,
        key = { it.chapterIndex },
    ) { row ->
        PlaylistRow(
            modifier = Modifier.fillMaxWidth(),
            state = row,
            onTogglePlayback = { onTogglePlayback(row.chapterIndex) },
            onOpenTranscription = { onOpenTranscription(row) },
        )
    }
}
