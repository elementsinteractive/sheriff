package nl.elements.podwalks.playlist.compose

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.popup
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.airbnb.mvrx.compose.collectAsState
import com.airbnb.mvrx.compose.mavericksViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import nl.elements.podwalks.playlist.compose.PlaylistViewEvent.AudioPlayer
import nl.elements.podwalks.playlist.compose.PlaylistViewEvent.ItemTogglePlayback
import nl.elements.podwalks.playlist.compose.PlaylistViewEvent.Setup
import nl.elements.podwalks.playlist.compose.PlaylistViewEvent.Transcription
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.components.player.AudioPlayer
import nl.elements.podwalks.sdk.ui.components.player.AudioPlayerPlaybackState
import nl.elements.podwalks.sdk.ui.components.player.AudioPlayerState
import nl.elements.podwalks.sdk.ui.components.player.TrackDuration
import nl.elements.podwalks.sdk.ui.components.playlist.PlaylistRowState
import nl.elements.podwalks.sdk.ui.components.playlist.Selected
import nl.elements.podwalks.sdk.ui.components.playlist.VisitedState
import nl.elements.podwalks.shared.resources.R
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

@Composable
fun PlaylistScreen(
    modifier: Modifier = Modifier,
    podwalkId: String?,
    onTranscriptionMode: Boolean,
    viewModel: PlaylistViewModel = mavericksViewModel(),
    onCloseClicked: () -> Unit,
) {
    val state = viewModel.collectAsState()
    LaunchedEffect(key1 = podwalkId, key2 = onTranscriptionMode, block = {
        if (podwalkId != null) {
            viewModel.trigger(Setup(podwalkId, onTranscriptionMode))
        }
    })

    PlaylistScreen(
        modifier = modifier.semantics {
            popup()
        },
        state = state.value,
        seekDone = viewModel.seekDone,
        onEvent = viewModel::trigger,
        onCloseClicked = {
            if (onTranscriptionMode || state.value.viewMode is PlaylistViewMode.Playlist) {
                onCloseClicked()
            } else {
                viewModel.trigger(Transcription.Close)
            }
        },
    )
}

@Composable
private fun PlaylistScreen(
    modifier: Modifier,
    state: PlaylistViewState,
    seekDone: Flow<Unit>,
    onEvent: (event: PlaylistViewEvent) -> Unit,
    onCloseClicked: () -> Unit,
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colors.background,
    ) {
        Column(modifier = Modifier.systemBarsPadding()) {
            PlaylistTopBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(top = 24.dp),
                heading = when (state.viewMode) {
                    PlaylistViewMode.Playlist -> stringResource(id = R.string.playlist_title)
                    is PlaylistViewMode.Transcription -> state.viewMode.title
                },
                subHeading = state.podwalkName.orEmpty(),
                onCloseClicked = onCloseClicked,
            )

            Box() {
                val density = LocalDensity.current
                var audioPlayerHeight by remember {
                    mutableStateOf(0.dp)
                }

                PlaylistViewContent(
                    state = state,
                    audioPlayerHeight = audioPlayerHeight,
                    onEvent = onEvent,
                )

                if (state.audioPlayerState != null) {
                    AudioPlayer(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .onSizeChanged {
                                with(density) {
                                    audioPlayerHeight = it.height.toDp()
                                }
                            }
                            .fillMaxWidth(),
                        state = state.audioPlayerState,
                        seekDone = seekDone,
                        onTogglePlayback = { onEvent(AudioPlayer.PlayPause) },
                        onSeekFinished = { onEvent(AudioPlayer.SeekingDone(it)) },
                    )
                }
            }
        }
    }
}

@Composable
private fun BoxScope.PlaylistViewContent(
    state: PlaylistViewState,
    audioPlayerHeight: Dp,
    onEvent: (event: PlaylistViewEvent) -> Unit,
) {
    when (state.viewMode) {
        PlaylistViewMode.Playlist -> PlaylistItemList(
            modifier = Modifier.fillMaxSize(),
            alreadyVisited = state.visitedCheckpoints,
            toVisit = state.unvisitedCheckpoints,
            bottomPadding = audioPlayerHeight + 32.dp,
            onTogglePlayback = { onEvent(ItemTogglePlayback(it)) },
            onOpenTranscription = { onEvent(Transcription.Open(it)) },
        )

        is PlaylistViewMode.Transcription -> PlaylistTranscription(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .padding(top = 24.dp, bottom = audioPlayerHeight),
            transcription = state.viewMode.text,
        )
    }
}

@Preview()
@Composable
fun PlaylistScreenPreview() {
    AppTheme {
        PlaylistScreen(
            modifier = Modifier.fillMaxSize(),
            state = PlaylistViewState(
                audioPlayerState = AudioPlayerState.Chapter(
                    playback = AudioPlayerPlaybackState.PAUSED,
                    duration = TrackDuration(
                        elapsed = 20.seconds,
                        total = 2.minutes + 12.seconds,
                    ),
                    progress = 0.33f,
                ),
                visitedCheckpoints = listOf(
                    PlaylistRowState(
                        chapterIndex = 0,
                        chapterName = "Lorem Ipsum",
                        selected = null,
                        transcription = null,
                        visitedState = VisitedState.Visited,
                    ),
                    PlaylistRowState(
                        chapterIndex = 1,
                        chapterName = "Sed ut perspiciatis",
                        selected = Selected(true),
                        transcription = "lorem ipsum",
                        visitedState = VisitedState.Visited,
                    ),
                ),
                unvisitedCheckpoints = listOf(
                    PlaylistRowState(
                        chapterIndex = 2,
                        chapterName = "Ut enim ad minim",
                        selected = null,
                        transcription = null,
                        visitedState = VisitedState.Unvisited(true),
                    ),
                    PlaylistRowState(
                        chapterIndex = 3,
                        chapterName = "At vero eos et accusamus",
                        selected = null,
                        transcription = null,
                        visitedState = VisitedState.Unvisited(false),
                    ),
                ),
                podwalkName = "Walk Around the Office",
            ),
            seekDone = emptyFlow(),
            onEvent = {},
            onCloseClicked = {},
        )
    }
}
