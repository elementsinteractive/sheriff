plugins {
    id("podwalks.android.feature")
    id("dagger.hilt.android.plugin")
    id("kotlin-parcelize")
}

android {

    namespace = "nl.elements.podwalks.share"
}

dependencies {
    implementation(project(":shared:analytics"))

    implementation(libs.bundles.mavericks)
    implementation(libs.bundles.navigationFragment)
    implementation(libs.bundles.compose)

    debugImplementation(libs.androidx.compose.uiTooling)
    implementation(libs.androidx.compose.uiToolingPreview)

    implementation(libs.dagger.hilt.compose)
    implementation(libs.dagger.hilt.base)
    ksp(libs.dagger.hilt.compiler)
}
