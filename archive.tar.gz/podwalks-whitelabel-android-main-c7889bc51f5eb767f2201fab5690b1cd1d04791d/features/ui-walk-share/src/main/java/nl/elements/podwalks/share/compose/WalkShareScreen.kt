package nl.elements.podwalks.share.compose

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.airbnb.mvrx.compose.collectAsState
import com.airbnb.mvrx.compose.mavericksViewModel
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.intent.ShareIntents.shareWalk
import nl.elements.podwalks.share.WalkShareArguments
import nl.elements.podwalks.share.WalkShareViewModel
import nl.elements.podwalks.share.WalkShareViewState
import nl.elements.podwalks.share.compose.buttons.CloseTextButton
import nl.elements.podwalks.share.compose.buttons.ShareButton

@Composable
fun WalkShareScreen(
    modifier: Modifier = Modifier,
    podwalkId: String,
    onCloseClick: () -> Unit,
    viewModel: WalkShareViewModel = mavericksViewModel(
        argsFactory = {
            WalkShareArguments(podwalkId)
        },
    ),
) {
    val context = LocalContext.current
    val state by viewModel.collectAsState()

    LaunchedEffect(null) {
        viewModel.setup()
    }

    BackHandler {
        viewModel.stopTour()
        onCloseClick()
    }

    WalkShareScreen(
        modifier = modifier,
        state = state,
        onCloseClick = {
            viewModel.stopTour()
            onCloseClick()
        },
        onShareClick = {
            val content = state.content
            if (content !== null) {
                context.shareWalk(content)
            }

            viewModel.shareWalk()
        },
    )
}

@Composable
fun WalkShareScreen(
    modifier: Modifier = Modifier,
    state: WalkShareViewState,
    onCloseClick: () -> Unit,
    onShareClick: () -> Unit,
) {
    Surface(
        modifier = modifier.navigationBarsPadding(),
        color = MaterialTheme.colors.background,
    ) {
        if (state.image != null && state.body != null) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                WalkShareHeader(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(305.dp),
                    backgroundImageUrl = state.image,
                    onCloseClick = onCloseClick,
                )

                WalkShareMessageView(
                    modifier = Modifier
                        .padding(horizontal = 24.dp, vertical = 32.dp),
                    description = state.body,
                )

                Spacer(modifier = Modifier.weight(1f))

                Column(
                    modifier = Modifier
                        .padding(horizontal = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    ShareButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onShareClick,
                    )

                    CloseTextButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onCloseClick,
                    )
                }
            }
        }
    }
}

@Preview
@Composable
fun WalkShareScreenPreviews() {
    AppTheme {
        WalkShareScreen(
            state = WalkShareViewState(
                podwalkId = "1",
                image = "",
                body = """
                        You finished the Podwalk.
                        Now you know all about Amsterdam and understand how we still benefit from the hard work done in the Golden Ages.
                """.trimIndent(),
            ),
            onCloseClick = {},
            onShareClick = {},
        )
    }
}
