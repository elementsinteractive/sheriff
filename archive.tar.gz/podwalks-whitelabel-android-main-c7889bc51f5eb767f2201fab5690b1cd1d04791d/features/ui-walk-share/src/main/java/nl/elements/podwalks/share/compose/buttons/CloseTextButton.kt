package nl.elements.podwalks.share.compose.buttons

import androidx.compose.material.ButtonDefaults
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import nl.elements.podwalks.shared.resources.R

@Composable
fun CloseTextButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    TextButton(
        modifier = modifier,
        onClick = onClick,
        colors = ButtonDefaults.textButtonColors(
            contentColor = MaterialTheme.colors.onSurface,
        ),
    ) {
        Text(
            text = stringResource(R.string.walk_share_close),
            style = MaterialTheme.typography.button,
        )
    }
}
