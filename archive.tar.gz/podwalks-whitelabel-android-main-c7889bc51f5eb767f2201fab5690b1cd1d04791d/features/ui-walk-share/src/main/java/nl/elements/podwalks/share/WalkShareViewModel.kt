package nl.elements.podwalks.share

import com.airbnb.mvrx.MavericksViewModel
import com.airbnb.mvrx.MavericksViewModelFactory
import com.airbnb.mvrx.hilt.AssistedViewModelFactory
import com.airbnb.mvrx.hilt.hiltMavericksViewModelFactory
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.domain.interactors.touring.effects.StopTour
import nl.elements.podwalks.domain.podwalk.GetPodwalkById
import nl.elements.podwalks.domain.podwalk.Id

class WalkShareViewModel @AssistedInject constructor(
    @Assisted initialState: WalkShareViewState,
    private val getPodwalkById: GetPodwalkById,
    private val analyticsTracker: AnalyticsTracker,
    private val stopTourInteractor: StopTour,
) : MavericksViewModel<WalkShareViewState>(initialState) {
    private val podwalkId = initialState.podwalkId

    fun setup() {
        viewModelScope.launch {
            collectPodwalk()
        }
    }

    fun stopTour() {
        viewModelScope.launch {
            stopTourInteractor()
        }
    }

    private fun CoroutineScope.collectPodwalk() = launch {
        getPodwalkById.get(Id(podwalkId))
            .filterNotNull()
            .collectLatest { podwalk ->
                setState {
                    copy(
                        image = podwalk.images.first().url.value,
                        body = podwalk.share.invitationText,
                        content = podwalk.share.content,
                        name = podwalk.name.value,
                    )
                }
            }
    }

    fun shareWalk() = withState { state ->
        analyticsTracker.track(AnalyticsEvent.SharePodwalk(state.name ?: ""))
    }

    @AssistedFactory
    interface Factory : AssistedViewModelFactory<WalkShareViewModel, WalkShareViewState> {
        override fun create(state: WalkShareViewState): WalkShareViewModel
    }

    companion object : MavericksViewModelFactory<WalkShareViewModel, WalkShareViewState>
    by hiltMavericksViewModelFactory()
}
