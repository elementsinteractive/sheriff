package nl.elements.podwalks.share

object WalkShareConstants {
    const val SHARE_WALK_TYPE = "text/plain"
}
