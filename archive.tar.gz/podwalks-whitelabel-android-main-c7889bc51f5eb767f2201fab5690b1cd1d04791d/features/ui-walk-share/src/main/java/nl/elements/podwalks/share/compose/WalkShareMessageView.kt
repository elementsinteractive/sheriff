package nl.elements.podwalks.share.compose

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.shared.resources.R

@Composable
fun WalkShareMessageView(
    modifier: Modifier = Modifier,
    description: String,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = stringResource(id = R.string.walk_share_congratulation),
            style = MaterialTheme.typography.subtitle1,
        )

        Text(
            text = description,
            style = MaterialTheme.typography.body1,
            textAlign = TextAlign.Center,
        )
    }
}
