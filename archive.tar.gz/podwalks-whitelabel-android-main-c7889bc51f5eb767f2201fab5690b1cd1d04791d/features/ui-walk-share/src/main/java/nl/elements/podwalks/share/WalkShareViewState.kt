package nl.elements.podwalks.share

import android.os.Parcelable
import com.airbnb.mvrx.MavericksState
import kotlinx.parcelize.Parcelize

data class WalkShareViewState(
    val podwalkId: String,
    val image: String? = null,
    val body: String? = null,
    val content: String? = null,
    val name: String? = null,
) : MavericksState {
    constructor(args: WalkShareArguments) : this(args.podwalkId)
}

@Parcelize
data class WalkShareArguments(
    val podwalkId: String,
) : Parcelable
