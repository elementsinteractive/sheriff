package nl.elements.podwalks.share.compose.buttons

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.shared.resources.R

@Composable
fun ShareButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    PrimaryButton(
        modifier = modifier,
        onClick = onClick,
    ) {
        val painter = painterResource(id = R.drawable.ic_share)
        Icon(painter = painter, contentDescription = null)

        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text = stringResource(R.string.walk_share_button_title),
            style = MaterialTheme.typography.button,
        )
    }
}

@Preview
@Composable
fun ShareButtonPreview() {
    AppTheme {
        ShareButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {},
        )
    }
}
