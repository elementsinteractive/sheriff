package nl.elements.podwalks.share.compose

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import nl.elements.podwalks.presentation.constant.MarginConstants
import nl.elements.podwalks.sdk.ui.components.buttons.CloseButton
import nl.elements.podwalks.shared.resources.R

@Composable
fun WalkShareHeader(
    modifier: Modifier = Modifier,
    backgroundImageUrl: String,
    onCloseClick: () -> Unit,
) {
    val buttonEdgeMargin = MarginConstants.cornerButtonEdgeMarginInDp.dp

    Box(modifier) {
        AsyncImage(
            modifier = Modifier
                .fillMaxSize(),
            model = ImageRequest.Builder(LocalContext.current)
                .data(backgroundImageUrl)
                .crossfade(true)
                .build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
        )

        CloseButton(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(
                    end = buttonEdgeMargin,
                    top = buttonEdgeMargin,
                ),
            contentDescription = stringResource(id = R.string.acc_navigation_close_button),
            onClick = onCloseClick,
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFF, heightDp = 305)
@Composable
fun WalkShareHeaderPreviews() {
    WalkShareHeader(
        backgroundImageUrl = "",
        onCloseClick = {},
    )
}
