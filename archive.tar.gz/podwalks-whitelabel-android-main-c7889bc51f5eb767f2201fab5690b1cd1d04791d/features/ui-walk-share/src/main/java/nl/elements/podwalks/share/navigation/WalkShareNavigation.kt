@file:Suppress("MatchingDeclarationName")

package nl.elements.podwalks.share.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import kotlinx.serialization.Serializable
import nl.elements.podwalks.share.compose.WalkShareScreen

@Serializable
data class WalkShare(
    val podwalkId: String,
)

fun NavController.navigateToWalkShare(
    podwalkId: String,
    navOptions: NavOptions? = null,
) = navigate(
    route = WalkShare(podwalkId),
    navOptions = navOptions,
)

fun NavGraphBuilder.walkShareScreen(
    onCloseClick: (podwalkId: String) -> Unit,
) {
    composable<WalkShare> { backStackEntry ->
        val walkShare: WalkShare = backStackEntry.toRoute()

        WalkShareScreen(
            podwalkId = walkShare.podwalkId,
            onCloseClick = {
                onCloseClick(walkShare.podwalkId)
            },
        )
    }
}
