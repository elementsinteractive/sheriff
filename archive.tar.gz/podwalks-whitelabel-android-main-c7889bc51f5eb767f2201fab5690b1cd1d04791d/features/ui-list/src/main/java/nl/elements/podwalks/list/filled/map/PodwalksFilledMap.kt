package nl.elements.podwalks.list.filled.map

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment.Companion.BottomCenter
import androidx.compose.ui.Alignment.Companion.BottomStart
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.google.maps.android.compose.GoogleMap
import nl.elements.podwalks.list.ListSeasonClick
import nl.elements.podwalks.list.filled.components.SwitchButton
import nl.elements.podwalks.list.item.ListMapGroup
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.seasons.ListSeasonsState
import nl.elements.podwalks.list.seasons.carousel.SeasonsCarousel
import nl.elements.podwalks.shared.resources.R

@Composable
@Suppress("MagicNumber")
fun PodwalksFilledMap(
    modifier: Modifier = Modifier,
    podwalks: List<ListMapGroup>,
    onWalkClick: (ListPodwalk) -> Unit,
    onModeToggle: () -> Unit,
    seasonsState: ListSeasonsState,
    onSeasonClicked: ListSeasonClick,
) {
    var selectedId: String? by remember { mutableStateOf(null as String?) }

    Box(modifier = modifier) {
        PodwalkMap(
            modifier = Modifier.fillMaxSize(),
            groups = podwalks,
            selectedId = selectedId,
            onSelectGroup = { group ->
                selectedId = group.id
            },
        )

        SwitchButton(
            title = stringResource(id = R.string.view_list_button),
            onModeToggle = onModeToggle,
        )

        if (selectedId == null) {
            SeasonsCarousel(
                modifier = Modifier.align(BottomStart),
                seasonsState = seasonsState,
                onSeasonClicked = onSeasonClicked,
            )
        }

        selectedId?.let { id -> podwalks.firstOrNull { it.id == id } }?.let { selectedGroup ->
            MapDetail(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(BottomCenter)
                    .padding(12.dp),
                group = selectedGroup,
                onSelect = onWalkClick,
                onDismiss = { selectedId = null },
            )
        }
    }
}

@Composable
internal fun PodwalkMap(
    modifier: Modifier = Modifier,
    groups: List<ListMapGroup>,
    selectedId: String?,
    onSelectGroup: (ListMapGroup) -> Unit,
    // hasLocationAccess: Boolean,
) {
    var mapProperties by remember {
        mutableStateOf(defaultMapProperties)
    }

    val cameraPosition = rememberPodwalkMapCameraPosition()

    GoogleMap(
        modifier = modifier,
        cameraPositionState = cameraPosition,
        properties = mapProperties,
        uiSettings = mapUiSettings,
    ) {
        MapMarkers(
            groups = groups,
            selectedId = selectedId,
            onSelect = onSelectGroup,
        )
    }
}
