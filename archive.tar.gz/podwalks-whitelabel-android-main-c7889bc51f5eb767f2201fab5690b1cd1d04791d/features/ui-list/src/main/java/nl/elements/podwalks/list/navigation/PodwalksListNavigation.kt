@file:Suppress("MatchingDeclarationName")

package nl.elements.podwalks.list.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.compose.composable
import kotlinx.serialization.Serializable
import nl.elements.podwalks.list.PodwalksListScreen
import nl.elements.podwalks.list.item.ListPodwalk

@Serializable
data object PodwalksList

fun NavController.navigateToPodwalks(
    navOptions: NavOptions? = null,
) = navigate(
    route = PodwalksList,
    navOptions = navOptions,
)

fun NavGraphBuilder.podwalks(
    onAboutClick: () -> Unit,
    onWalkClick: (ListPodwalk) -> Unit,
) {
    composable<PodwalksList> {
        PodwalksListScreen(
            onAboutClick = onAboutClick,
            onWalkClick = onWalkClick,
        )
    }
}
