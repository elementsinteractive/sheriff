package nl.elements.podwalks.list.item

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.Icon
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.components.attributes.PodwalkLengthAttribute
import nl.elements.podwalks.sdk.ui.components.attributes.PodwalkTimeAttribute
import nl.elements.podwalks.shared.resources.R

@Composable
internal fun BottomContent(
    modifier: Modifier = Modifier,
    podwalk: ListPodwalk,
) {
    Column(
        modifier = modifier,
    ) {
        PodwalkTitle(name = podwalk.name)
        PodwalkLocationName(location = podwalk.locationName)
        Spacer(modifier = Modifier.height(8.dp))

        BottomRow(
            modifier = Modifier.fillMaxWidth(),
            podwalk = podwalk,
        )
    }
}

@Composable
private fun BottomRow(modifier: Modifier = Modifier, podwalk: ListPodwalk) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.Start,
    ) {
        PodwalkTimeAttribute(
            duration = podwalk.duration,
        )

        Spacer(modifier = Modifier.width(16.dp))

        PodwalkLengthAttribute(
            lengthInKm = podwalk.lengthInKm,
        )

        Spacer(modifier = Modifier.weight(1f))

        if (podwalk.isCompleted) {
            Icon(
                modifier = Modifier
                    .size(20.dp),
                painter = painterResource(id = R.drawable.ic_check_filled),
                contentDescription = null,
            )

            Spacer(modifier = Modifier.width(12.dp))
        }

        if (podwalk.isDownloaded) {
            AlreadyDownloadedIcon()
        } else {
            DownloadIcon()
        }
    }
}

@Preview
@Composable
internal fun BottomContentPreview(
    @PreviewParameter(ListPodwalkPreviewParameterProvider::class) podwalk: ListPodwalk,
) {
    AppTheme {
        Surface {
            BottomContent(
                modifier = Modifier.fillMaxWidth(),
                podwalk = podwalk,
            )
        }
    }
}
