package nl.elements.podwalks.list

import com.airbnb.mvrx.MavericksState
import nl.elements.podwalks.list.filled.ListType
import nl.elements.podwalks.list.item.ListMapGroup
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.seasons.ListSeasonsState
import kotlin.time.Duration

sealed class PodwalksListScreenState {

    object Loading : PodwalksListScreenState()
    object NoWalksFound : PodwalksListScreenState()
    data class WalksFound(
        val podwalks: List<ListPodwalk> = emptyList(),
        val groups: List<ListMapGroup> = emptyList(),
    ) : PodwalksListScreenState()

    object AppUpdateRequired : PodwalksListScreenState()

    override fun toString(): String {
        return when (this) {
            AppUpdateRequired, Loading, NoWalksFound -> "${this::class.simpleName}"
            is WalksFound -> super.toString()
        }
    }
}

data class PodwalksListViewState(
    val isLoading: Boolean = true,
    val didRefreshConfig: Boolean = false,
    val didManuallyRetry: Boolean = false,
    val retryDialogShown: Boolean = false,
    val listPresentationType: ListType = ListType.List,
    val screenState: PodwalksListScreenState = PodwalksListScreenState.Loading,
    val seasonsState: ListSeasonsState = ListSeasonsState(),
) : MavericksState {

    @Deprecated("Use ListPodwalk instead.")
    data class Tour(
        val id: String,
        val name: String,
        val imagePath: String,
        val locationName: String,
        val duration: Duration,
        val lengthInKm: Double,
        val isCompleted: Boolean,
        val isDownloaded: Boolean,
    )
}
