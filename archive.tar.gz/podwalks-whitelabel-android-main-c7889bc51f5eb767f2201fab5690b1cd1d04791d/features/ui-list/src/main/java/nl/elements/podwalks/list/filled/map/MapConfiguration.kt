package nl.elements.podwalks.list.filled.map

import androidx.compose.runtime.Composable
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.rememberCameraPositionState
import nl.elements.podwalks.maps.constants.MapConstants
import nl.elements.podwalks.maps.constants.MapRegion
import nl.elements.podwalks.maps.extensions.toLatLng
import nl.elements.ui_list.BuildConfig

internal val mapUiSettings
    get() = MapUiSettings(
        compassEnabled = false,
        indoorLevelPickerEnabled = false,
        mapToolbarEnabled = false,
        myLocationButtonEnabled = false,
        rotationGesturesEnabled = false,
        scrollGesturesEnabled = true,
        scrollGesturesEnabledDuringRotateOrZoom = false,
        tiltGesturesEnabled = false,
        zoomControlsEnabled = false,
        zoomGesturesEnabled = true,
    )

internal val defaultMapProperties
    get() = MapProperties(
        isBuildingEnabled = false,
        isIndoorEnabled = false,
        isMyLocationEnabled = false,
        isTrafficEnabled = false,
        latLngBoundsForCameraTarget =
        LatLngBounds(
            MapRegion.valueOf(BuildConfig.region).boundsSouthWest.toLatLng(),
            MapRegion.valueOf(BuildConfig.region).boundsNorthEast.toLatLng(),
        ),
        mapStyleOptions = null,
        mapType = MapType.NORMAL,
        maxZoomPreference = MapConstants.MAPS_MAX_ZOOM,
        minZoomPreference = MapConstants.MAPS_MIN_ZOOM,
    )

@Composable
internal fun rememberPodwalkMapCameraPosition() = rememberCameraPositionState {
    val center = MapRegion.valueOf(BuildConfig.region).center
    position = CameraPosition.fromLatLngZoom(
        LatLng(center.first, center.second),
        MapConstants.DEFAULT_MAPS_ZOOM,
    )
}
