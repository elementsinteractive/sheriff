package nl.elements.podwalks.list.seasons

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import nl.elements.podwalks.list.ListSeasonClick
import nl.elements.podwalks.list.seasons.carousel.SeasonsCarousel

@Composable
fun SeasonsSection(
    modifier: Modifier = Modifier,
    seasonsState: ListSeasonsState,
    onSeasonClicked: ListSeasonClick,
) {
    SeasonsCarousel(
        modifier = modifier,
        seasonsState = seasonsState,
        onSeasonClicked = onSeasonClicked,
    )
}
