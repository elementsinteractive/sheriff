// ktlint-disable filename
@file:Suppress("MatchingDeclarationName", "filename")

package nl.elements.podwalks.list.mapper

import nl.elements.podwalks.data.model.domain.AppVersionQualification
import nl.elements.podwalks.list.PodwalksListScreenState
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.item.groupPodwalks

internal data class ListStateMutation(
    val listScreenState: PodwalksListScreenState,
    val showRetryDialog: Boolean,
)

internal fun mapStateToViewStateMutation(
    isLoading: Boolean,
    minimumVersionCheck: AppVersionQualification,
    didRefreshConfig: Boolean,
    didManuallyRetry: Boolean,
    walks: List<ListPodwalk>,
): ListStateMutation {
    var showRetryDialog = false

    val listState = when {
        isLoading -> PodwalksListScreenState.Loading
        minimumVersionCheck == AppVersionQualification.UNKNOWN -> {
            showRetryDialog = didManuallyRetry
            PodwalksListScreenState.NoWalksFound
        }
        minimumVersionCheck == AppVersionQualification.BELOW_MINIMUM ->
            PodwalksListScreenState.AppUpdateRequired
        !didRefreshConfig && walks.isNotEmpty() -> {
            showRetryDialog = true
            PodwalksListScreenState.WalksFound(walks, groupPodwalks(walks))
        }
        walks.isEmpty() -> {
            showRetryDialog = didManuallyRetry
            PodwalksListScreenState.NoWalksFound
        }
        else -> {
            PodwalksListScreenState.WalksFound(walks, groupPodwalks(walks))
        }
    }

    return ListStateMutation(listState, showRetryDialog)
}
