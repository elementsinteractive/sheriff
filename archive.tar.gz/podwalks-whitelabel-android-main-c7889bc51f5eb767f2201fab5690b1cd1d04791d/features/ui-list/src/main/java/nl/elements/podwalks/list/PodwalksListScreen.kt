package nl.elements.podwalks.list

import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import com.airbnb.mvrx.compose.collectAsState
import com.airbnb.mvrx.compose.mavericksViewModel
import nl.elements.podwalks.list.PodwalksListScreenState.AppUpdateRequired
import nl.elements.podwalks.list.PodwalksListScreenState.Loading
import nl.elements.podwalks.list.PodwalksListScreenState.NoWalksFound
import nl.elements.podwalks.list.PodwalksListScreenState.WalksFound
import nl.elements.podwalks.list.dialog.ErrorDialog
import nl.elements.podwalks.list.empty.EmptyListContent
import nl.elements.podwalks.list.filled.ListType
import nl.elements.podwalks.list.filled.PodwalksFilled
import nl.elements.podwalks.list.intent.openGooglePlayStoreForCurrentApp
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.loading.LoadingContent
import nl.elements.podwalks.presentation.compose.events.OnLifecycleEvent
import nl.elements.podwalks.presentation.compose.topbar.DefaultTopBar
import nl.elements.podwalks.presentation.compose.updateStatusBar
import nl.elements.podwalks.shared.resources.R
import nl.elements.podwalks.update.UpdateAppScreen

@Composable
fun PodwalksListScreen(
    modifier: Modifier = Modifier,
    onAboutClick: () -> Unit,
    onWalkClick: (ListPodwalk) -> Unit,
    viewModel: PodwalksListViewModel = mavericksViewModel(),
) {
    val state by viewModel.collectAsState()

    val context = LocalContext.current as ComponentActivity

    LaunchedEffect(null) {
        viewModel.setup()
    }

    OnLifecycleEvent { owner, event ->
        when (event) {
            Lifecycle.Event.ON_START -> context.updateStatusBar(false)
            else -> {}
        }
    }

    PodwalksListScreen(
        modifier = modifier.systemBarsPadding(),
        state = state,
        onRetryClicked = viewModel::onRetryClicked,
        onUpdateClicked = {
            context.openGooglePlayStoreForCurrentApp()
        },
        onHelpClicked = onAboutClick,
        onDismissRetryDialog = viewModel::dismissRetryDialog,
        onWalkClick = onWalkClick,
        onChangeMode = viewModel::changePresentationType,
        onSeasonClick = viewModel::selectSeason,
    )
}

@Composable
internal fun PodwalksListScreen(
    modifier: Modifier = Modifier,
    state: PodwalksListViewState,
    onRetryClicked: () -> Unit,
    onUpdateClicked: () -> Unit,
    onHelpClicked: () -> Unit,
    onDismissRetryDialog: () -> Unit,
    onWalkClick: (ListPodwalk) -> Unit,
    onChangeMode: (ListType) -> Unit,
    onSeasonClick: ListSeasonClick,
) {
    Column(modifier.background(MaterialTheme.colors.background)) {
        DefaultTopBar(
            modifier = Modifier,
            titleRes = R.string.podwalks_list_title,
            onHelpClicked = onHelpClicked,
        )

        val screenState = state.screenState

        when (screenState) {
            AppUpdateRequired ->
                UpdateAppScreen(
                    modifier = Modifier.fillMaxSize(),
                    onUpdateClicked = onUpdateClicked,
                )
            Loading -> {
                LoadingContent(
                    modifier = Modifier.fillMaxSize(),
                )
            }
            NoWalksFound -> EmptyListContent(
                modifier = Modifier.fillMaxSize(),
                onRetryClicked = onRetryClicked,
            )
            is WalksFound -> PodwalksFilled(
                mode = state.listPresentationType,
                podwalks = screenState.podwalks,
                groups = screenState.groups,
                seasonsState = state.seasonsState,
                onWalkClick = onWalkClick,
                onChangeMode = onChangeMode,
                onSeasonClick = onSeasonClick,
            )
        }

        if (state.retryDialogShown) {
            ErrorDialog(
                onDismissRequest = onDismissRetryDialog,
                onRetryClicked = onRetryClicked,
            )
        }

        if (state.retryDialogShown) {
            ErrorDialog(
                onDismissRequest = onDismissRetryDialog,
                onRetryClicked = onRetryClicked,
            )
        }
    }
}
