@file:Suppress("TopLevelPropertyNaming")

package nl.elements.podwalks.list.intent

import android.content.Context
import android.content.Intent
import androidx.core.net.toUri

private const val BASE_GOOGLE_PLAY_STORE_APP_LINK = "https://play.google.com/store/apps/details?id="

internal fun createPlayStoreIntent(packageName: String): Intent =
    Intent(Intent.ACTION_VIEW)
        .apply {
            data = (BASE_GOOGLE_PLAY_STORE_APP_LINK + packageName).toUri()
        }

internal fun Context.openGooglePlayStoreForCurrentApp() {
    val playStoreIntent = createPlayStoreIntent(packageName)
    startActivity(playStoreIntent)
}
