package nl.elements.podwalks.list.item

import nl.elements.podwalks.domain.Coordinate

data class ListMapGroup(
    val id: String,
    val coordinate: Coordinate,
    val name: String,
    val podwalks: List<ListPodwalk>,
)

internal fun groupPodwalks(podwalks: List<ListPodwalk>): List<ListMapGroup> {
    val accumulator: MutableMap<Coordinate, ListMapGroup> = mutableMapOf()
    podwalks.forEach { podwalk ->
        val group = accumulator.get(podwalk.coordinate) ?: ListMapGroup(
            id = podwalk.id,
            coordinate = podwalk.coordinate,
            name = podwalk.locationName,
            podwalks = mutableListOf(),
        )
        val newList = mutableListOf(podwalk)
        newList.addAll(group.podwalks)
        accumulator.set(
            podwalk.coordinate,
            group.copy(
                podwalks = newList,
            ),
        )
    }
    return accumulator.values.toList()
}
