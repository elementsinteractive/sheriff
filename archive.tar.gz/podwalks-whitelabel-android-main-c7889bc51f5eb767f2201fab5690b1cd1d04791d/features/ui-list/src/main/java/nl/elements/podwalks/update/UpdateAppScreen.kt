package nl.elements.podwalks.update

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.theme.defaultIconTint
import nl.elements.podwalks.sdk.ui.components.buttons.PrimaryButton
import nl.elements.podwalks.shared.resources.R

@Composable
internal fun UpdateAppScreen(
    modifier: Modifier = Modifier,
    onUpdateClicked: () -> Unit,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            modifier = Modifier.size(192.dp),
            painter = painterResource(id = R.drawable.ic_update_app),
            contentDescription = null,
            tint = MaterialTheme.colors.defaultIconTint,
        )

        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = stringResource(id = R.string.update_needed_title),
            style = MaterialTheme.typography.subtitle2,
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            modifier = Modifier
                .padding(horizontal = 40.dp),
            textAlign = TextAlign.Center,
            text = stringResource(id = R.string.update_needed_description),
            style = MaterialTheme.typography.body1,
        )

        Spacer(modifier = Modifier.height(24.dp))

        PrimaryButton(
            modifier = Modifier.width(192.dp),
            onClick = onUpdateClicked,
        ) {
            Text(
                text = stringResource(id = R.string.update_button),
                style = MaterialTheme.typography.button,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Preview
@Composable
internal fun UpdatePreview() {
    AppTheme {
        Surface(color = MaterialTheme.colors.background) {
            UpdateAppScreen(
                modifier = Modifier.fillMaxSize(),
                onUpdateClicked = {},
            )
        }
    }
}
