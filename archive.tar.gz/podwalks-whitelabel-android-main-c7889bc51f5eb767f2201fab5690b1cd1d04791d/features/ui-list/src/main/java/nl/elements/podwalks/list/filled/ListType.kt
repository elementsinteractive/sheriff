package nl.elements.podwalks.list.filled

sealed class ListType {
    object List : ListType()
    object Map : ListType()
}
