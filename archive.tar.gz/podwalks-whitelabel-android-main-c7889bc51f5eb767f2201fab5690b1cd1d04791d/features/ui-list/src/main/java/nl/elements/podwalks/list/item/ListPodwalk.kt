package nl.elements.podwalks.list.item

import androidx.compose.runtime.Immutable
import nl.elements.podwalks.domain.Coordinate
import kotlin.time.Duration

@Immutable
data class ListPodwalk(
    val id: String,
    val name: String,
    val imageUrl: String,
    val locationName: String,
    val duration: Duration,
    val lengthInKm: Double,
    val isCompleted: Boolean,
    val isDownloaded: Boolean,
    val coordinate: Coordinate,
)
