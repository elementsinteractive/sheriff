// ktlint-disable filename
package nl.elements.podwalks.list

import nl.elements.podwalks.domain.podwalk.PodwalkSeason

typealias ListSeasonClick = (PodwalkSeason) -> Unit
