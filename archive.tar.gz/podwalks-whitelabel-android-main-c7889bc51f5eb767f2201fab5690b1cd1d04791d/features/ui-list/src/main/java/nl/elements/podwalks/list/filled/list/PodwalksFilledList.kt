package nl.elements.podwalks.list.filled.list

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.list.ListSeasonClick
import nl.elements.podwalks.list.filled.components.SwitchButton
import nl.elements.podwalks.list.filled.list.PodwalksFilledList.CONTENT_TYPE_LIST_HEADER
import nl.elements.podwalks.list.filled.list.PodwalksFilledList.CONTENT_TYPE_LIST_WALK
import nl.elements.podwalks.list.filled.list.PodwalksFilledList.KEY_HEADER_SEASONS
import nl.elements.podwalks.list.filled.list.PodwalksFilledList.KEY_HEADER_WALKS
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.item.PodwalkListItem
import nl.elements.podwalks.list.seasons.ListSeasonsState
import nl.elements.podwalks.list.seasons.SeasonsSection
import nl.elements.podwalks.list.sections.SectionHeader
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.shared.resources.R
import nl.elements.ui_list.BuildConfig

@Composable
@Suppress("MagicNumber")
internal fun PodwalksFilledList(
    modifier: Modifier = Modifier,
    podwalks: List<ListPodwalk>,
    onWalkClick: (ListPodwalk) -> Unit,
    onModeToggle: () -> Unit,
    seasonsState: ListSeasonsState,
    onSeasonClicked: ListSeasonClick,
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        if (BuildConfig.mapOverviewEnabled) {
            item {
                SwitchButton(
                    title = stringResource(id = R.string.view_map_button),
                    onModeToggle = onModeToggle,
                )
            }
        }

        if (seasonsState.seasons.isNotEmpty()) {
            item(
                key = KEY_HEADER_SEASONS,
                contentType = CONTENT_TYPE_LIST_HEADER,
            ) {
                SectionHeader(
                    title = stringResource(R.string.podwalks_list_seasons_title),
                )
            }

            item {
                SeasonsSection(
                    seasonsState = seasonsState,
                    onSeasonClicked = onSeasonClicked,
                )
            }
        }

        item(
            key = KEY_HEADER_WALKS,
            contentType = CONTENT_TYPE_LIST_HEADER,
        ) {
            SectionHeader(
                title = stringResource(R.string.podwalks_list_walks_title),
            )
        }

        items(
            items = podwalks,
            key = { it.id },
            contentType = {
                CONTENT_TYPE_LIST_WALK
            },
        ) { tour ->
            PodwalkListItem(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .animateItem(),
                podwalk = tour,
                onClick = { onWalkClick(tour) },
            )
        }
    }
}
object PodwalksFilledList {
    const val CONTENT_TYPE_LIST_HEADER = "header"
    const val CONTENT_TYPE_LIST_WALK = "walk"
    const val KEY_HEADER_SEASONS = "seasonsHeader"
    const val KEY_HEADER_WALKS = "walksHeader"
}

@Preview
@Composable
internal fun FullListPreview(
    @PreviewParameter(PodwalkListPreviewParameterProvider::class) podwalks: List<ListPodwalk>,
) {
    AppTheme {
        PodwalksFilledList(
            modifier = Modifier.fillMaxSize(),
            podwalks = podwalks,
            seasonsState = ListSeasonsState(),
            onWalkClick = {},
            onModeToggle = {},
            onSeasonClicked = {},
        )
    }
}
