package nl.elements.podwalks.list.item

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Card
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.sdk.ui.theme.PodwalkTheme

@OptIn(ExperimentalMaterialApi::class)
@Composable
internal fun PodwalkListItem(
    modifier: Modifier = Modifier,
    podwalk: ListPodwalk,
    onClick: () -> Unit,
) {
    Card(
        modifier = modifier.shadow(
            elevation = 8.dp,
            shape = PodwalkTheme.shapes.card,
        ),
        shape = PodwalkTheme.shapes.card,
        onClick = onClick,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clipToBounds()
                .aspectRatio(CardAspectRatio)
                .height(240.dp),
        ) {
            CompositionLocalProvider(LocalContentColor provides Color.White) {
                AsyncImage(
                    modifier = Modifier.fillMaxSize(),
                    model = podwalk.imageUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                )

                Box(
                    Modifier
                        .gradient()
                        .fillMaxSize(),
                )

                BottomContent(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp),
                    podwalk = podwalk,
                )
            }
        }
    }
}

private const val CardAspectRatio = 1.5f

private fun Modifier.gradient() = composed {
    background(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color.Transparent,
                Color.Black,
            ),
            startY = 200f,
            endY = 700f,
        ),
    )
}

@Preview
@Composable
internal fun PodwalkListItemPreview(
    @PreviewParameter(ListPodwalkPreviewParameterProvider::class) podwalk: ListPodwalk,
) {
    AppTheme {
        PodwalkListItem(
            modifier = Modifier.fillMaxWidth(),
            podwalk = podwalk,
            onClick = {},
        )
    }
}
