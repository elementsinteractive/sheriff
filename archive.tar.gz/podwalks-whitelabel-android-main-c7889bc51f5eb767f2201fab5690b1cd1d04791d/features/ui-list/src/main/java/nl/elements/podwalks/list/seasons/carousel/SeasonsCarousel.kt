package nl.elements.podwalks.list.seasons.carousel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.list.ListSeasonClick
import nl.elements.podwalks.list.seasons.ListSeasonsState

@Composable
fun SeasonsCarousel(
    modifier: Modifier = Modifier,
    seasonsState: ListSeasonsState,
    onSeasonClicked: ListSeasonClick,
) {
    if (seasonsState.seasons.isNotEmpty()) {
        LazyRow(
            modifier = modifier,
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(
                seasonsState.seasons,
                key = { it.podwalkSeason.id },
            ) { season ->
                SeasonCard(
                    season = season,
                    onClick = onSeasonClicked,
                )
            }
        }
    }
}
