package nl.elements.podwalks.list.seasons.carousel

object SeasonCardConstants {
    const val CARD_WIDTH = 219
    const val CARD_HEIGHT = 140
    const val CARD_SELECTED_BORDER_WIDTH = 3
}
