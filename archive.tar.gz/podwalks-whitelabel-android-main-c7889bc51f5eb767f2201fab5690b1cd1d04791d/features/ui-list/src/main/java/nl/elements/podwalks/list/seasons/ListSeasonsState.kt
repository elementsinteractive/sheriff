package nl.elements.podwalks.list.seasons

import nl.elements.podwalks.domain.podwalk.PodwalkSeason

data class ListSeasonsState(
    val seasons: List<ListSeason> = emptyList(),
    val selectedSeasons: Set<PodwalkSeason> = setOf(),
)

data class ListSeason(
    val podwalkSeason: PodwalkSeason,
    val selected: Boolean,
)
