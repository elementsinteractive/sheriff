package nl.elements.podwalks.list.item

import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import nl.elements.podwalks.presentation.compose.theme.AppTheme

@Composable
internal fun PodwalkTitle(
    modifier: Modifier = Modifier,
    name: String,
) {
    Text(
        modifier = modifier,
        text = name,
        style = MaterialTheme.typography.subtitle2,
    )
}

@Composable
internal fun PodwalkLocationName(
    modifier: Modifier = Modifier,
    location: String,
) {
    Text(
        modifier = modifier,
        text = location,
        style = MaterialTheme.typography.caption,
    )
}

@Preview
@Composable
internal fun PodwalkTitlePreview() {
    AppTheme {
        PodwalkTitle(name = "Prachtig Almere")
    }
}

@Preview
@Composable
internal fun PodwalkLocationNamePreview() {
    AppTheme {
        PodwalkLocationName(location = "Almere")
    }
}
