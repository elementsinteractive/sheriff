package nl.elements.podwalks.list.seasons.carousel

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.size.Size
import nl.elements.podwalks.domain.podwalk.PodwalkSeason
import nl.elements.podwalks.list.ListSeasonClick
import nl.elements.podwalks.list.seasons.ListSeason
import nl.elements.podwalks.list.seasons.carousel.SeasonCardConstants.CARD_HEIGHT
import nl.elements.podwalks.list.seasons.carousel.SeasonCardConstants.CARD_SELECTED_BORDER_WIDTH
import nl.elements.podwalks.list.seasons.carousel.SeasonCardConstants.CARD_WIDTH
import nl.elements.podwalks.presentation.compose.theme.AppTheme

@Composable
fun SeasonCard(
    modifier: Modifier = Modifier,
    season: ListSeason,
    onClick: ListSeasonClick,
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick(season.podwalkSeason) }
            .semantics(true) { }
            .seasonBorder(season.selected),
    ) {
        Box(
            modifier = Modifier
                .width(width = CARD_WIDTH.dp)
                .height(height = CARD_HEIGHT.dp),
            contentAlignment = Alignment.BottomStart,
        ) {
            AsyncImage(
                modifier = Modifier
                    .fillMaxSize(),
                model = ImageRequest.Builder(LocalContext.current)
                    .data(season.podwalkSeason.coverImageUrl)
                    .crossfade(true)
                    .size(Size.ORIGINAL)
                    .build(),
                contentDescription = null,
                contentScale = ContentScale.FillWidth,
            )

            Text(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0f),
                                Color.Black,
                            ),
                        ),
                    )
                    .padding(16.dp),
                color = Color.White,
                text = season.podwalkSeason.name,
                style = MaterialTheme.typography.overline,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun Modifier.seasonBorder(selected: Boolean): Modifier = if (selected) {
    border(CARD_SELECTED_BORDER_WIDTH.dp, MaterialTheme.colors.primary, RoundedCornerShape(16.dp))
} else {
    this
}

@Preview
@Composable
fun SeasonCardPreview() {
    AppTheme {
        val season = PodwalkSeason(
            id = "asdf",
            index = 1,
            name = "Season title",
            coverImageUrl = "",
            tourIds = emptyList(),
        )

        val listSeason = ListSeason(
            podwalkSeason = season,
            selected = false,
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            SeasonCard(
                season = listSeason,
                onClick = {},
            )

            SeasonCard(
                season = listSeason.copy(selected = true),
                onClick = {},
            )
        }
    }
}
