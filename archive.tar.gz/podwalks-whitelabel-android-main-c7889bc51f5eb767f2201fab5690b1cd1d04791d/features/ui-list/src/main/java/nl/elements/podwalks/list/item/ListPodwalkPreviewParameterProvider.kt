package nl.elements.podwalks.list.item

import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.Latitude
import nl.elements.podwalks.domain.Longitude
import kotlin.time.Duration.Companion.hours
import kotlin.time.Duration.Companion.minutes

internal class ListPodwalkPreviewParameterProvider : PreviewParameterProvider<ListPodwalk> {
    override val values: Sequence<ListPodwalk> = sequenceOf(
        ListPodwalk(
            id = "1",
            name = "Prachtig Almere",
            imageUrl = "",
            isDownloaded = false,
            locationName = "Almere Stad",
            duration = 1.hours,
            lengthInKm = 5.5,
            isCompleted = false,
            coordinate = Coordinate(Latitude(52.0), Longitude(5.0)),
        ),
        ListPodwalk(
            id = "2",
            name = "Wonderful Almere",
            imageUrl = "",
            isDownloaded = true,
            locationName = "Almere Buiten",
            duration = 2.hours,
            lengthInKm = 3.6,
            isCompleted = false,
            coordinate = Coordinate(Latitude(52.5), Longitude(5.0)),
        ),
        ListPodwalk(
            id = "3",
            name = "Beautiful Almere",
            imageUrl = "",
            isDownloaded = true,
            locationName = "Almere Poort",
            duration = 45.minutes,
            lengthInKm = 2.2,
            isCompleted = true,
            coordinate = Coordinate(Latitude(52.0), Longitude(4.5)),
        ),
    )
}
