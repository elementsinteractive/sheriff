package nl.elements.podwalks.list.filled.map

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.list.item.ListMapGroup
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.item.PodwalkListItem
import nl.elements.podwalks.sdk.ui.components.buttons.BackButton
import nl.elements.podwalks.sdk.ui.components.buttons.CloseButton
import nl.elements.podwalks.sdk.ui.components.buttons.NextButton
import nl.elements.podwalks.sdk.ui.theme.PodwalkTheme
import nl.elements.podwalks.shared.resources.R

@Composable
@Suppress("MagicNumber")
fun MapDetail(
    modifier: Modifier = Modifier,
    group: ListMapGroup,
    onSelect: (ListPodwalk) -> Unit,
    onDismiss: () -> Unit,
) {
    var selectedIndex by remember { mutableStateOf(0) }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colors.background)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            val backAlpha = if (selectedIndex <= 0) 0f else 1f
            BackButton(
                modifier = Modifier.alpha(backAlpha),
                contentDescription = stringResource(id = R.string.acc_map_previous),
                onClick = {
                    if (selectedIndex > 0) {
                        selectedIndex--
                    }
                },
            )

            if (group.podwalks.count() > 1) {
                MapDetailTicker(
                    position = selectedIndex + 1,
                    total = group.podwalks.count(),
                )
            }

            val forwardAlpha = if (selectedIndex + 1 >= group.podwalks.count()) 0f else 1f
            NextButton(
                modifier = Modifier.alpha(forwardAlpha),
                contentDescription = stringResource(id = R.string.acc_map_next),
                onClick = {
                    if (selectedIndex + 1 < group.podwalks.count()) {
                        selectedIndex++
                    }
                },
            )

            Spacer(modifier = Modifier.weight(1.0f))

            CloseButton(
                contentDescription = stringResource(R.string.acc_close_button),
                onClick = onDismiss,
            )
        }

        group.podwalks.getOrNull(selectedIndex)?.let { podwalk ->
            PodwalkListItem(
                modifier = Modifier.fillMaxWidth(),
                podwalk = podwalk,
                onClick = { onSelect(podwalk) },
            )
        }
    }
}

@Composable
@Suppress("MagicNumber")
fun MapDetailTicker(
    modifier: Modifier = Modifier,
    position: Int,
    total: Int,
) {
    Box(
        modifier = modifier
            .size(height = 48.dp, width = 96.dp)
            .clip(PodwalkTheme.shapes.iconButton)
            .background(PodwalkTheme.colors.iconButtonBackground),
    ) {
        Text(
            modifier = Modifier.align(Alignment.Center),
            text = "$position / $total",
            style = MaterialTheme.typography.button,
            textAlign = TextAlign.Center,
            color = PodwalkTheme.colors.iconButtonContent,
        )
    }
}
