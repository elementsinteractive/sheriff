package nl.elements.podwalks.list

import com.airbnb.mvrx.MavericksViewModel
import com.airbnb.mvrx.MavericksViewModelFactory
import com.airbnb.mvrx.hilt.AssistedViewModelFactory
import com.airbnb.mvrx.hilt.hiltMavericksViewModelFactory
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.domain.interactors.CheckMinimumAppVersionQualification
import nl.elements.podwalks.domain.podwalk.DefaultDeleteUnusedPodwalkFiles
import nl.elements.podwalks.domain.podwalk.GetAllPodwalkProgress
import nl.elements.podwalks.domain.podwalk.GetDownloadStates
import nl.elements.podwalks.domain.podwalk.GetPodwalks
import nl.elements.podwalks.domain.podwalk.GetSeasons
import nl.elements.podwalks.domain.podwalk.Podwalk
import nl.elements.podwalks.domain.podwalk.PodwalkSeason
import nl.elements.podwalks.domain.podwalk.SyncPodwalks
import nl.elements.podwalks.domain.podwalk.SyncRemoteConfiguration
import nl.elements.podwalks.domain.podwalk.downloaded
import nl.elements.podwalks.list.filled.ListType
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.mapper.mapStateToViewStateMutation
import nl.elements.podwalks.list.seasons.ListSeason
import nl.elements.podwalks.list.seasons.ListSeasonsState
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers

class PodwalksListViewModel @AssistedInject constructor(
    @Assisted initialState: PodwalksListViewState,
    getPodwalks: GetPodwalks,
    getAllPodwalkProgress: GetAllPodwalkProgress,
    getDownloadStates: GetDownloadStates,
    getSeasons: GetSeasons,
    private val logger: Logger,
    private val syncPodwalks: SyncPodwalks,
    private val checkMinimumVersion: CheckMinimumAppVersionQualification,
    private val syncRemoteConfiguration: SyncRemoteConfiguration,
    private val deleteUnusedPodwalkFiles: DefaultDeleteUnusedPodwalkFiles,
    private val dispatchers: AppCoroutineDispatchers,
) : MavericksViewModel<PodwalksListViewState>(initialState) {

    private val listPodwalks =
        combine(
            getPodwalks.get(),
            getAllPodwalkProgress.get(),
            getDownloadStates.get(),
            stateFlow.map { it.seasonsState },
        ) { walks, progress, downloadStates, seasonState ->
            val currentWalks = when {
                seasonState.selectedSeasons.isNotEmpty() -> {
                    val snapshot = mutableSetOf<Podwalk>()

                    seasonState.selectedSeasons.forEach { season ->
                        snapshot.addAll(
                            walks.filter { walk ->
                                season.tourIds.contains(walk.id.value)
                            },
                        )
                    }

                    snapshot.toList()
                }

                else -> walks
            }

            currentWalks.map { walk ->
                ListPodwalk(
                    id = walk.id.value,
                    name = walk.name.value,
                    imageUrl = walk.coverImage?.url?.value ?: walk.images.first().url.value,
                    locationName = walk.location.name,
                    coordinate = walk.location.coordinate,
                    duration = walk.length.duration,
                    lengthInKm = walk.length.distance.value.toDouble() / 1000,
                    isCompleted = progress[walk.id]?.completed ?: false,
                    isDownloaded = downloadStates[walk.id]?.downloaded ?: false,
                )
            }
        }

    private val seasons = getSeasons.get()

    private val podwalkRefreshExceptionHandler = CoroutineExceptionHandler { _, throwable ->
        logger.i(throwable, "Failed to refresh Podwalks.")
        setState { copy(isLoading = false) }
    }

    fun setup() {
        logger.d("SETUP")
        refreshPodwalks(false)
        collectStateChanges()
        viewModelScope.showConsentIfNeeded()
    }

    private fun refreshPodwalks(manualRetry: Boolean) {
        logger.d("Refreshing Podwalks")

        setState {
            copy(
                isLoading = true,
                retryDialogShown = false,
                didManuallyRetry = manualRetry,
            )
        }

        viewModelScope.launch(podwalkRefreshExceptionHandler) {
            syncRemoteConfiguration.sync()
            setState { copy(didRefreshConfig = true) }

            syncPodwalks.sync()

            deleteUnusedPodwalkFiles.delete()

            setState { copy(isLoading = false) }
        }
    }

    private suspend fun combineState() = combine(
        stateFlow.map { it.isLoading },
        stateFlow.map { it.didRefreshConfig },
        stateFlow.map { it.didManuallyRetry },
        checkMinimumVersion(),
        listPodwalks,
    ) { isLoading, didRefreshConfig, manualRetry, minimumVersionCheck, walks ->
        mapStateToViewStateMutation(
            isLoading,
            minimumVersionCheck,
            didRefreshConfig,
            manualRetry,
            walks,
        )
    }

    private fun collectStateChanges() {
        viewModelScope.launch {
            logger.d("Collecting state")
            combineState()
                .distinctUntilChanged()
                .collectLatest { mutation ->

                    logger.d("screenState mutation: ${mutation.listScreenState}")
                    logger.d("retryDialogShown mutation: ${mutation.showRetryDialog}")

                    setState {
                        copy(
                            screenState = mutation.listScreenState,
                            retryDialogShown = mutation.showRetryDialog,
                        )
                    }
                }
        }

        viewModelScope.launch {
            combine(
                seasons,
                stateFlow.map { it.seasonsState },
            ) { seasons, seasonsState ->
                ListSeasonsState(
                    seasons = seasons.map { season ->
                        ListSeason(
                            season,
                            selected = seasonsState.selectedSeasons.firstOrNull { it.id == season.id } != null,
                        )
                    },
                    selectedSeasons = seasonsState.selectedSeasons,
                )
            }.flowOn(dispatchers.computation)
                .collectLatest {
                    setState {
                        copy(seasonsState = it)
                    }
                }
        }
    }

    fun onRetryClicked() {
        logger.d("Retrying refresh Podwalks.")
        refreshPodwalks(true)
    }

    fun dismissRetryDialog() = setState {
        logger.d("Dismissing retry dialog.")
        copy(retryDialogShown = false, didManuallyRetry = false)
    }

    fun changePresentationType(type: ListType) = setState {
        copy(listPresentationType = type)
    }

    fun selectSeason(podwalkSeason: PodwalkSeason) {
        viewModelScope.launch(dispatchers.computation) {
            setState {
                val snapshot = seasonsState.selectedSeasons

                val selectedSeasons = if (seasonsState.selectedSeasons.contains(podwalkSeason)) {
                    snapshot - podwalkSeason
                } else {
                    snapshot + podwalkSeason
                }

                copy(seasonsState = seasonsState.copy(selectedSeasons = selectedSeasons))
            }
        }
    }

    @AssistedFactory
    interface Factory : AssistedViewModelFactory<PodwalksListViewModel, PodwalksListViewState> {
        override fun create(state: PodwalksListViewState): PodwalksListViewModel
    }

    companion object :
        MavericksViewModelFactory<PodwalksListViewModel, PodwalksListViewState> by hiltMavericksViewModelFactory()
}
