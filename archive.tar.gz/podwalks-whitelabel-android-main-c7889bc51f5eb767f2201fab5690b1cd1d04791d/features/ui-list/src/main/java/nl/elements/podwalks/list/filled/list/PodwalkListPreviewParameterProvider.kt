package nl.elements.podwalks.list.filled.list

import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.item.ListPodwalkPreviewParameterProvider

internal class PodwalkListPreviewParameterProvider : PreviewParameterProvider<List<ListPodwalk>> {
    override val values: Sequence<List<ListPodwalk>> = sequenceOf(
        ListPodwalkPreviewParameterProvider().values.toList(),
    )
}
