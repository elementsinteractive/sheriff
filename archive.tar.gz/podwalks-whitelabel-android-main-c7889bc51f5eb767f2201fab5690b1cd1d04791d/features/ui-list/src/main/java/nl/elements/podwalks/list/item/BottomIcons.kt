package nl.elements.podwalks.list.item

import androidx.compose.foundation.layout.size
import androidx.compose.material.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.shared.resources.R

@Composable
internal fun AlreadyDownloadedIcon() {
    Icon(
        modifier = Modifier
            .size(20.dp),
        painter = painterResource(R.drawable.ic_downloaded),
        contentDescription = null,
    )
}

@Composable
internal fun DownloadIcon() {
    Icon(
        modifier = Modifier
            .size(20.dp),
        painter = painterResource(R.drawable.ic_download),
        contentDescription = null,
    )
}

@Preview
@Composable
internal fun AlreadyDownloadedIconPreview() {
    AppTheme {
        AlreadyDownloadedIcon()
    }
}

@Preview
@Composable
internal fun DownloadIconPreview() {
    AppTheme {
        DownloadIcon()
    }
}
