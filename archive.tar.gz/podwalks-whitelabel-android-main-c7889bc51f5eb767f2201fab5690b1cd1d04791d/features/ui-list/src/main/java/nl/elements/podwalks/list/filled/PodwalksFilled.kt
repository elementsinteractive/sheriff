package nl.elements.podwalks.list.filled

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import nl.elements.podwalks.list.ListSeasonClick
import nl.elements.podwalks.list.filled.list.PodwalksFilledList
import nl.elements.podwalks.list.filled.map.PodwalksFilledMap
import nl.elements.podwalks.list.item.ListMapGroup
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.list.seasons.ListSeasonsState

@Composable
fun PodwalksFilled(
    podwalks: List<ListPodwalk>,
    groups: List<ListMapGroup>,
    seasonsState: ListSeasonsState,
    mode: ListType,
    onWalkClick: (ListPodwalk) -> Unit,
    onChangeMode: (ListType) -> Unit,
    onSeasonClick: ListSeasonClick,
) {
    when (mode) {
        is ListType.List -> {
            PodwalksFilledList(
                modifier = Modifier,
                podwalks = podwalks,
                onWalkClick = onWalkClick,
                onModeToggle = {
                    onChangeMode(ListType.Map)
                },
                seasonsState = seasonsState,
                onSeasonClicked = onSeasonClick,
            )
        }

        is ListType.Map -> {
            PodwalksFilledMap(
                modifier = Modifier,
                podwalks = groups,
                onWalkClick = onWalkClick,
                onModeToggle = {
                    onChangeMode(ListType.List)
                },
                seasonsState = seasonsState,
                onSeasonClicked = onSeasonClick,
            )
        }
    }
}
