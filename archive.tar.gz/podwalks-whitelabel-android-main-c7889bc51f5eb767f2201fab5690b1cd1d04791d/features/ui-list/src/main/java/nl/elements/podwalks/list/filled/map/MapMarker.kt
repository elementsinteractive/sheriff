package nl.elements.podwalks.list.filled.map

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.unit.dp
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.MarkerComposable
import com.google.maps.android.compose.MarkerState
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.list.filled.list.PodwalkListPreviewParameterProvider
import nl.elements.podwalks.list.item.ListMapGroup
import nl.elements.podwalks.list.item.ListPodwalk
import nl.elements.podwalks.presentation.compose.theme.AppTheme

@Composable
internal fun MapMarkers(
    groups: List<ListMapGroup>,
    selectedId: String?,
    onSelect: (ListMapGroup) -> Unit,
) {
    for (group in groups) {
        MapMarker(
            coordinate = group.coordinate,
            selected = group.id == selectedId,
            title = group.name,
            onSelect = { onSelect(group) },
        )
    }
}

@Composable
@Suppress("MagicNumber")
internal fun MapMarker(
    coordinate: Coordinate,
    selected: Boolean,
    title: String,
    onSelect: () -> Unit,
) {
    val markerState = remember {
        MarkerState(position = LatLng(coordinate.latitude.value, coordinate.longitude.value))
    }

    val innerShape = RoundedCornerShape(10.dp)
    val outerShape = RoundedCornerShape(12.dp)

    MarkerComposable(
        keys = arrayOf(selected, title),
        state = markerState,
        title = title,
        anchor = Offset(0.5f, 0.5f),
        onClick = {
            onSelect()
            true
        },
    ) {
        val markerColor = when (selected) {
            true -> MaterialTheme.colors.onSurface
            false -> MaterialTheme.colors.primary
        }

        Box(
            modifier = Modifier
                .height(64.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .align(Alignment.Center)
                    .clip(outerShape)
                    .background(MaterialTheme.colors.onPrimary),
            )
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .align(Alignment.Center)
                    .clip(innerShape)
                    .background(markerColor),
            )
            Text(
                modifier = Modifier.align(Alignment.BottomCenter),
                text = title,
                style = MaterialTheme.typography.caption.copy(
                    shadow = Shadow(
                        color = MaterialTheme.colors.background,
                        blurRadius = 4.0f,
                    ),
                ),
                color = MaterialTheme.colors.onBackground,
            )
        }
    }
}

@Preview
@Composable
internal fun MapMarkerPreview(
    @PreviewParameter(PodwalkListPreviewParameterProvider::class) podwalks: List<ListPodwalk>,
) {
    AppTheme {
        val item = podwalks.first()
        Column(modifier = Modifier.background(MaterialTheme.colors.background)) {
            MapMarker(
                coordinate = item.coordinate,
                selected = false,
                title = item.name,
                onSelect = {},
            )

            MapMarker(
                coordinate = item.coordinate,
                selected = true,
                title = item.name,
                onSelect = {},
            )
        }
    }
}
