package nl.elements.podwalks.list

import be.vrt.consents.VrtConsents
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

internal fun CoroutineScope.showConsentIfNeeded() = launch {
    VrtConsents.showConsentsScreenIfNeeded()
}
