package nl.elements.podwalks.list

import kotlinx.coroutines.CoroutineScope

internal fun CoroutineScope.showConsentIfNeeded() = Unit
