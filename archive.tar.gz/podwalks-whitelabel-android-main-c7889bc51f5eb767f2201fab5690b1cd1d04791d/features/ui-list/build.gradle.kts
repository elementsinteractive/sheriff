import nl.elements.podwalks.PodwalkFlavor

plugins {
    id("podwalks.android.feature")
    id("dagger.hilt.android.plugin")
}

val customListFlavors = listOf(PodwalkFlavor.vrt)

android {

    buildFeatures {
        buildConfig = true
    }

    namespace = "nl.elements.ui_list"

    @Suppress("UnstableApiUsage")
    sourceSets {
        PodwalkFlavor.values()
            .filterNot { customListFlavors.contains(it) }
            .forEach {
                getByName(it.name) {
                    java.srcDirs("src/default/java")
                }
            }
    }

    defaultConfig {
        buildConfigField("String", "region", "UNDEFINED")
        buildConfigField("Boolean", "mapOverviewEnabled", "UNDEFINED")
    }

    productFlavors {
        PodwalkFlavor.values().forEach { flavor ->
            getByName(flavor.name) {
                buildConfigField("String", "region", "\"" + flavor.mapRegion + "\"")
                buildConfigField("Boolean", "mapOverviewEnabled", flavor.mapOverviewEnabled.toString())
            }
        }
    }
}

dependencies {
    implementation(project(":shared:maps"))

    implementation(libs.bundles.mavericks)
    implementation(libs.bundles.navigationFragment)
    implementation(libs.bundles.compose)
    implementation(libs.bundles.maps)

    implementation(libs.mobilization.loggingApi)
    implementation(libs.google.location)

    implementation(libs.androidx.compose.uiToolingPreview)
    debugImplementation(libs.androidx.compose.uiTooling)

    implementation(libs.dagger.hilt.compose)
    implementation(libs.dagger.hilt.base)
    ksp(libs.dagger.hilt.compiler)
}

// VRT dependencies
dependencies {
    vrtImplementation(libs.vrt.consents.core)
}
