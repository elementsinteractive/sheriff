@file:Suppress("MatchingDeclarationName")

package nl.elements.podwalks.splash.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.compose.composable
import kotlinx.serialization.Serializable
import nl.elements.podwalks.splash.compose.SplashScreen

@Serializable
data object Splash

fun NavController.navigateToSplash(
    navOptions: NavOptions? = null,
) = navigate(
    route = Splash,
    navOptions = navOptions,
)

fun NavGraphBuilder.splashScreen(
    onOpenOnboarding: () -> Unit,
    onOpenWalkList: () -> Unit,
    onOpenLogin: () -> Unit,
) {
    composable<Splash> {
        SplashScreen(
            onOpenOnboarding = onOpenOnboarding,
            onOpenWalkList = onOpenWalkList,
            onOpenLogin = onOpenLogin,
        )
    }
}
