package nl.elements.podwalks.splash.compose

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.flowWithLifecycle
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.splash.SplashNextScreenResult
import nl.elements.podwalks.splash.SplashScreen
import nl.elements.podwalks.splash.SplashViewModel

@Composable
internal fun SplashScreen(
    modifier: Modifier = Modifier,
    onOpenOnboarding: () -> Unit,
    onOpenWalkList: () -> Unit,
    onOpenLogin: () -> Unit,
    viewModel: SplashViewModel = hiltViewModel(),
) {
    LaunchedEffect(true) {
        viewModel.continueToNextScreen()
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val currentOnOpenOnboarding by rememberUpdatedState(onOpenOnboarding)
    val currentOnOpenWalkList by rememberUpdatedState(onOpenWalkList)
    val currentOnOpenLogin by rememberUpdatedState(onOpenLogin)

    LaunchedEffect(viewModel, lifecycle) {
        snapshotFlow { viewModel.screenSelectedFlow.filterNotNull() }
            .map { it.first() }
            .flowWithLifecycle(lifecycle, Lifecycle.State.RESUMED)
            .collect { screen ->
                when (screen) {
                    SplashNextScreenResult.Onboarding -> currentOnOpenOnboarding()
                    SplashNextScreenResult.WalkList -> currentOnOpenWalkList()
                    SplashNextScreenResult.Login -> currentOnOpenLogin()
                }
            }
    }

    SplashScreen(
        modifier = modifier,
    )
}

@Preview
@Composable
internal fun SplashScreenPreview() {
    AppTheme {
        SplashScreen(
            modifier = Modifier.fillMaxSize(),
        )
    }
}
