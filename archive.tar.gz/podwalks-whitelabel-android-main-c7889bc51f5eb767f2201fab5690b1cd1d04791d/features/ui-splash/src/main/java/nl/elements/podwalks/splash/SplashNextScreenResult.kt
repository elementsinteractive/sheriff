package nl.elements.podwalks.splash

sealed class SplashNextScreenResult {
    data object Onboarding : SplashNextScreenResult()
    data object WalkList : SplashNextScreenResult()
    data object Login : SplashNextScreenResult()
}
