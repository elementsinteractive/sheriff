package nl.elements.podwalks.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.time.Duration.Companion.seconds

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val nextScreen: SplashNextScreen,
) : ViewModel() {

    val screenSelectedFlow: MutableStateFlow<SplashNextScreenResult?> = MutableStateFlow(null)

    fun continueToNextScreen() {
        viewModelScope.launch {
            val delay = async { cosmeticDelay() }
            val screen = async { nextScreen() }

            listOf(delay, screen).awaitAll()
            screenSelectedFlow.emit(screen.await())
        }
    }

    private suspend fun cosmeticDelay() = delay(COSMETIC_DELAY)

    companion object {
        val COSMETIC_DELAY = 2.5.seconds
    }
}
