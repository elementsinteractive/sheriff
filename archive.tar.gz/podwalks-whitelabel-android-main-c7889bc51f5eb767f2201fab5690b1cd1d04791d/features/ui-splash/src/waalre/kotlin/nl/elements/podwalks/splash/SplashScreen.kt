package nl.elements.podwalks.splash

import androidx.activity.ComponentActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.updateStatusBar
import nl.elements.podwalks.shared.resources.R as SharedResources

@Composable
internal fun SplashScreen(
    modifier: Modifier = Modifier,
) {
    SystemBarColorEffect()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            modifier = Modifier.width(256.dp),
            painter = painterResource(id = SharedResources.drawable.splash_logo),
            contentDescription = null,
        )
    }
}

@Composable
private fun SystemBarColorEffect() {
    val context = LocalContext.current as ComponentActivity

    LaunchedEffect(null) {
        context.updateStatusBar(false)
    }
}

@Preview
@Composable
fun SplashPreview() {
    AppTheme {
        SplashScreen()
    }
}
