package nl.elements.podwalks.splash

import dagger.Reusable
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.domain.interactors.ShouldShowOnboarding
import nl.elements.podwalks.splash.SplashNextScreenResult.Onboarding
import nl.elements.podwalks.splash.SplashNextScreenResult.WalkList
import javax.inject.Inject

@Reusable
class SplashNextScreen @Inject constructor(
    private val shouldShowOnboarding: ShouldShowOnboarding,
) {

    suspend operator fun invoke() = shouldShowOnboarding()
        .map { if (it) Onboarding else WalkList }
        .first()
}
