package nl.elements.podwalks.splash

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.shared.resources.R

@Composable
internal fun SplashScreen(
    modifier: Modifier = Modifier,
) {
    SystemBarColorEffect()

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center,
    ) {
        Image(
            modifier = Modifier.width(200.dp),
            painter = painterResource(id = R.drawable.splash_logo),
            contentDescription = null,
            contentScale = ContentScale.Fit,
        )
    }
}

@Composable
private fun SystemBarColorEffect() {
    val context = LocalContext.current as ComponentActivity
    val color = Color.Transparent.toArgb()

    LaunchedEffect(null) {
        context.enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(color),
        )
    }
}

@Preview
@Composable
fun SplashPreview() {
    AppTheme {
        SplashScreen()
    }
}
