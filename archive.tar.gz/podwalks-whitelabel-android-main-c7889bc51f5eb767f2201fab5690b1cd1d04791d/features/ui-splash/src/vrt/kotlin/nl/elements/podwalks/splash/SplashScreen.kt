package nl.elements.podwalks.splash

import androidx.activity.ComponentActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.presentation.compose.updateStatusBar
import nl.elements.podwalks.shared.resources.R

@Composable
internal fun SplashScreen(modifier: Modifier = Modifier) {
    SystemBarColorEffect()

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center,
    ) {
        Image(
            modifier = Modifier.fillMaxSize(),
            painter = painterResource(id = R.drawable.splash_logo),
            contentDescription = null,
            contentScale = ContentScale.Crop,
        )
    }
}

@Composable
private fun SystemBarColorEffect() {
    val context = LocalContext.current as ComponentActivity

    LaunchedEffect(null) {
        context.updateStatusBar(false)
    }
}

@Preview
@Composable
fun SplashPreview() {
    AppTheme {
        SplashScreen()
    }
}
