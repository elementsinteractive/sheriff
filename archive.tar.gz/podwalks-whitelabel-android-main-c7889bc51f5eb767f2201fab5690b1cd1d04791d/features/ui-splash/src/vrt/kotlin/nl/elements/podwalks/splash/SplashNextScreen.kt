package nl.elements.podwalks.splash

import be.vrt.login.core.VrtLogin
import be.vrt.login.core.model.Result
import be.vrt.login.core.model.SsoAvailability
import dagger.Reusable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import nl.elements.podwalks.domain.interactors.ShouldShowOnboarding
import nl.elements.podwalks.splash.SplashNextScreenResult.Login
import nl.elements.podwalks.splash.SplashNextScreenResult.Onboarding
import nl.elements.podwalks.splash.SplashNextScreenResult.WalkList
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject

@Reusable
class SplashNextScreen @Inject constructor(
    private val shouldShowOnboarding: ShouldShowOnboarding,
    private val dispatchers: AppCoroutineDispatchers,
) {

    suspend operator fun invoke() = coroutineScope {
        val showOnboarding = shouldShowOnboarding().first()

        withContext(dispatchers.io) {
            if (VrtLogin.getUserAndTokens(refreshTokensIfExpired = true) is Result.LoginComplete) {
                WalkList
            }

            val ssoAvailability = VrtLogin.isSsoLoginAvailable()
            val autoSsoResult =
                if (ssoAvailability is SsoAvailability.Available) VrtLogin.autoSso(true) else null

            if (autoSsoResult is Result.LoginComplete) {
                if (showOnboarding) Onboarding else WalkList
            }

            if (showOnboarding) Login else WalkList
        }
    }
}
