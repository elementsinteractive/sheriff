import nl.elements.podwalks.PodwalkFlavor

plugins {
    id("podwalks.android.feature")
}

val customSplashFlavors =
    listOf(PodwalkFlavor.ajsph, PodwalkFlavor.waalre, PodwalkFlavor.vrt, PodwalkFlavor.bnob, PodwalkFlavor.nimh, PodwalkFlavor.gelderland, PodwalkFlavor.natuurmonumenten, PodwalkFlavor.deinze)

android {
    namespace = "nl.elements.podwalks.splash"

    @Suppress("UnstableApiUsage")
    sourceSets {
        PodwalkFlavor.values()
            .filterNot { customSplashFlavors.contains(it) }
            .forEach {
                getByName(it.name) {
                    java.srcDirs("src/default/java")
                }
            }
    }
}

dependencies {
    implementation(libs.bundles.compose)
    debugImplementation(libs.androidx.compose.uiTooling)
    implementation(libs.androidx.compose.uiToolingPreview)

    implementation(libs.dagger.hilt.base)
    implementation(libs.dagger.hilt.compose)
    ksp(libs.dagger.hilt.compiler)
}

// VRT dependencies
dependencies {
    vrtImplementation(libs.vrt.login)
}
