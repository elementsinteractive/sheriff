package buildConfig.buildTime

import com.android.build.api.variant.AndroidComponentsExtension
import com.android.build.api.variant.BuildConfigField
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.getByType
import org.gradle.kotlin.dsl.register

class BuildTimePlugin : Plugin<Project> {
    override fun apply(project: Project) {
        val buildTimeProvider = project.tasks.register<BuildTimeTask>("buildTimeProvider") {

            buildTimeOutputFile.set(
                project.layout.buildDirectory.dir("intermediates/buildTimeProvider/output").get().asFile
            )

            outputs.upToDateWhen { false }
        }

        val androidComponents = project.extensions.getByType(AndroidComponentsExtension::class)

        androidComponents.onVariants {
            it.buildConfigFields?.put(
                "BUILD_TIME",
                buildTimeProvider.map { task ->
                    BuildConfigField(
                        "String",
                        "\"${task.buildTimeOutputFile.get().asFile.readText(Charsets.UTF_8)}\"",
                        "Build time"
                    )
                }
            )
        }
    }
}
