package buildConfig.gitSha

import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.tasks.OutputFile
import org.gradle.api.tasks.TaskAction

abstract class GitVersionTask : DefaultTask() {
    @get:OutputFile
    abstract val gitVersionOutputFile: RegularFileProperty

    @ExperimentalStdlibApi
    @TaskAction
    fun taskAction() {
        val gitProcess = ProcessBuilder("git", "rev-parse", "--short", "HEAD").start()

        val error = gitProcess.errorStream.readBytes().decodeToString()
        if (error.isNotBlank()) {
            System.err.println("Git error : $error")
        }

        val gitVersion = gitProcess.inputStream.readBytes().decodeToString().trim()

        gitVersionOutputFile.get().asFile.writeText(gitVersion)
    }
}
