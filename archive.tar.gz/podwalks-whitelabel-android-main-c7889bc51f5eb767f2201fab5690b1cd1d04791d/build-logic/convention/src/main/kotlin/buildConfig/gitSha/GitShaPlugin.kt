package buildConfig.gitSha

import com.android.build.api.variant.AndroidComponentsExtension
import com.android.build.api.variant.BuildConfigField
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.getByType
import org.gradle.kotlin.dsl.register

class GitShaPlugin : Plugin<Project> {
    override fun apply(project: Project) {
        val gitVersionProvider = project.tasks.register<GitVersionTask>("gitVersionProvider") {

            gitVersionOutputFile.set(
                project.layout.buildDirectory.dir("intermediates/gitVersionProvider/output").get().asFile
            )

            outputs.upToDateWhen { false }
        }

        val androidComponents = project.extensions.getByType(AndroidComponentsExtension::class)

        androidComponents.onVariants {
            it.buildConfigFields?.put(
                "GIT_SHA",
                gitVersionProvider.map { task ->
                    BuildConfigField(
                        "String",
                        "\"${task.gitVersionOutputFile.get().asFile.readText(Charsets.UTF_8)}\"",
                        "Git SHA"
                    )
                }
            )
        }
    }
}
