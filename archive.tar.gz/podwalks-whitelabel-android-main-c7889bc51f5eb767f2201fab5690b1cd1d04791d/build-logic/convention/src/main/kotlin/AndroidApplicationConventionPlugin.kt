import com.android.build.api.dsl.ApplicationExtension
import nl.elements.podwalks.Config
import nl.elements.podwalks.configureKotlinAndroid
import nl.elements.podwalks.configureKotlinAndroidToolchain
import nl.elements.podwalks.configureLeakCanary
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.artifacts.VersionCatalogsExtension
import org.gradle.kotlin.dsl.configure
import org.gradle.kotlin.dsl.dependencies
import org.gradle.kotlin.dsl.getByType
import org.gradle.kotlin.dsl.kotlin

class AndroidApplicationConventionPlugin : Plugin<Project> {

    override fun apply(target: Project) {
        with(target) {

            with(pluginManager) {
                apply("com.android.application")
                apply("org.jetbrains.kotlin.android")
                apply("podwalks.codestyle")
                apply("com.google.devtools.ksp")
            }

            configureKotlinAndroidToolchain()
            configureLeakCanary()
            extensions.configure<ApplicationExtension> {
                configureKotlinAndroid(this)
                defaultConfig.targetSdk = Config.targetSdk
                compileOptions.isCoreLibraryDesugaringEnabled = true
            }

            val libs = extensions.getByType<VersionCatalogsExtension>().named("libs")

            dependencies {
                add("coreLibraryDesugaring", libs.findLibrary("android.desugarJdkLibs").get())
            }
        }
    }
}
