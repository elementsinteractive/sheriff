import org.gradle.api.Plugin
import org.gradle.api.Project

class BuildConfigPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            pluginManager.apply {
                apply("podwalks.buildConfig.buildTime")
                apply("podwalks.buildConfig.gitSha")
            }
        }
    }
}
