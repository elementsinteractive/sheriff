package nl.elements.podwalks

import com.android.build.api.dsl.ApplicationBuildType
import com.android.build.api.dsl.ApplicationProductFlavor
import com.android.build.api.dsl.CommonExtension
import nl.elements.podwalks.BuildType.Companion.toName
import nl.elements.podwalks.Config.DEVELOPMENT_SIGNING_NAME
import org.gradle.api.Project
import org.gradle.kotlin.dsl.getByName
import java.io.FileInputStream
import java.util.Properties

fun Project.configureApplicationFlavorSigning(
    commonExtension: CommonExtension<*, *, *, *, *, *>,
) {
    commonExtension.apply {
        val keystorePropertiesFile = rootProject.file("keystore.properties")

        /**
         * Signs each flavor with its own keystore
         */
        if (keystorePropertiesFile.exists()) {
            val keystoreProperties = Properties().apply {
                load(FileInputStream(keystorePropertiesFile))
            }

            signingConfigs {
                PodwalkFlavor.values().map {
                    require(file(it.signingConfig.filename).exists()) {
                        "Could not find keystore file for flavor ${it.name}"
                    }

                    create(it.signingConfigName) {
                        storeFile = file(it.signingConfig.filename)
                        storePassword = keystoreProperties.getProperty(it.signingConfig.storePasswordField)
                        keyAlias = keystoreProperties.getProperty(it.signingConfig.keyAliasField)
                        keyPassword = keystoreProperties.getProperty(it.signingConfig.keyPasswordField)
                    }
                }
            }

            productFlavors {
                PodwalkFlavor.values().forEach {
                    getByName<ApplicationProductFlavor>(it.name) {
                        val config = signingConfigs.findByName(it.signingConfigName)
                        requireNotNull(config) {
                            "Could not find signing config for ${it.signingConfigName} with flavor ${it.name}"
                        }

                        signingConfig = config
                    }
                }
            }
        }

        signingConfigs {
            create(DEVELOPMENT_SIGNING_NAME) {
                storeFile = file("keystore/development.keystore")
                storePassword = "android"
                keyAlias = "AndroidDebugKey"
                keyPassword = "android"
            }
        }

        buildTypes {
            create(BuildType.Staging.toName())
        }
    }
}
