package nl.elements.podwalks

import com.android.build.api.variant.AndroidComponentsExtension
import com.android.build.api.variant.BuildConfigField
import com.android.build.api.variant.Variant
import nl.elements.podwalks.BuildType.Companion.toBuildType
import org.gradle.api.Project

fun Project.configureVariants() {
    val androidComponents = extensions.getByType(AndroidComponentsExtension::class.java)

    androidComponents.onVariants { variant ->
        val flavorName = variant.flavorName
        val buildTypeName = variant.buildType
        requireNotNull(flavorName)
        requireNotNull(buildTypeName)

        val flavor = flavorName.toPodwalkFlavor()
        val buildType = buildTypeName.toBuildType()

        val config = when (buildType) {
            BuildType.Debug -> flavor.variantConfig.debug
            BuildType.Release -> flavor.variantConfig.release
            BuildType.Staging -> flavor.variantConfig.staging
        }

        variant.putPodwalkAPIHost(config)
        variant.putPodwalkAPIKey(config)
        variant.putGoogleMapsApiKey(config)
        variant.putConfigFields(config)
    }
}

private fun Variant.putPodwalkAPIHost(
    config: BuildTypeConfig,
) {
    buildConfigFields?.put(
        "PODWALK_API_HOST",
        BuildConfigField("String", config.podwalkAPIHost.toConfigField(), "Podwalk API host")
    )
}

private fun Variant.putPodwalkAPIKey(
    config: BuildTypeConfig,
) {
    val podwalkAPIKey = System.getenv(config.podwalkAPIKeyEnvironmentName)

    requireNotNull(podwalkAPIKey) {
        "Could not find Podwalk API key. Did you define ${config.podwalkAPIKeyEnvironmentName}?"
    }

    buildConfigFields?.put(
        "PODWALK_API_KEY",
        BuildConfigField("String", podwalkAPIKey.toConfigField(), "Podwalk API key")
    )
}

private fun Variant.putGoogleMapsApiKey(
    config: BuildTypeConfig,
) {
    val googleMapsAPIKey = System.getenv(config.googleMapsApiKeyEnvironmentName)

    requireNotNull(googleMapsAPIKey) {
        "Could not find Google Maps API key. Did you define ${config.googleMapsApiKeyEnvironmentName}?"
    }

    manifestPlaceholders.put(
        "GOOGLE_MAPS_API_KEY",
        googleMapsAPIKey,
    )
}

private fun Variant.putConfigFields(
    config: BuildTypeConfig,
) {
    config.otherFields.forEach { (key, field) ->
        val isString = field.type.equals("String", true)
        val fieldValue = if (isString) field.value.toConfigField() else field.value

        buildConfigFields?.put(key, BuildConfigField(field.type, fieldValue, field.comment))
    }
}

fun String.toConfigField() = "\"$this\""
