package nl.elements.podwalks

data class PodwalkSigningInfo(
    val filename: String,
    val prefix: String,
)

internal val PodwalkSigningInfo.storePasswordField get() = "${prefix}storePassword"
internal val PodwalkSigningInfo.keyAliasField get() = "${prefix}keyAlias"
internal val PodwalkSigningInfo.keyPasswordField get() = "${prefix}keyPassword"
