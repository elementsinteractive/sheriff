package nl.elements.podwalks

import org.gradle.api.JavaVersion

object Config {
    const val compileSdk = 36
    const val minSdk = 28
    const val targetSdk = 36

    val jdkVersion = JavaVersion.VERSION_21
    const val jdkVersionNumber = 21

    const val DEVELOPMENT_SIGNING_NAME = "development"
}

data class VariantConfig(
    val release: BuildTypeConfig,
    val staging: BuildTypeConfig,
    val debug: BuildTypeConfig,
)

data class BuildTypeConfig(
    val podwalkAPIHost: String,
    val podwalkAPIKeyEnvironmentName: String,
    val googleMapsApiKeyEnvironmentName: String,
    val otherFields: Map<String, BuildTypeConfigField> = mapOf(),
)

data class BuildTypeConfigField(
    val type: String,
    val value: String,
    val comment: String? = null,
)

sealed interface BuildType {
    object Debug : BuildType
    object Staging : BuildType
    object Release : BuildType

    companion object {

        val BUILD_TYPES = listOf(Debug, Staging, Release)

        fun String.toBuildType(): BuildType = when (this) {
            "debug" -> Debug
            "staging" -> Staging
            "release" -> Release
            else -> error("Unsupported build type found.")
        }

        fun BuildType.toName(): String = when(this) {
            Debug -> "debug"
            Release -> "release"
            Staging -> "staging"
        }
    }
}
