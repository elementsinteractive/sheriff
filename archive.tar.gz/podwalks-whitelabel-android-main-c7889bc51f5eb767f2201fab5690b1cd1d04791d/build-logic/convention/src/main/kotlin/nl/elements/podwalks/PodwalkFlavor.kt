package nl.elements.podwalks

import com.android.build.api.dsl.ApplicationExtension
import com.android.build.api.dsl.ApplicationProductFlavor
import com.android.build.api.dsl.CommonExtension
import com.android.build.api.dsl.ProductFlavor
import org.gradle.api.Project

@Suppress("EnumEntryName")
enum class FlavorDimension {
    podwalkType
}

internal object PodwalkConfig {
    const val API_HOST = "https://podwalks.elements.nl"
}

@Suppress("EnumEntryName")
enum class PodwalkFlavor(
    val dimension: FlavorDimension,
    val variantConfig: VariantConfig,
    val signingConfig: PodwalkSigningInfo,
    val applicationId: String? = null,
    val versionName: String? = null,
    val applicationIdSuffix: String? = null,
    val resourceConfigurations: List<String>? = null,
    val mapRegion: String = "NETHERLANDS",
    val mapOverviewEnabled: Boolean = false,
) {
    elements(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_ELEMENTS_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_ELEMENTS_GOOGLE_MAPS_API_KEY",
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_ELEMENTS_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_ELEMENTS_GOOGLE_MAPS_API_KEY",
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_ELEMENTS_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_ELEMENTS_GOOGLE_MAPS_API_KEY",
            ),
        ),
        applicationIdSuffix = ".elements",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/elements.keystore",
            prefix = "",
        ),
        mapOverviewEnabled = true,
    ),
    waalre(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_WAALRE_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_WAALRE_PROD_GOOGLE_MAPS_API_KEY",
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_WAALRE_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_WAALRE_DEV_GOOGLE_MAPS_API_KEY",
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_WAALRE_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_WAALRE_DEV_GOOGLE_MAPS_API_KEY",
            ),
        ),
        applicationId = "nl.waalre.podwalks",
        versionName = "1.0.3",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/waalre.keystore",
            prefix = "waalre",
        ),
    ),
    ajsph(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_AJSPH_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_AJSPH_PROD_GOOGLE_MAPS_API_KEY",
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_AJSPH_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_AJSPH_DEV_GOOGLE_MAPS_API_KEY",
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_AJSPH_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_AJSPH_DEV_GOOGLE_MAPS_API_KEY",
            ),
        ),
        applicationId = "nl.rug.ajsph.podwalks",
        versionName = "1.0.4",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/ajsph.keystore",
            prefix = "ajsph",
        ),
    ),
    vrt(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_VRT_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_VRT_PROD_GOOGLE_MAPS_API_KEY",
                otherFields = vrtLoginConfigRelease + vrtConsentConfigRelease
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_VRT_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_VRT_DEV_GOOGLE_MAPS_API_KEY",
                otherFields = vrtLoginConfigStaging + vrtConsentConfigRelease
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_VRT_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_VRT_DEV_GOOGLE_MAPS_API_KEY",
                otherFields = vrtLoginConfigStaging + vrtConsentConfigRelease
            ),
        ),
        applicationId = "be.vrt.podwalks",
        versionName = "1.0.8",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/vrt.keystore",
            prefix = "vrt",
        ),
        resourceConfigurations = listOf("nl"),
        mapRegion = "BELGIUM",
        mapOverviewEnabled = true,
    ),
    bnob(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_BNOB_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_BNOB_PROD_GOOGLE_MAPS_API_KEY",
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_BNOB_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_BNOB_DEV_GOOGLE_MAPS_API_KEY",
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_BNOB_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_BNOB_DEV_GOOGLE_MAPS_API_KEY",
            ),
        ),
        applicationId = "nl.bnob.podwalks",
        versionName = "1.1.0",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/bnob.keystore",
            prefix = "bnob",
        ),
        resourceConfigurations = listOf("nl"),
    ),
    nimh(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_NIMH_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_NIMH_PROD_GOOGLE_MAPS_API_KEY",
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_NIMH_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_NIMH_DEV_GOOGLE_MAPS_API_KEY",
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_NIMH_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_NIMH_DEV_GOOGLE_MAPS_API_KEY",
            ),
        ),
        applicationId = "nl.nimh.podwalks",
        versionName = "1.0.0",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/nimh.keystore",
            prefix = "nimh",
        ),
    ),
    gelderland(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_GELDERLAND_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_GELDERLAND_PROD_GOOGLE_MAPS_API_KEY",
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_GELDERLAND_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_GELDERLAND_DEV_GOOGLE_MAPS_API_KEY",
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_GELDERLAND_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_GELDERLAND_DEV_GOOGLE_MAPS_API_KEY",
            ),
        ),
        applicationId = "nl.gelderland.podwalks",
        versionName = "1.0.0",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/gelderland.keystore",
            prefix = "gelderland",
        ),
        resourceConfigurations = listOf("nl"),
    ),
    natuurmonumenten(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_NATUURMONUMENTEN_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_NATUURMONUMENTEN_PROD_GOOGLE_MAPS_API_KEY",
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_NATUURMONUMENTEN_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_NATUURMONUMENTEN_DEV_GOOGLE_MAPS_API_KEY",
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_NATUURMONUMENTEN_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_NATUURMONUMENTEN_DEV_GOOGLE_MAPS_API_KEY",
            ),
        ),
        applicationId = "nl.natuurmonumenten.podwalks",
        versionName = "1.0.0",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/natuurmonumenten.keystore",
            prefix = "natuurmonumenten",
        ),
        resourceConfigurations = listOf("nl"),
    ),
    deinze(
        dimension = FlavorDimension.podwalkType,
        variantConfig = VariantConfig(
            release = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_DEINZE_PROD_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_DEINZE_PROD_GOOGLE_MAPS_API_KEY",
            ),
            staging = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_DEINZE_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_DEINZE_DEV_GOOGLE_MAPS_API_KEY",
            ),
            debug = BuildTypeConfig(
                podwalkAPIHost = PodwalkConfig.API_HOST,
                podwalkAPIKeyEnvironmentName = "PODWALKS_DEINZE_DEV_API_KEY",
                googleMapsApiKeyEnvironmentName = "PODWALKS_DEINZE_DEV_GOOGLE_MAPS_API_KEY",
            ),
        ),
        applicationId = "be.deinze.podwalks",
        versionName = "1.0.0",
        signingConfig = PodwalkSigningInfo(
            filename = "keystore/deinze.keystore",
            prefix = "deinze",
        ),
        resourceConfigurations = listOf("nl"),
    ),
}

internal val PodwalkFlavor.signingConfigName get() = "${name}Config"

fun String.toPodwalkFlavor(): PodwalkFlavor = when (this) {
    PodwalkFlavor.elements.name -> PodwalkFlavor.elements
    PodwalkFlavor.waalre.name -> PodwalkFlavor.waalre
    PodwalkFlavor.ajsph.name -> PodwalkFlavor.ajsph
    PodwalkFlavor.vrt.name -> PodwalkFlavor.vrt
    PodwalkFlavor.bnob.name -> PodwalkFlavor.bnob
    PodwalkFlavor.nimh.name -> PodwalkFlavor.nimh
    PodwalkFlavor.gelderland.name -> PodwalkFlavor.gelderland
    PodwalkFlavor.natuurmonumenten.name -> PodwalkFlavor.natuurmonumenten
    PodwalkFlavor.deinze.name -> PodwalkFlavor.deinze
    else -> error("Unsupported flavor name found.")
}

fun Project.configureFlavors(
    commonExtension: CommonExtension<*, *, *, *, *, *>,
    flavorConfigurationBlock: ProductFlavor.(flavor: PodwalkFlavor) -> Unit = {}
) {
    commonExtension.apply {
        flavorDimensions += FlavorDimension.podwalkType.name

        productFlavors {
            PodwalkFlavor.values().forEach {
                create(it.name) {
                    dimension = it.dimension.name

                    flavorConfigurationBlock(this, it)

                    if (this@apply is ApplicationExtension && this is ApplicationProductFlavor) {
                        if (it.applicationId != null) {
                            this.applicationId = it.applicationId
                        }

                        if (it.applicationIdSuffix != null) {
                            this.applicationIdSuffix = it.applicationIdSuffix
                        }

                        if (it.versionName != null) {
                            this.versionName = it.versionName
                        }

                        if (it.resourceConfigurations != null) {
                            this.resourceConfigurations.addAll(it.resourceConfigurations)
                        } else {
                            this.resourceConfigurations.addAll(listOf("en", "nl"))
                        }
                    }
                }
            }
        }

        sourceSets {
            PodwalkFlavor.values().forEach { flavor ->
                getByName(flavor.name) {
                    setRoot("src/flavors/${flavor.name}")
                }
            }
        }
    }
}

private val vrtLoginConfigStaging
    get() = mapOf(
        "VRT_CLIENT_ID" to BuildTypeConfigField(
            type = "String",
            value = "podwalk-stag",
        ),
        "VRT_LOGIN_BFF" to BuildTypeConfigField(
            type = "String",
            value = "https://sso-stag.vrt.be/podwalk/",
        ),
    )

private val vrtLoginConfigRelease
    get() = mapOf(
        "VRT_CLIENT_ID" to BuildTypeConfigField(
            type = "String",
            value = "podwalk",
        ),
        "VRT_LOGIN_BFF" to BuildTypeConfigField(
            type = "String",
            value = "https://sso.vrt.be/podwalk/",
        ),
    )

private val vrtConsentConfigRelease
    get() = mapOf(
        "SOURCEPOINT_ID" to BuildTypeConfigField(
            type = "int",
            value = "34939",
        ),
        "SOURCEPOINT_NAME" to BuildTypeConfigField(
            type = "String",
            value = "podwalk-app-prod",
        ),
        "SOURCEPOINT_MANAGER_ID" to BuildTypeConfigField(
            type = "String",
            value = "1018179",
        ),
    )
