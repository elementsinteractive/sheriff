package nl.elements.podwalks

import com.android.build.gradle.internal.cxx.configure.gradleLocalProperties
import org.gradle.api.Project
import org.gradle.api.artifacts.VersionCatalogsExtension
import org.gradle.kotlin.dsl.dependencies
import org.gradle.kotlin.dsl.getByType

/**
 * Configues [LeakCanary](https://github.com/square/leakcanary)
 *
 * To opt-out of leakcanary during development builds define "leakcanary.enabled" in your
 * local.properties configuration file.
 */
internal fun Project.configureLeakCanary() {

    val shouldAddLeakCanary = gradleLocalProperties(rootDir, providers)
        .getProperty("leakcanary.enabled")
        .let {
            when (it) {
                "true" -> true
                "false" -> false
                else -> true
            }
        }

    val libs = extensions.getByType<VersionCatalogsExtension>().named("libs")

    if (shouldAddLeakCanary) {
        dependencies {
            add("debugImplementation", libs.findLibrary("leakcanary.development").get())
        }
    }
}
