import com.diffplug.gradle.spotless.SpotlessExtension
import io.gitlab.arturbosch.detekt.extensions.DetektExtension
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.configure

class CodeStyleConventionPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            pluginManager.apply {
                apply("io.gitlab.arturbosch.detekt")
                apply("com.diffplug.spotless")
            }

            configure<DetektExtension> {
                source.setFrom(
                    DetektExtension.DEFAULT_SRC_DIR_JAVA,
                    DetektExtension.DEFAULT_TEST_SRC_DIR_JAVA,
                    DetektExtension.DEFAULT_SRC_DIR_KOTLIN,
                    DetektExtension.DEFAULT_TEST_SRC_DIR_KOTLIN,
                )

                config.from("${rootDir.path}/detekt.yml")
            }

            val detektTask = tasks.getByName("detekt")

            rootProject.tasks.getByName("detektCheck").dependsOn(detektTask)

            configure<SpotlessExtension> {
                kotlin {
                    target("**/*.kt")
                    targetExclude("**/build/**/*.kt")

                    ktlint()
                        .userData(mapOf("android" to "true"))
                        .editorConfigOverride(
                            mapOf(
                                "ij_kotlin_allow_trailing_comma" to true,
                                "ij_kotlin_allow_trailing_comma_on_call_site" to true,
                            )
                        )
                }

                format("kts") {
                    target("**/*.kts")
                    targetExclude("**/build/**/*.kts")
                }
            }
        }
    }
}
