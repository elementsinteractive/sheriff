import com.android.build.gradle.LibraryExtension
import nl.elements.podwalks.Config
import nl.elements.podwalks.configureKotlinAndroid
import nl.elements.podwalks.configureKotlinAndroidToolchain
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.configure

class AndroidLibraryConventionPlugin : Plugin<Project> {

    override fun apply(target: Project) {
        with(target) {

            with(pluginManager) {
                apply("com.android.library")
                apply("org.jetbrains.kotlin.android")
                apply("podwalks.codestyle")
                apply("com.google.devtools.ksp")
            }

            configureKotlinAndroidToolchain()
            extensions.configure<LibraryExtension> {
                configureKotlinAndroid(this)
                defaultConfig.targetSdk = Config.targetSdk
            }
        }
    }
}
