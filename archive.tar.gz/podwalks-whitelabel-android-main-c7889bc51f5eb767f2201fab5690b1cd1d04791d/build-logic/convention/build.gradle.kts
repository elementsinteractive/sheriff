import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
    `kotlin-dsl`
}

group = "nl.elements.podwalks.buildlogic"

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}

tasks.withType<KotlinCompile>().configureEach {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_21)
    }
}

dependencies {
    compileOnly(libs.android.agp)
    compileOnly(libs.kotlin)
    compileOnly(libs.detekt)
    compileOnly(libs.spotless)
}

gradlePlugin {
    plugins {

        register("codeStyle") {
            id = "podwalks.codestyle"
            implementationClass = "CodeStyleConventionPlugin"
        }

        register("androidApplication") {
            id = "podwalks.android.application"
            implementationClass = "AndroidApplicationConventionPlugin"
        }

        register("androidApplicationCompose") {
            id = "podwalks.android.application.compose"
            implementationClass = "AndroidApplicationComposeConventionPlugin"
        }

        register("androidLibrary") {
            id = "podwalks.android.library"
            implementationClass = "AndroidLibraryConventionPlugin"
        }

        register("androidFeature") {
            id = "podwalks.android.feature"
            implementationClass = "AndroidFeatureConventionPlugin"
        }

        register("androidLibraryCompose") {
            id = "podwalks.android.library.compose"
            implementationClass = "AndroidLibraryComposeConventionPlugin"
        }

        register("kotest") {
            id = "podwalks.android.kotest"
            implementationClass = "KotestConventionPlugin"
        }

        register("podwalksSdk") {
            id = "podwalks.sdk"
            implementationClass = "PodwalkSdkPlugin"
        }

        register("androidFlavors") {
            id = "podwalks.android.application.flavors"
            implementationClass = "AndroidApplicationFlavorsConventionPlugin"
        }
        register("androidLibraryFlavors") {
            id = "podwalks.android.library.flavors"
            implementationClass = "AndroidLibraryFlavorsConventionPlugin"
        }

        register("buildConfig") {
            id = "podwalks.buildConfig"
            implementationClass = "BuildConfigPlugin"
        }
        register("buildConfigBuildTime") {
            id = "podwalks.buildConfig.buildTime"
            implementationClass = "buildConfig.buildTime.BuildTimePlugin"
        }
        register("buildConfigGitSHA") {
            id = "podwalks.buildConfig.gitSha"
            implementationClass = "buildConfig.gitSha.GitShaPlugin"
        }
    }
}
