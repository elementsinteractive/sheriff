#!/bin/bash

USERS=""
while read line; do
    USERS="$USERS --recipient $line"
    key_present=`gpg --list-keys | grep $line`
    if [ -z "$key_present" ]; then
        echo "ERROR Key for $line missing in your keyring"
        exit 1
    fi
done < deploy_users

FILE=$1
gpg --output $FILE.gpg --encrypt $USERS $FILE
