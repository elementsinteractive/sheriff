![Platform](https://img.shields.io/badge/platform-Android-blue.svg)
[![pipeline status](https://git.elements.nl/elements-android/skeleton-kotlin/badges/main/pipeline.svg)](https://git.elements.nl/elements-android/skeleton-kotlin/commits/main)
![coverage](https://git.elements.nl/elements-android/skeleton-kotlin/badges/main/coverage.svg?style=flat)


**_Every Android developer from Elements Interactive B.V. should participate in making this project up-to-date with latest technological stack._**


# Skeleton Kotlin documentation

## Documentation

More detailed documentation can be found in the [docs](./docs) folder.
