import nl.elements.podwalks.PodwalkFlavor

plugins {
    id("podwalks.android.library")
    id("podwalks.android.kotest")
    id("podwalks.android.library.flavors")
    kotlin("plugin.serialization")
}

val customDomainFlavors = listOf(PodwalkFlavor.waalre)

android {
    namespace = "nl.elements.podwalks.domain"

    defaultConfig {
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
        }
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"

            // License files
            excludes += "META-INF/LICENSE.md"
            excludes += "META-INF/LICENSE-notice.md"

            // for JNA and JNA-platform
            excludes += "META-INF/AL2.0"
            excludes += "META-INF/LGPL2.1"

            // for byte-buddy
            excludes += "META-INF/licenses/ASM"
            pickFirsts.addAll(listOf(
                "win32-x86-64/attach_hotspot_windows.dll",
                "win32-x86/attach_hotspot_windows.dll"
            ))
        }
    }

    @Suppress("UnstableApiUsage")
    sourceSets {
        PodwalkFlavor.values()
            .filterNot { customDomainFlavors.contains(it) }
            .forEach {
                getByName(it.name) {
                    java.srcDirs("src/default/kotlin")
                }
            }
    }
}

dependencies {
    api(project(":shared:analytics"))
    api(project(":shared:utils"))
    api(project(":data"))

    implementation(libs.mobilization.interactor)
    implementation(libs.mobilization.logging)

    implementation(libs.kotlin.reflect)

    ksp(libs.dagger.compiler)

    implementation(libs.dagger.hilt.base)
    ksp(libs.dagger.hilt.compiler)

}

dependencies {
    testImplementation(project(":memory"))
    testImplementation(project(":shared:test-repository"))
    testImplementation(libs.bundles.kotest)
    testImplementation(libs.turbine)
}

dependencies {
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.androidx.test.core)
    androidTestImplementation(libs.junit.junit)
    androidTestImplementation(project(":shared:test-repository"))
    androidTestImplementation(libs.kotest.runner.junit4)
    androidTestImplementation(libs.kotest.assertions.core)
    androidTestImplementation(libs.turbine)
}
