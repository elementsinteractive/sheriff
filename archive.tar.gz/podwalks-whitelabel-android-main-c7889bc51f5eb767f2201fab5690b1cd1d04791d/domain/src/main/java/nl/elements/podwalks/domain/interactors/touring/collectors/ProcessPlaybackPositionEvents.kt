package nl.elements.podwalks.domain.interactors.touring.collectors

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.data.store.TourGuideStore
import nl.elements.podwalks.domain.podwalk.PlaybackPositionChanged
import javax.inject.Inject

@Reusable
class ProcessPlaybackPositionEvents @Inject constructor(
    private val logger: Logger,
    private val store: TourGuideStore,
) {

    suspend operator fun invoke(events: Flow<PlaybackPositionChanged>) = events.collect {
        logger.i("Playback position changed: $it.")
        store.setPlaybackPosition(
            positionMs = it.positionInMs,
            trackDurationInMs = it.durationInMs,
        )
    }
}
