package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import nl.elements.podwalks.data.model.response.TourUpdateDocument
import nl.elements.podwalks.data.network.PodwalksService
import nl.elements.podwalks.data.state.AppState
import javax.inject.Inject

interface SyncRemoteConfiguration {
    suspend fun sync()
}

@Reusable
class DefaultSyncRemoteConfiguration @Inject constructor(
    private val service: PodwalksService,
    private val appState: AppState,
    private val podwalkRepository: PodwalkRepository,
    private val seasonRepository: SeasonRepository,
) : SyncRemoteConfiguration {

    override suspend fun sync(): Unit = coroutineScope {
        val (minAppVersion, updates, seasons) = service.getConfig()

        listOf(
            async {
                podwalkRepository.replaceSyncUpdates(updates.toUpdatesWithPreservedOrder())

                seasonRepository.insert(
                    seasons.mapIndexed { index, season ->
                        season.toPodwalkSeason(
                            index,
                        )
                    },
                )
            },
            async {
                appState.updateMinAppVersion(minAppVersion)
            },
        ).awaitAll()
    }
}

private fun List<TourUpdateDocument>.toUpdatesWithPreservedOrder(): LinkedHashMap<Id, UpdatedAt> {
    val result = linkedMapOf<Id, UpdatedAt>()
    for (update in this) {
        result[Id(update.id)] = UpdatedAt(update.updatedAt)
    }
    return result
}
