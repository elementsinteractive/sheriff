package nl.elements.podwalks.domain.storage

import dagger.Reusable
import kotlinx.coroutines.withContext
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.domain.podwalk.DownloadResult
import nl.elements.podwalks.domain.podwalk.DownloadStatus
import nl.elements.podwalks.domain.podwalk.Downloadable
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import java.io.File
import javax.inject.Inject

interface DownloadableFileRemover {
    suspend fun <T : Downloadable<DownloadResult.OnDisk>> delete(
        downloadable: T,
        onDeleted: suspend (T, File) -> Unit,
    )
}

@Reusable
class DefaultDownloadableFileRemover @Inject constructor(
    private val logger: Logger,
    private val dispatchers: AppCoroutineDispatchers,
) : DownloadableFileRemover {
    override suspend fun <T : Downloadable<DownloadResult.OnDisk>> delete(
        downloadable: T,
        onDeleted: suspend (T, File) -> Unit,
    ) = withContext(dispatchers.io) {
        when (val status = downloadable.downloadStatus) {
            is DownloadStatus.Downloaded -> {
                logger.logDelete(downloadable, status.result)
                status.result.file.delete()
                onDeleted(downloadable, status.result.file)
            }
            DownloadStatus.NotDownloaded -> logger.logNoDelete(downloadable)
        }
    }
}
