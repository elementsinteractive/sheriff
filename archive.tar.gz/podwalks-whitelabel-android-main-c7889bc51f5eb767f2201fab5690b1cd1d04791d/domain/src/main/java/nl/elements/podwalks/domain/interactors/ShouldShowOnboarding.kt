package nl.elements.podwalks.domain.interactors

import dagger.Reusable
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.state.AppState
import javax.inject.Inject

@Reusable
class ShouldShowOnboarding @Inject constructor(
    private val state: AppState,
) {

    operator fun invoke() = state.hasFinishedOnboarding.map { it.not() }
}
