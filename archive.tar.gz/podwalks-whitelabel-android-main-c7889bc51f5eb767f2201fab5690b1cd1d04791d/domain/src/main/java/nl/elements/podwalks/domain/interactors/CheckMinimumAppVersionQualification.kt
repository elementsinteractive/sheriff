package nl.elements.podwalks.domain.interactors

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.config.AppConfiguration
import nl.elements.podwalks.data.model.domain.AppVersionQualification
import nl.elements.podwalks.data.state.AppState
import javax.inject.Inject

@Reusable
class CheckMinimumAppVersionQualification @Inject constructor(
    private val configuration: AppConfiguration,
    private val state: AppState,
) {

    operator fun invoke(): Flow<AppVersionQualification> {
        return state.remoteMinAppVersion
            .map { versionCode ->
                when {
                    versionCode == null -> AppVersionQualification.UNKNOWN
                    versionCode > configuration.versionCode ->
                        AppVersionQualification.BELOW_MINIMUM
                    else -> AppVersionQualification.PASSED
                }
            }
    }
}
