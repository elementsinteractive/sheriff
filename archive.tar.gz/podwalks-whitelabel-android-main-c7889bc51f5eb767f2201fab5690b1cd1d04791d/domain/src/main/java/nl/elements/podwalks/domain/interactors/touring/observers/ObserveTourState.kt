package nl.elements.podwalks.domain.interactors.touring.observers

import dagger.Reusable
import nl.elements.podwalks.data.store.TourGuideStore
import javax.inject.Inject

@Reusable
class ObserveTourState @Inject constructor(
    private val store: TourGuideStore,
) {

    operator fun invoke() = store.state
}
