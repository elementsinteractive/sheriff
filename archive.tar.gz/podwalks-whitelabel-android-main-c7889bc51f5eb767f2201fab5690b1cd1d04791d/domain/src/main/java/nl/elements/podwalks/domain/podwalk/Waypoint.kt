package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.domain.Coordinate
data class Waypoint(
    override val indexWithinRoute: CheckpointIndexWithinRoute,
    override val coordinates: Coordinate,
) : Point

/**
 * Internal index of a waypoint or a checkpoint.
 */
@JvmInline
value class CheckpointIndexWithinRoute(val value: Int)
