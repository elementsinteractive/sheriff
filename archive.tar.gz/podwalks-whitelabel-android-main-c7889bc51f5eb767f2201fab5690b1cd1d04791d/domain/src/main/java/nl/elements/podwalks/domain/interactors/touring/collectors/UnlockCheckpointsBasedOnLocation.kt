package nl.elements.podwalks.domain.interactors.touring.collectors

import dagger.Reusable
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.data.bus.LastKnownLocationEventBus
import nl.elements.podwalks.data.bus.TourGuidePlaybackEventBus
import nl.elements.podwalks.data.bus.TourGuidePlaybackEventBus.Event
import nl.elements.podwalks.data.model.domain.Coordinate
import nl.elements.podwalks.data.utils.GeoUtils
import nl.elements.podwalks.domain.podwalk.Checkpoint
import nl.elements.podwalks.domain.podwalk.Id
import nl.elements.podwalks.domain.podwalk.PodwalkProgressRepository
import nl.elements.podwalks.domain.podwalk.PointRepository
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject

@Reusable
class UnlockCheckpointsBasedOnLocation @Inject constructor(
    private val dispatchers: AppCoroutineDispatchers,
    private val logger: Logger,
    private val lastKnownLocationEventBus: LastKnownLocationEventBus,
    private val playbackEventBus: TourGuidePlaybackEventBus,
    private val checkpointRepository: PointRepository,
    private val progressRepository: PodwalkProgressRepository,
) {

    suspend operator fun invoke(tourId: String) = withContext(dispatchers.io) {
        val checkpoints = checkpointRepository.getCheckpoints(Id(tourId)).first()

        logger.i("Starting unlock based on location.")

        combine(
            lastKnownLocationEventBus.location
                .filterNotNull(),
            progressRepository.getCheckpointsProgressState(Id(tourId))
                .map { map -> map.filter { it.value.visited }.map { it.key.index.value } },
        ) { coordinate, progresses ->
            val inRangeCheckpoint = getInRangeCheckpointOrNull(checkpoints, coordinate)

            if (inRangeCheckpoint != null && isCheckpointUnvisited(progresses, inRangeCheckpoint)) {
                // Checkpoint is within radius, need to be unlocked
                logger.i("Should unlock next checkpoint: $inRangeCheckpoint.")
                inRangeCheckpoint
            } else {
                logger.i("Should not unlock next checkpoint: $inRangeCheckpoint.")
                null
            }
        }
            .filterNotNull()
            .distinctUntilChanged()
            .collect { checkpoint ->
                logger.i("Unlocking checkpoint with index ${checkpoint.index.value} and playing audio.")
                progressRepository.visit(Id(tourId), checkpoint)
                playbackEventBus.emit(Event.PlayNarratorTrackAtIndex(checkpoint.index.value))
            }
    }

    private fun isCheckpointUnvisited(
        progresses: List<Int>,
        inRangeCheckpoint: Checkpoint?,
    ) = progresses.contains(inRangeCheckpoint?.index?.value).not()

    private fun getInRangeCheckpointOrNull(
        checkpoints: List<Checkpoint>,
        coordinate: Coordinate,
    ) = checkpoints.firstOrNull {
        val distance = GeoUtils.calculateDistanceInMeters(
            first = coordinate,
            second = Coordinate(it.coordinates.latitude.value, it.coordinates.longitude.value),
        )

        distance <= it.triggerRadius.value
    }
}
