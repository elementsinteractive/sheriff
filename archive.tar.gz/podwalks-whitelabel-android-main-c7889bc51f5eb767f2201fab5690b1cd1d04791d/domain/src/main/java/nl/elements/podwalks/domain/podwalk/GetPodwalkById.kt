package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

interface GetPodwalkById {
    fun get(id: Id): Flow<Podwalk?>
}

@Reusable
class DefaultGetPodwalkById @Inject constructor(
    private val podwalkRepository: PodwalkRepository,
) : GetPodwalkById {

    override fun get(id: Id): Flow<Podwalk?> =
        podwalkRepository.getPodwalk(id)
}
