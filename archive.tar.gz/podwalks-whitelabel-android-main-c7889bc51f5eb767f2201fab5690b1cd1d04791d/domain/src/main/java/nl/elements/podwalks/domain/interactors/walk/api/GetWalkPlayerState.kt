package nl.elements.podwalks.domain.interactors.walk.api

import kotlinx.coroutines.flow.Flow
import nl.elements.podwalks.domain.interactors.walk.api.GetWalkPlayerState.PlayerState.Playing.NarratorTrack
import kotlin.time.Duration

interface GetWalkPlayerState {

    fun getState(): Flow<PlayerState>

    sealed interface PlayerState {

        data object Idle : PlayerState

        sealed interface Playing : PlayerState {

            val isPaused: Boolean

            data class NarratorTrack(
                override val isPaused: Boolean,
                val chapterIndex: Int,
                val elapsedTime: Duration,
                val totalTime: Duration,
            ) : Playing

            data class BackgroundLoop(
                override val isPaused: Boolean,
            ) : Playing
        }
    }
}

val NarratorTrack.progress: Float
    get() = elapsedTime.inWholeMilliseconds.toFloat() / totalTime.inWholeMilliseconds
