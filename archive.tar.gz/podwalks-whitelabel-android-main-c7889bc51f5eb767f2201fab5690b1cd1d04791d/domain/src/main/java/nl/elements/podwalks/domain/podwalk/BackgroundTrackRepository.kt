package nl.elements.podwalks.domain.podwalk

import java.io.File

interface BackgroundTrackRepository {
    suspend fun updateDownloadState(track: BackgroundTrack, file: File?)
    suspend fun deleteUnused()
}
