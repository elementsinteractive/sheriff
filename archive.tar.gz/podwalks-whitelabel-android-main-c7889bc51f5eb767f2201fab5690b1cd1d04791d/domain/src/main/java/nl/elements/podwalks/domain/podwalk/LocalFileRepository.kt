package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow

interface LocalFileRepository {
    fun getUnusedLocalFiles(): Flow<List<LocalFile>>
    fun delete(files: List<LocalFile>)
}
