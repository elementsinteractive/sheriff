package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.domain.Coordinate
import javax.inject.Inject

interface GetWaypoints {
    fun get(id: Id): Flow<List<Coordinate>>
}

@Reusable
class DefaultGetWaypoints @Inject constructor(
    private val checkpointRepository: PointRepository,
) : GetWaypoints {

    override fun get(id: Id) = checkpointRepository.getWaypoints(id)
        .map { list -> list.map { it.coordinates } }
}
