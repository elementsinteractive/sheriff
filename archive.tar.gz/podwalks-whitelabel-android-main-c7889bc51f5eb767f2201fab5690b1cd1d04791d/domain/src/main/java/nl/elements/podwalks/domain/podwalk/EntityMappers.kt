package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.data.podwalk.ArAssetEntity
import nl.elements.podwalks.data.podwalk.ArAssetWithLocalFile
import nl.elements.podwalks.data.podwalk.BackgroundAudioTrackWithLocalFile
import nl.elements.podwalks.data.podwalk.CheckpointAudioTrackWithLocalFile
import nl.elements.podwalks.data.podwalk.CoverImageEntity
import nl.elements.podwalks.data.podwalk.ImageEntity
import nl.elements.podwalks.domain.Url
import java.io.File

internal fun BackgroundAudioTrackWithLocalFile.toBackgroundTrack() = BackgroundTrack(
    filename = Filename(track.filename),
    hash = Hash(track.hash),
    url = Url(track.url),
    downloadStatus = file.path
        ?.let { DownloadStatus.Downloaded(DownloadResult.OnDisk(File(it))) }
        ?: DownloadStatus.NotDownloaded,
)

internal fun CheckpointAudioTrackWithLocalFile.toCheckpointTrack() = CheckpointTrack(
    filename = Filename(track.filename),
    hash = Hash(track.hash),
    url = Url(track.url),
    downloadStatus = file.path
        ?.let { DownloadStatus.Downloaded(DownloadResult.OnDisk(File(it))) }
        ?: DownloadStatus.NotDownloaded,
    transcription = track.transcription,
)

internal fun List<ArAssetWithLocalFile>.toArAssets() = map { it.toArAsset() }

internal fun ArAssetWithLocalFile.toArAsset() = ArAsset(
    filename = Filename(asset.filename),
    hash = Hash(asset.hash),
    url = Url(asset.url),
    downloadStatus = file.path
        ?.let { DownloadStatus.Downloaded(DownloadResult.OnDisk(File(it))) }
        ?: DownloadStatus.NotDownloaded,
)

internal fun ArAsset.arAssetEntity(
    localFileId: Long,
    sceneId: Long,
) = ArAssetEntity(
    id = 0,
    filename = filename.value,
    hash = hash.value,
    url = url.value,
    localFileId = localFileId,
    arSceneId = sceneId,
)

internal fun List<ImageEntity>.toImages() =
    map { it.toImage() }.toSet()

internal fun ImageEntity.toImage() =
    Image(
        hash = Hash(hash),
        url = Url(url),
        statusBarColor = if (lightStatusBarIcons) StatusBarColor.LIGHT else StatusBarColor.DARK,
    )

internal fun CoverImageEntity.toImage() =
    Image(
        hash = Hash(hash),
        url = Url(url),
        statusBarColor = StatusBarColor.LIGHT,
    )

@JvmName("toImageEntity")
internal fun Image.toEntity(podwalkId: String) = ImageEntity(
    id = 0,
    hash = hash.value,
    url = url.value,
    lightStatusBarIcons = when (statusBarColor) {
        StatusBarColor.LIGHT -> true
        StatusBarColor.DARK -> false
    },
    podwalkId = podwalkId,
)

@JvmName("toCoverImageEntity")
internal fun Image.toCoverImageEntity(podwalkId: String) = CoverImageEntity(
    id = 0,
    hash = hash.value,
    url = url.value,
    podwalkId = podwalkId,
)
