@file:Suppress("TooManyFunctions")

package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.database.DatabaseTransactionRunner
import nl.elements.podwalks.data.podwalk.BackgroundAudioTrackEntity
import nl.elements.podwalks.data.podwalk.BackgroundAudioTrackWithLocalFile
import nl.elements.podwalks.data.podwalk.BackgroundTrackDao
import nl.elements.podwalks.data.podwalk.CoverImageEntity
import nl.elements.podwalks.data.podwalk.ImageDao
import nl.elements.podwalks.data.podwalk.ImageEntity
import nl.elements.podwalks.data.podwalk.LocalFileDao
import nl.elements.podwalks.data.podwalk.LocalFileEntity
import nl.elements.podwalks.data.podwalk.PodwalkDao
import nl.elements.podwalks.data.podwalk.PodwalkEntity
import nl.elements.podwalks.data.podwalk.PodwalkEntityMetadata
import nl.elements.podwalks.data.podwalk.PointEntity
import nl.elements.podwalks.data.podwalk.RemotePodwalkUpdate
import nl.elements.podwalks.data.podwalk.RemotePodwalkUpdateDao
import nl.elements.podwalks.data.podwalk.TagCrossReference
import nl.elements.podwalks.data.podwalk.TagEntity
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.Latitude
import nl.elements.podwalks.domain.Longitude
import nl.elements.podwalks.domain.Meters
import nl.elements.podwalks.domain.Name
import javax.inject.Inject
import kotlin.time.Duration.Companion.minutes

@Suppress("TooManyFunctions")
@Reusable
class RoomPodwalkRepository @Inject constructor(
    private val transactionRunner: DatabaseTransactionRunner,
    private val podwalkDao: PodwalkDao,
    private val imageDao: ImageDao,
    private val localFileDao: LocalFileDao,
    private val backgroundTrackDao: BackgroundTrackDao,
    private val remoteUpdateDao: RemotePodwalkUpdateDao,
) : PodwalkRepository {

    override fun getSyncUpdates(): Flow<LinkedHashMap<Id, UpdatedAt>> =
        remoteUpdateDao.getUpdates()
            .map { updates -> updates.toUpdatesWithPreservedOrder() }

    override suspend fun replaceSyncUpdates(updates: LinkedHashMap<Id, UpdatedAt>) = transactionRunner {
        remoteUpdateDao.delete()
        remoteUpdateDao.insertUpdates(updates.toUpdateEntities())
    }

    override val podwalks: Flow<List<Podwalk>>
        get() = podwalkDao.getPodwalks()
            .map { metadata -> podwalks(metadata) }

    override fun getPodwalk(id: Id): Flow<Podwalk?> =
        podwalkDao.getPodwalk(id.value)
            .map { metadata ->
                if (metadata != null) {
                    podwalk(
                        podwalk = metadata.podwalk,
                        images = metadata.images,
                        tags = metadata.tags,
                        audioFile = metadata.backgroundAudioFile,
                        coverImage = metadata.coverImage,
                        route = metadata.points,
                    )
                } else {
                    null
                }
            }

    private suspend fun insertBackgroundAudioTrack(podwalk: Podwalk): Long {
        val backgroundTrack = podwalk.backgroundTrack
        val localFileId = localFileDao.getByHash(backgroundTrack.hash.value).first()?.id
            ?: localFileDao.insert(LocalFileEntity(0, backgroundTrack.hash.value, null))

        val backgroundTrackId =
            backgroundTrackDao.getBackgroundTrackForPodwalk(podwalk.id.value).first()
                ?.let { entity ->
                    backgroundTrackDao.update(
                        entity.copy(
                            filename = backgroundTrack.filename.value,
                            hash = backgroundTrack.hash.value,
                            url = backgroundTrack.url.value,
                            localFileId = localFileId,
                        ),
                    )
                    entity.id
                }
                ?: backgroundTrackDao.insert(backgroundTrack.toAudioFileEntity(localFileId))

        return backgroundTrackId
    }

    private suspend fun insertOrUpdateTransaction(podwalk: Podwalk) {
        val backgroundTrackId = insertBackgroundAudioTrack(podwalk)
        insertOrUpdatePodwalk(podwalk, backgroundTrackId)
        replaceImages(podwalk)
        insertOrUpdateTags(podwalk)
    }

    private suspend fun replaceImages(podwalk: Podwalk) {
        imageDao.deleteAllForPodawlk(podwalk.id.value)
        imageDao.deleteCoverImageForPodwalk(podwalk.id.value)
        podwalk.images
            .map { it.toEntity(podwalk.id.value) }
            .let { entities -> imageDao.insert(entities) }
        podwalk.coverImage?.let {
            imageDao.insert(it.toCoverImageEntity(podwalk.id.value))
        }
    }

    private suspend fun insertOrUpdatePodwalk(
        podwalk: Podwalk,
        backgroundTrackId: Long,
    ) {
        podwalkDao.getPodwalk(podwalk.id.value).first()
            ?.let { metadata ->
                podwalkDao.update(
                    metadata.podwalk.copy(
                        updatedAt = podwalk.updatedAt.value,
                        index = podwalk.index.value,
                        name = podwalk.name.value,
                        description = podwalk.description.value,
                        locationName = podwalk.location.name,
                        startAddress = podwalk.startAddress.value,
                        durationInMinutes = podwalk.length.duration.inWholeMinutes.toInt(),
                        lengthInMeters = podwalk.length.distance.value,
                        backgroundAudioTrackId = backgroundTrackId,
                        shareContent = podwalk.share.content,
                        shareInvitationText = podwalk.share.invitationText,
                    ),
                )
            }
            ?: podwalkDao.insert(podwalk.podwalkEntity(backgroundTrackId))
    }

    private suspend fun insertOrUpdateTags(podwalk: Podwalk) {
        val tagEntities = podwalkDao.getTags()

        // Create an association between the podwalk and existing tags
        tagEntities
            .filter { entity -> podwalk.tags.map { it.value }.contains(entity.name) }
            .map { TagCrossReference(podwalk.id.value, it.id) }
            .let { podwalkDao.insertTagsCrossReferences(it) }

        // Create new tags and associate them with the podwalk
        podwalk.tags
            .filter { tag -> tagEntities.firstOrNull { it.name == tag.value } == null }
            .let { podwalkDao.insertTags(it.tagEntities()) }
            .map { TagCrossReference(podwalk.id.value, it) }
            .let { podwalkDao.insertTagsCrossReferences(it) }

        // Remove references between the tags and the podwalk that are no longer in the tags list
        tagEntities
            .filter { entity -> podwalk.tags.firstOrNull { it.value == entity.name } == null }
            .map { it.id }
            .let { podwalkDao.deleteTagCrossReference(podwalk.id.value, it) }

        podwalkDao.deleteUnreferencedTags()
    }

    override suspend fun insertOrUpdate(podwalk: Podwalk) = transactionRunner.invoke {
        insertOrUpdateTransaction(podwalk)
    }

    override suspend fun insertOrUpdate(podwalks: List<Podwalk>) = transactionRunner.invoke {
        podwalks.forEach { insertOrUpdateTransaction(it) }
    }

    override suspend fun delete(ids: List<Id>) {
        podwalkDao.delete(ids.map { it.value })
    }
}

@Suppress("DestructuringDeclarationWithTooManyEntries")
private fun podwalks(
    entities: List<PodwalkEntityMetadata>,
) = entities.map { (podwalk, images, tags, audioFile, coverImage, route) ->
    podwalk(podwalk, images, tags, audioFile, coverImage, route)
}

private fun podwalk(
    podwalk: PodwalkEntity,
    images: List<ImageEntity>,
    tags: List<TagEntity>,
    audioFile: BackgroundAudioTrackWithLocalFile,
    coverImage: CoverImageEntity?,
    route: List<PointEntity>,
) = Podwalk(
    id = Id(podwalk.id),
    index = Index(podwalk.index),
    updatedAt = UpdatedAt(podwalk.updatedAt),
    name = Name(podwalk.name),
    location = Location(podwalk.locationName, startCoordinates(route)),
    description = Description(podwalk.description),
    length = length(podwalk),
    startAddress = Address(podwalk.startAddress),
    tags = tags(tags),
    images = images.toImages(),
    backgroundTrack = audioFile.toBackgroundTrack(),
    share = PodwalkShare(
        content = podwalk.shareContent,
        invitationText = podwalk.shareInvitationText,
    ),
    coverImage = coverImage?.toImage(),
)

private fun startCoordinates(route: List<PointEntity>): Coordinate {
    val point = route.sortedBy { it.indexWithinRoute }.firstOrNull()
    val latitude = point?.latitude ?: 0.0
    val longitude = point?.longitude ?: 0.0
    return Coordinate(latitude = Latitude(latitude), longitude = Longitude(longitude))
}

private fun length(podwalk: PodwalkEntity) = Length(
    distance = Meters(podwalk.lengthInMeters),
    duration = podwalk.durationInMinutes.minutes,
)

private fun tags(tags: List<TagEntity>) = tags.map { it.name }.map { Tag(it) }.toSet()

private fun Podwalk.podwalkEntity(
    backgroundTrackId: Long,
) = PodwalkEntity(
    id = id.value,
    updatedAt = updatedAt.value,
    index = index.value,
    name = name.value,
    description = description.value,
    locationName = location.name,
    startAddress = startAddress.value,
    durationInMinutes = length.duration.inWholeMinutes.toInt(),
    lengthInMeters = length.distance.value,
    backgroundAudioTrackId = backgroundTrackId,
    shareContent = share.content,
    shareInvitationText = share.invitationText,
)

private fun List<Tag>.tagEntities() = map { it.entity() }

private fun Tag.entity() = TagEntity(
    id = 0,
    name = value,
)

private fun BackgroundTrack.toAudioFileEntity(localFileId: Long) =
    BackgroundAudioTrackEntity(
        id = 0,
        filename = filename.value,
        hash = hash.value,
        url = url.value,
        localFileId = localFileId,
    )

private fun List<RemotePodwalkUpdate>.toUpdatesWithPreservedOrder(): LinkedHashMap<Id, UpdatedAt> {
    val result = linkedMapOf<Id, UpdatedAt>()
    for (update in this) {
        result[Id(update.podwalkId)] = UpdatedAt(update.updatedAt)
    }
    return result
}

private fun LinkedHashMap<Id, UpdatedAt>.toUpdateEntities() =
    map { RemotePodwalkUpdate(it.key.value, it.value.value) }
