package nl.elements.podwalks.domain.storage

import java.io.File

data class SyncDirectories(
    val root: File,
    val checkpoint: File,
    val background: File,
    val ar: File,
)
