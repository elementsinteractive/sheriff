package nl.elements.podwalks.domain.podwalk

data class CheckpointProgress(
    val visited: Boolean,
    val played: Boolean,
)

data class PodwalkProgress(
    val visitedCheckpoints: List<Checkpoint>,
    val playedCheckpoints: List<Checkpoint>,
    val nextCheckpoint: Checkpoint?,
    val completed: Boolean,
)

fun checkpointProgress(visited: Boolean = false, played: Boolean = false) =
    CheckpointProgress(visited = visited, played = played)

internal fun progress(checkpoints: Map<Checkpoint, CheckpointProgress>) =
    PodwalkProgress(
        visitedCheckpoints = visited(checkpoints),
        playedCheckpoints = played(checkpoints),
        nextCheckpoint = nextCheckpoint(checkpoints),
        completed = completed(checkpoints),
    )

private fun nextCheckpoint(
    checkpoints: Map<Checkpoint, CheckpointProgress>,
): Checkpoint? =
    when {
        checkpoints.hasNotVisitedAny -> checkpoints.keys.toList().firstByIndex()
        completed(checkpoints) -> null
        else -> checkpoints.checkpointAfterLastVisited(
            lastVisited = checkpoints.lastVisitedCheckpoint,
        )
    }

private fun Map<Checkpoint, CheckpointProgress>.checkpointAfterLastVisited(lastVisited: Checkpoint) =
    keys.firstOrNull { it.index.value == lastVisited.index.value + 1 }

private val Map<Checkpoint, CheckpointProgress>.lastVisitedCheckpoint
    get() = filter { it.value.visited }
        .keys
        .maxBy { it.index.value }

private fun List<Checkpoint>.firstByIndex() = minBy { it.index.value }

private val Map<Checkpoint, CheckpointProgress>.hasNotVisitedAny
    get() = filterValues { it.visited }.isEmpty()

private fun visited(checkpoints: Map<Checkpoint, CheckpointProgress>) =
    checkpoints.filter { it.value.visited }.keys.toList()

private fun played(checkpoints: Map<Checkpoint, CheckpointProgress>) =
    checkpoints.filter { it.value.played }.keys.toList()

private fun completed(checkpoints: Map<Checkpoint, CheckpointProgress>) =
    checkpoints.all { it.value.visited && it.value.played }
