package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.data.model.response.SeasonDocument
import nl.elements.podwalks.data.model.response.TourDocument
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.Latitude
import nl.elements.podwalks.domain.Longitude
import nl.elements.podwalks.domain.Meters
import nl.elements.podwalks.domain.Name
import nl.elements.podwalks.domain.Url
import kotlin.time.Duration.Companion.minutes

internal fun TourDocument.toPodwalk(index: Int) =
    Podwalk(
        id = Id(id),
        index = Index(index.toInt()),
        updatedAt = UpdatedAt(deepUpdateAt),
        name = Name(name),
        location = Location(locationName, startingCoordinates()),
        description = Description(description),
        length = Length(
            distance = Meters(length.inMeters.toInt()),
            duration = length.inMinutes.minutes,
        ),
        startAddress = Address(startLocationAddress),
        tags = tags.map { Tag(it.tag) }.toSet(),
        images = images.map { image ->
            Image(
                hash = Hash(image.file.checksum),
                url = Url(image.file.url),
                statusBarColor = if (image.file.lightStatusBar) StatusBarColor.LIGHT else StatusBarColor.DARK,
            )
        }.toSet(),
        backgroundTrack = BackgroundTrack(
            filename = Filename(backgroundTrack.filename),
            hash = Hash(backgroundTrack.checksum),
            url = Url(backgroundTrack.url),
            downloadStatus = DownloadStatus.NotDownloaded,
        ),
        share = PodwalkShare(
            content = finishedTourScreen.content,
            invitationText = finishedTourScreen.shareText,
        ),
        coverImage = coverImage?.let {
            Image(
                hash = Hash(it.checksum),
                url = Url(it.url),
                statusBarColor = StatusBarColor.LIGHT,
            )
        },
    )

internal fun TourDocument.Point.toCheckpoint(indexWithinRoute: Int, index: Int) =
    requireNotNull(checkpoint).let { checkpoint ->
        Checkpoint(
            index = CheckpointIndex(index),
            indexWithinRoute = CheckpointIndexWithinRoute(indexWithinRoute),
            name = ChapterName(checkpoint.name ?: ""),
            triggerRadius = Meters(checkpoint.triggerRadiusInMeters.toInt()),
            coordinates = Coordinate(
                latitude = Latitude(location[1]),
                longitude = Longitude(location[0]),
            ),
            track = requireNotNull(checkpoint.narratorTrack).let {
                CheckpointTrack(
                    filename = Filename(it.filename),
                    hash = Hash(it.checksum),
                    url = Url(it.url),
                    downloadStatus = DownloadStatus.NotDownloaded,
                    transcription = it.transcription,
                )
            },
            arScene = checkpoint.arScene?.toArScene(),
        )
    }

internal fun TourDocument.Point.toWaypoint(indexWithinRoute: Int) =
    Waypoint(
        indexWithinRoute = CheckpointIndexWithinRoute(indexWithinRoute),
        coordinates = Coordinate(
            latitude = Latitude(location[1]),
            longitude = Longitude(location[0]),
        ),
    )

internal fun TourDocument.ArScene.toArScene(): ArScene? {
    val sceneId = sceneId
    val assets = assets
    if (sceneId == null || assets == null) {
        return null
    }

    return ArScene(
        id = ArSceneIdentifier(sceneId),
        assets = assets.map {
            ArAsset(
                filename = Filename(it.filename),
                hash = Hash(it.checksum),
                url = Url(it.url),
                downloadStatus = DownloadStatus.NotDownloaded,
            )
        },
    )
}

internal fun TourDocument.startingCoordinates(): Coordinate {
    val coordinatePair = route.points.firstOrNull()?.location
    val longitude: Double = coordinatePair?.firstOrNull() ?: 0.0
    val latitude: Double = coordinatePair?.lastOrNull() ?: 0.0
    return Coordinate(latitude = Latitude(latitude), longitude = Longitude(longitude))
}

internal fun SeasonDocument.toPodwalkSeason(index: Int) = PodwalkSeason(
    id = id,
    name = name,
    index = index,
    coverImageUrl = seasonCover.url,
    tourIds = tourIds,
)
