package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.data.podwalk.BackgroundTrackDao
import nl.elements.podwalks.data.podwalk.LocalFileDao
import java.io.File
import javax.inject.Inject

@Reusable
class RoomBackgroundTrackRepository @Inject constructor(
    private val localFileDao: LocalFileDao,
    private val backgroundTrackDao: BackgroundTrackDao,
) : BackgroundTrackRepository {

    override suspend fun updateDownloadState(track: BackgroundTrack, file: File?) {
        requireNotNull(localFileDao.getByHash(track.hash.value).first())
            .let { entity -> localFileDao.update(entity.copy(path = file?.absolutePath)) }
    }

    override suspend fun deleteUnused() {
        backgroundTrackDao.deleteUnused()
    }
}
