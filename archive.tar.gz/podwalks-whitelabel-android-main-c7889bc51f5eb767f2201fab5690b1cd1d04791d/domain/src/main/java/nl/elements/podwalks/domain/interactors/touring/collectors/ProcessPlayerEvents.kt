package nl.elements.podwalks.domain.interactors.touring.collectors

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.data.bus.TourGuidePlayerEventBus
import nl.elements.podwalks.data.store.TourGuideStore
import nl.elements.podwalks.domain.podwalk.GetPodwalkById
import nl.elements.podwalks.domain.podwalk.Id
import nl.elements.podwalks.domain.podwalk.PodwalkProgressRepository
import nl.elements.podwalks.domain.podwalk.TrackAudioPlayerEvent
import nl.elements.podwalks.extensions.calculateDuration
import javax.inject.Inject

@Reusable
class ProcessPlayerEvents @Inject constructor(
    private val logger: Logger,
    private val store: TourGuideStore,
    private val playerEventBus: TourGuidePlayerEventBus,
    private val getPodwalkById: GetPodwalkById,
    private val analyticsTracker: AnalyticsTracker,
    private val progressRepository: PodwalkProgressRepository,
) {

    suspend operator fun invoke(events: Flow<TrackAudioPlayerEvent>) = events.collect {
        when (it) {
            is TrackAudioPlayerEvent.NarratorTrackPlaying -> {
                logger.i("Narrator track playing at index ${it.index}.")
                store.setCheckpointMode(it.index)

                playerEventBus.emit(
                    TourGuidePlayerEventBus.Event.PlayingNarratorTrack(it.index),
                )
            }
            TrackAudioPlayerEvent.BackgroundTrackPlaying -> {
                logger.i("Background track playing.")
                store.setBackgroundMode()
            }
            is TrackAudioPlayerEvent.IsPlaying -> {
                logger.i("Is playing state changed to ${it.isPlaying}.")
                store.setIsPlayingState(it.isPlaying)
            }
            is TrackAudioPlayerEvent.SeekingDone -> {
                logger.i("Seeking done.")
                playerEventBus.emit(TourGuidePlayerEventBus.Event.SeekingDone)
            }
            is TrackAudioPlayerEvent.NarratorTrackPlayed -> {
                logger.i("A narrator track played.")
                trackTrackPlayed(it.index, it.count)

                markPlayed(it.index)
            }
            is TrackAudioPlayerEvent.LastNarratorTrackPlayed -> {
                logger.i("Reached end of playlist.")
                playerEventBus.emit(TourGuidePlayerEventBus.Event.EndOfPlaylist)

                trackTourFinish()
            }
        }
    }

    private suspend fun markPlayed(indexWithinRoute: Int) {
        store.state.value?.let {
            progressRepository.played(Id(it.tourId), indexWithinRoute)
        }
    }

    private fun trackTrackPlayed(index: Int, count: Int) {
        store.state.value?.let {
            analyticsTracker.track(AnalyticsEvent.CompleteCheckpoint(it.tourId, index + 1, count))
        }
    }

    private suspend fun trackTourFinish() {
        store.state.value?.let {
            val durationValue = calculateDuration(it.startTimeInMs)

            getPodwalkById.get(Id(it.tourId)).first()?.let { podwalk ->
                analyticsTracker.track(AnalyticsEvent.PodwalkDuration(podwalk.name.value, durationValue))
                analyticsTracker.track(AnalyticsEvent.FinishPodwalk(podwalk.name.value))
            }
        }
    }
}
