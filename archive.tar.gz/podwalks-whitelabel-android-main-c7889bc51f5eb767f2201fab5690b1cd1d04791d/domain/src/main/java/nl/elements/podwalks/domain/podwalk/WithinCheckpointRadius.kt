package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import nl.elements.podwalks.data.bus.LastKnownLocationEventBus
import nl.elements.podwalks.data.model.domain.Coordinate
import nl.elements.podwalks.data.model.domain.LegacyCoordinate
import nl.elements.podwalks.data.utils.GeoUtils
import nl.elements.podwalks.utils.inject.LegacyPodwalkApi
import javax.inject.Inject

interface WithinCheckpointRadius {
    fun withinRadius(id: Id): Flow<Checkpoint?>
}

@Reusable
class DefaultWithinCheckpointRadius @Inject constructor(
    private val locationBus: LastKnownLocationEventBus,
    private val repository: PointRepository,
) : WithinCheckpointRadius {

    @OptIn(LegacyPodwalkApi::class)
    override fun withinRadius(id: Id) =
        combine(
            locationBus.location,
            repository.getCheckpoints(id),
        ) { location, checkpoints ->
            location?.let { checkpoints.firstInTriggerRadiusOrNull(it) }
        }

    @OptIn(LegacyPodwalkApi::class)
    private fun List<Checkpoint>.firstInTriggerRadiusOrNull(coordinate: LegacyCoordinate) =
        firstOrNull {
            val distance = GeoUtils.calculateDistanceInMeters(
                first = coordinate,
                second = Coordinate(it.coordinates.latitude.value, it.coordinates.longitude.value),
            )

            distance <= it.triggerRadius.value
        }
}
