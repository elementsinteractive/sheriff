package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.Meters

data class Checkpoint(
    val index: CheckpointIndex,
    override val indexWithinRoute: CheckpointIndexWithinRoute,
    val name: ChapterName,
    val triggerRadius: Meters,
    override val coordinates: Coordinate,
    val track: CheckpointTrack,
    val arScene: ArScene?,
) : Point

@JvmInline
value class ChapterName(val value: String)

/**
 * Logical index for checkpoints. All waypoints have '-1' as an index.
 */
@JvmInline
value class CheckpointIndex(val value: Int)
