package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.zip
import javax.inject.Inject

interface GetDownloadStates {
    fun get(): Flow<Map<Id, DownloadState>>
}

@Reusable
class DefaultGetDownloadStates @Inject constructor(
    private val podwalkRepository: PodwalkRepository,
    private val pointRepository: PointRepository,
) : GetDownloadStates {

    private val podwalks: Flow<List<Podwalk>>
        get() = podwalkRepository.podwalks

    private val checkpoints: Flow<Map<Id, List<Checkpoint>>>
        get() = pointRepository.getCheckpoints()

    override fun get(): Flow<Map<Id, DownloadState>> =
        podwalks.zip(checkpoints) { podwalks, checkpoints ->
            podwalks
                .associateWith { walk -> checkpoints[walk.id] ?: emptyList() }
                .mapValues { (podwalk, checkpoints) -> downloadState(podwalk, checkpoints) }
                .mapKeys { it.key.id }
        }
}
