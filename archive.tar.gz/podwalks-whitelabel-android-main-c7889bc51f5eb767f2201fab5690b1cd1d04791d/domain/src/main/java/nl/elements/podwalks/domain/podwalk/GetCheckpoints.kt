package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

interface GetCheckpoints {
    fun get(id: Id): Flow<List<Checkpoint>>
}

@Reusable
class DefaultGetCheckpoints @Inject constructor(
    private val checkpointRepository: PointRepository,
) : GetCheckpoints {

    override fun get(id: Id) = checkpointRepository.getCheckpoints(id)
}
