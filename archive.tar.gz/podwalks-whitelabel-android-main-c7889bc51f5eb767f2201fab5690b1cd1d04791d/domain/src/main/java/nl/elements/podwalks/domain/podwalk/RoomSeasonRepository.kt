package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.database.DatabaseTransactionRunner
import nl.elements.podwalks.data.database.PodwalkSeasonCrossReference
import nl.elements.podwalks.data.podwalk.SeasonDao
import nl.elements.podwalks.data.podwalk.SeasonEntity
import nl.elements.podwalks.data.podwalk.SeasonEntityMetadata
import javax.inject.Inject

class RoomSeasonRepository @Inject constructor(
    private val seasonDao: SeasonDao,
    private val transactionRunner: DatabaseTransactionRunner,
) : SeasonRepository {

    override suspend fun insert(seasons: List<PodwalkSeason>) {
        transactionRunner {
            seasonDao.deleteSeasons()
            seasonDao.insert(seasons.map { it.seasonEntity() })

            seasonDao.deletePodwalkSeasonCrossReferences()

            seasons.map { season ->
                seasonDao.insertPodwalkSeasonCrossReferences(
                    season.tourIds.map { PodwalkSeasonCrossReference(it, season.id) },
                )
            }
        }
    }

    override fun getSeasons(): Flow<List<PodwalkSeason>> =
        seasonDao.getSeasons().map { metadata -> seasons(metadata) }
}

private fun seasons(
    entities: List<SeasonEntityMetadata>,
) = entities.map(::season)

private fun season(metadata: SeasonEntityMetadata) = PodwalkSeason(
    id = metadata.season.id,
    name = metadata.season.name,
    index = metadata.season.index,
    coverImageUrl = metadata.season.coverImageUrl,
    tourIds = metadata.podwalks.map { it.id },
)

private fun PodwalkSeason.seasonEntity() =
    SeasonEntity(
        id = id,
        index = index,
        name = name,
        coverImageUrl = coverImageUrl,
    )
