package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow

@Suppress("TooManyFunctions")
interface PodwalkRepository {
    fun getSyncUpdates(): Flow<LinkedHashMap<Id, UpdatedAt>>
    suspend fun replaceSyncUpdates(versions: LinkedHashMap<Id, UpdatedAt>)
    val podwalks: Flow<List<Podwalk>>
    fun getPodwalk(id: Id): Flow<Podwalk?>
    suspend fun insertOrUpdate(podwalk: Podwalk)
    suspend fun insertOrUpdate(podwalks: List<Podwalk>)
    suspend fun delete(ids: List<Id>)
}
