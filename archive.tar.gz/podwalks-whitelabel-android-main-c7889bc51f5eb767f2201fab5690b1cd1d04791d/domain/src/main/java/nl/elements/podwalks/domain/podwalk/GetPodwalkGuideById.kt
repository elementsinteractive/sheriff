package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

interface GetPodwalkGuideById {
    fun get(id: Id): Flow<PodwalkGuide>
}

@Reusable
class DefaultGetGuideById @Inject constructor(
    private val getProgress: GetProgress,
    private val podwalkRepository: PodwalkRepository,
    private val pointRepository: PointRepository,
) : GetPodwalkGuideById {
    override fun get(id: Id) = combine(
        podwalkRepository.getPodwalk(id).filterNotNull(),
        pointRepository.getCheckpoints(id),
        getProgress.get(id),
    ) { podwalk, checkpoints, progress ->
        PodwalkGuide(
            podwalk = podwalk,
            progress = progress,
            checkpoints = checkpoints,
        )
    }
}
