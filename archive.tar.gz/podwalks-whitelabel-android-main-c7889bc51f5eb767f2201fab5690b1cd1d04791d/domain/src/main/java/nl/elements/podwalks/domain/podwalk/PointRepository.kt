package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow
import nl.elements.podwalks.domain.Coordinate

interface Point {
    val indexWithinRoute: CheckpointIndexWithinRoute
    val coordinates: Coordinate
}

interface PointRepository {
    fun getCheckpoints(): Flow<Map<Id, List<Checkpoint>>>
    fun getCheckpoints(podwalkId: Id): Flow<List<Checkpoint>>
    fun getWaypoints(podwalkId: Id): Flow<List<Waypoint>>
    suspend fun insert(podwalkId: Id, points: List<Point>)
}
