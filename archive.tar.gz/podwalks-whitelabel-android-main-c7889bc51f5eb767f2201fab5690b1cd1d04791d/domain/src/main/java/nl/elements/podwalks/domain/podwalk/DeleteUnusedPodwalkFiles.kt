package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject

interface DeleteUnusedPodwalkFiles {
    suspend fun delete()
}

class DefaultDeleteUnusedPodwalkFiles @Inject constructor(
    private val dispatchers: AppCoroutineDispatchers,
    private val localFileRepository: LocalFileRepository,
    private val backgroundTrackRepository: BackgroundTrackRepository,
) : DeleteUnusedPodwalkFiles {

    override suspend fun delete(): Unit = withContext(dispatchers.io) {
        backgroundTrackRepository.deleteUnused()

        val unused = localFileRepository.getUnusedLocalFiles().first()

        unused
            .mapNotNull { it.file }
            .forEach { it.delete() }

        localFileRepository.delete(unused)
    }
}
