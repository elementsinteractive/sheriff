package nl.elements.podwalks.domain.podwalk

@JvmInline
value class ArSceneIdentifier(val value: String)

data class ArScene(
    val id: ArSceneIdentifier,
    val assets: List<ArAsset>,
)
