package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.podwalk.LocalFileDao
import java.io.File
import javax.inject.Inject

@Reusable
class RoomLocalFileRepository @Inject constructor(
    private val localFileDao: LocalFileDao,
) : LocalFileRepository {

    override fun getUnusedLocalFiles() =
        localFileDao.getUnusedFiles()
            .map { entities ->
                entities.map { entity ->
                    LocalFile(Hash(entity.hash), entity.path?.let { path -> File(path) })
                }
            }

    override fun delete(files: List<LocalFile>) {
        localFileDao.deleteByHashes(files.map { it.hash.value })
    }
}
