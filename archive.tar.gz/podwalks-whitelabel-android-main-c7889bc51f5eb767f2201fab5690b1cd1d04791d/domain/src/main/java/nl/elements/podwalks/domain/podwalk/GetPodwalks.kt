package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

interface GetPodwalks {
    fun get(): Flow<List<Podwalk>>
}

@Reusable
class DefaultGetPodwalks @Inject constructor(
    private val podwalkRepository: PodwalkRepository,
) : GetPodwalks {

    override fun get(): Flow<List<Podwalk>> = podwalkRepository.podwalks
        .map { list -> list.sortedBy { it.index.value } }
}
