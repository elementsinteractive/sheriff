package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

interface GetProgress {
    fun get(id: Id): Flow<PodwalkProgress>
}

@Reusable
class DefaultGetProgress @Inject constructor(
    private val progressRepository: PodwalkProgressRepository,
) : GetProgress {

    override fun get(id: Id): Flow<PodwalkProgress> =
        progressRepository.getCheckpointsProgressState(id)
            .map { progress(it) }
}
