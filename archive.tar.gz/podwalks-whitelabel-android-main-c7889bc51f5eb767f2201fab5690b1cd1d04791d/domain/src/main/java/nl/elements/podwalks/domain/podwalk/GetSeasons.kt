package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

interface GetSeasons {
    fun get(): Flow<List<PodwalkSeason>>
}

@Reusable
class DefaultGetSeasons @Inject constructor(
    private val seasonRepository: SeasonRepository,
) : GetSeasons {

    override fun get(): Flow<List<PodwalkSeason>> = seasonRepository.getSeasons()
}
