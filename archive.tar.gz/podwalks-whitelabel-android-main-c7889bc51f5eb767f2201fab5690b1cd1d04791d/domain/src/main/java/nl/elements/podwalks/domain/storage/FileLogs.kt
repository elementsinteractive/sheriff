@file:Suppress("TooManyFunctions")

package nl.elements.podwalks.domain.storage

import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.domain.podwalk.ArAsset
import nl.elements.podwalks.domain.podwalk.BackgroundTrack
import nl.elements.podwalks.domain.podwalk.CheckpointTrack
import nl.elements.podwalks.domain.podwalk.DownloadResult
import nl.elements.podwalks.domain.podwalk.Downloadable
import nl.elements.podwalks.domain.podwalk.Podwalk

internal fun Logger.logPodwalkDownload(podwalk: Podwalk) =
    i("Downloading files for podwalk ${podwalk.id.value}.")

internal fun Logger.logAlreadyDownloaded(downloadable: Downloadable<*>) =
    i(
        "File already downloaded: ${downloadable.filename.value} " +
            "(${downloadable.hash.value}), skipping download.",
    )

internal fun Logger.logDownload(downloadable: Downloadable<*>) =
    i("Downloading ${downloadable.filename.value} (${downloadable.hash.value}).")

internal fun Logger.logPodwalkFileDeletion(podwalk: Podwalk) =
    i("Deleting files for podwalk ${podwalk.id.value}.")

internal fun Logger.logBackgroundTrackInUse(track: BackgroundTrack) =
    i(
        "Background track (${track.hash.value}) in use by" +
            " other downloaded podwalk(s), skipping file deletion.",
    )

internal fun Logger.logCheckpointTrackInUse(track: CheckpointTrack) =
    i(
        "Checkpoint track (${track.hash.value}) in use by" +
            " other downloaded podwalk(s), skipping file deletion.",
    )

internal fun Logger.logArAssetInUse(asset: ArAsset) =
    i(
        "AR asset (${asset.hash.value}) in use by" +
            " other downloaded podwalk(s), skipping file deletion.",
    )
internal fun Logger.logDelete(downloadable: Downloadable<*>, onDisk: DownloadResult.OnDisk) =
    i(
        "Deleting ${downloadable.filename.value} (${downloadable.hash.value}) " +
            "located at: ${onDisk.file.absolutePath}.",
    )

internal fun Logger.logNoDelete(downloadable: Downloadable<*>) =
    i(
        "File is not downloaded: ${downloadable.filename.value} " +
            "(${downloadable.hash.value}), skipping deletion.",
    )
