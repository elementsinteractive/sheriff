package nl.elements.podwalks.domain.podwalk

data class PodwalkGuide(
    val podwalk: Podwalk,
    val progress: PodwalkProgress,
    val checkpoints: List<Checkpoint>,
)
