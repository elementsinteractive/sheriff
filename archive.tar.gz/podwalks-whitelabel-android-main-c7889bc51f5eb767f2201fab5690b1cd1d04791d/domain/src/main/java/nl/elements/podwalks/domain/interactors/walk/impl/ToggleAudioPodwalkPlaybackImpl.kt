package nl.elements.podwalks.domain.interactors.walk.impl

import nl.elements.podwalks.data.store.TourGuideStore
import nl.elements.podwalks.domain.interactors.touring.effects.PausePlayback
import nl.elements.podwalks.domain.interactors.touring.effects.ResumePlayback
import nl.elements.podwalks.domain.interactors.walk.api.ToggleAudioPodwalkPlayback
import javax.inject.Inject

class ToggleAudioPodwalkPlaybackImpl @Inject constructor(
    private val tourGuideStore: TourGuideStore,
    private val pausePlayback: PausePlayback,
    private val resumePlayback: ResumePlayback,
) : ToggleAudioPodwalkPlayback {
    override suspend fun toggle() {
        tourGuideStore.state.value?.let { state ->
            if (state.playback.isPlaying) {
                pausePlayback.invoke()
            } else {
                resumePlayback.invoke()
            }
        }
    }
}
