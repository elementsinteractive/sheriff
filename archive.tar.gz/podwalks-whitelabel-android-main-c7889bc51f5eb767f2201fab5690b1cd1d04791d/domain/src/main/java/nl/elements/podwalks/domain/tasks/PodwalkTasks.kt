package nl.elements.podwalks.domain.tasks

import kotlinx.coroutines.flow.Flow
import nl.elements.podwalks.domain.Name
import nl.elements.podwalks.domain.podwalk.Id

interface PodwalkTasks {
    fun downloadPodwalk(podwalkId: Id, podwalkName: Name)

    fun isDownloadingPodwalk(podwalkId: Id): Flow<Boolean>
}
