package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.onEach
import nl.elements.mobilization.logging.Logger
import javax.inject.Inject

interface GetDownloadState {
    fun get(id: Id): Flow<DownloadState>
}

@Reusable
class DefaultGetDownloadState @Inject constructor(
    private val logger: Logger,
    private val podwalkRepository: PodwalkRepository,
    private val pointRepository: PointRepository,
) : GetDownloadState {

    override fun get(id: Id): Flow<DownloadState> =
        combine(podwalk(id), checkpoints(id), ::downloadState)
            .onEach { state -> logState(id, state) }

    private fun podwalk(id: Id) =
        podwalkRepository.getPodwalk(id).filterNotNull()

    private fun checkpoints(id: Id) =
        pointRepository.getCheckpoints(id)

    private fun logState(id: Id, state: DownloadState) =
        logger.i(
            "Download state updated for podwalk (${id.value}):" +
                " ${state.progress * PERCENTAGE_MULTIPLIER}% downloaded",
        )

    companion object {
        private const val PERCENTAGE_MULTIPLIER = 100
    }
}
