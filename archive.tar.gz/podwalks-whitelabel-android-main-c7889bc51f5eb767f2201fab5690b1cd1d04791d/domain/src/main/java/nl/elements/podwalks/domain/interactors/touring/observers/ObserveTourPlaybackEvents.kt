package nl.elements.podwalks.domain.interactors.touring.observers

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.bus.TourGuidePlaybackEventBus
import javax.inject.Inject

@Reusable
class ObserveTourPlaybackEvents @Inject constructor(
    private val eventBus: TourGuidePlaybackEventBus,
) {

    operator fun invoke(): Flow<Event> = eventBus.events
        .map {
            // Map data model to domain model
            when (it) {
                TourGuidePlaybackEventBus.Event.Pause -> Event.Pause
                TourGuidePlaybackEventBus.Event.Play -> Event.Play
                is TourGuidePlaybackEventBus.Event.Seek -> Event.Seek(it.position)
                is TourGuidePlaybackEventBus.Event.PlayNarratorTrackAtIndex ->
                    Event.PlayNarratorTrackAtIndex(it.index)
            }
        }

    sealed class Event {
        object Play : Event()
        object Pause : Event()
        data class Seek(val position: Float) : Event()
        data class PlayNarratorTrackAtIndex(val index: Int) : Event()
    }
}
