package nl.elements.podwalks.domain.interactors.touring.observers

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import nl.elements.podwalks.data.bus.TourGuideServiceSignalEventBus
import javax.inject.Inject

@Reusable
class ObserveTourGuideServiceSignals @Inject constructor(
    private val eventBus: TourGuideServiceSignalEventBus,
) {

    operator fun invoke(): Flow<TourGuideServiceSignalEventBus.Signal> = eventBus.serviceSignals
}
