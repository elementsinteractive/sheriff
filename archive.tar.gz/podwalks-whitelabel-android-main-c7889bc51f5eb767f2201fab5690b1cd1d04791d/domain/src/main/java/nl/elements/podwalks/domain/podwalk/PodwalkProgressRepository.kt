package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow

interface PodwalkProgressRepository {
    fun getAllCheckpointsProgressState(): Flow<Map<Id, Map<Checkpoint, CheckpointProgress>>>
    fun getCheckpointsProgressState(id: Id): Flow<Map<Checkpoint, CheckpointProgress>>
    suspend fun visit(podwalkId: Id, checkpoint: Checkpoint)

    suspend fun played(podwalkId: Id, indexWithinRoute: Int)
    suspend fun deleteProgressForId(id: Id)
}
