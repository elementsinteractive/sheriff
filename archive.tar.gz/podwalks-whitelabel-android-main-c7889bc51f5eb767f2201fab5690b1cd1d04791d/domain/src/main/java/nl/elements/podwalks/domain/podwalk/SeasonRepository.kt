package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow

interface SeasonRepository {
    // Getters
    fun getSeasons(): Flow<List<PodwalkSeason>>

    // Setters
    suspend fun insert(seasons: List<PodwalkSeason>)
}
