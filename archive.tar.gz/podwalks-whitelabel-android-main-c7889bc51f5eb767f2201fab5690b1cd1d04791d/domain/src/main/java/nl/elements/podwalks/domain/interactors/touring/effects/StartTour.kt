package nl.elements.podwalks.domain.interactors.touring.effects

import dagger.Reusable
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.data.bus.TourGuideServiceSignalEventBus
import nl.elements.podwalks.data.bus.TourGuideServiceSignalEventBus.Signal
import nl.elements.podwalks.data.store.TourGuideStore
import nl.elements.podwalks.domain.podwalk.GetPodwalkById
import nl.elements.podwalks.domain.podwalk.Id
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject

@Reusable
class StartTour @Inject constructor(
    private val dispatchers: AppCoroutineDispatchers,
    private val eventBus: TourGuideServiceSignalEventBus,
    private val store: TourGuideStore,
    private val getPodwalkById: GetPodwalkById,
    private val analyticsTracker: AnalyticsTracker,
) {

    suspend operator fun invoke(tourId: String) = withContext(dispatchers.io) {
        val storeState = store.state.value
        if (storeState != null) {
            if (storeState.tourId != tourId) {
                // Signal a stop for the tour guide service for the different tour
                eventBus.post(Signal.Stop)

                // Reset the tour guide state
                store.teardown()

                // Setup the state
                store.setup(tourId)

                // Signal the tour guide service we have a new tour
                eventBus.post(Signal.AlreadyRunning(tourId))

                trackStartTour(tourId)
            }
        } else {
            // Setup the state
            store.setup(tourId)

            // Signal the start the tour guide service
            eventBus.post(Signal.Start(tourId))

            trackStartTour(tourId)
        }
    }

    private suspend fun trackStartTour(tourId: String) {
        getPodwalkById.get(Id(tourId)).first()?.let {
            analyticsTracker.track(AnalyticsEvent.StartPodwalk(it.name.value))
        }
    }
}
