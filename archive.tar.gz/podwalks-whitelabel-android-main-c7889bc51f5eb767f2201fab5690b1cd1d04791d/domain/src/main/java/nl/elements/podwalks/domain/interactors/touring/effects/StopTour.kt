package nl.elements.podwalks.domain.interactors.touring.effects

import dagger.Reusable
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.data.bus.TourGuideServiceSignalEventBus
import nl.elements.podwalks.data.store.TourGuideStore
import nl.elements.podwalks.domain.podwalk.GetPodwalkById
import nl.elements.podwalks.domain.podwalk.Id
import nl.elements.podwalks.extensions.calculateDuration
import javax.inject.Inject

@Reusable
class StopTour @Inject constructor(
    private val eventBus: TourGuideServiceSignalEventBus,
    private val store: TourGuideStore,
    private val getPodwalkById: GetPodwalkById,
    private val analyticsTracker: AnalyticsTracker,
) {

    suspend operator fun invoke() {
        // Signal a stop for the tour guide service
        eventBus.post(TourGuideServiceSignalEventBus.Signal.Stop)

        trackStopTour()

        // Reset the tour guide state
        store.teardown()
    }

    private suspend fun trackStopTour() {
        store.state.value?.let {
            val durationValue = calculateDuration(it.startTimeInMs)

            getPodwalkById.get(Id(it.tourId)).first()?.let {
                analyticsTracker.track(AnalyticsEvent.PodwalkDuration(it.name.value, durationValue))
            }
        }
    }
}
