package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.podwalk.ArSceneDao
import nl.elements.podwalks.data.podwalk.LocalFileDao
import java.io.File
import javax.inject.Inject

@Reusable
class RoomArRepository @Inject constructor(
    private val localFileDao: LocalFileDao,
    private val arSceneDao: ArSceneDao,
) : ArRepository {

    override fun getArAssets(id: Id) =
        arSceneDao.getAssets(id.value)
            .map { it.toArAssets() }

    override suspend fun updateDownloadState(asset: ArAsset, file: File?) {
        requireNotNull(localFileDao.getByHash(asset.hash.value).first())
            .let { entity -> localFileDao.update(entity.copy(path = file?.absolutePath)) }
    }

    override suspend fun delete(scenes: List<ArScene>) {
        arSceneDao.delete(scenes.map { it.id.value })
    }
}
