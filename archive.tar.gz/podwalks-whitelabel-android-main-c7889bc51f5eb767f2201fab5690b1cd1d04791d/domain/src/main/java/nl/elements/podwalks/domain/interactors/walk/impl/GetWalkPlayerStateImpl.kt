package nl.elements.podwalks.domain.interactors.walk.impl

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.state.PlaybackMode
import nl.elements.podwalks.data.state.TourGuideState
import nl.elements.podwalks.data.store.TourGuideStore
import nl.elements.podwalks.domain.interactors.walk.api.GetWalkPlayerState
import nl.elements.podwalks.domain.interactors.walk.api.GetWalkPlayerState.PlayerState
import javax.inject.Inject
import kotlin.time.Duration.Companion.milliseconds

class GetWalkPlayerStateImpl @Inject constructor(
    private val tourGuideStore: TourGuideStore,
) : GetWalkPlayerState {

    override fun getState(): Flow<PlayerState> =
        tourGuideStore.state.map { state ->

            val mode = state?.playback?.mode

            when {
                state == null || mode == null -> mapToIdle()
                mode == PlaybackMode.BackgroundMode -> mapToBackgroundLoop(state)
                mode is PlaybackMode.CheckpointMode -> mapToNarratorTrack(state, mode)
                else -> mapToIdle()
            }
        }

    private fun mapToIdle() = PlayerState.Idle

    private fun mapToBackgroundLoop(state: TourGuideState) =
        PlayerState.Playing.BackgroundLoop(state.playback.isPlaying.not())

    private fun mapToNarratorTrack(
        state: TourGuideState,
        mode: PlaybackMode.CheckpointMode,
    ) = PlayerState.Playing.NarratorTrack(
        isPaused = state.playback.isPlaying.not(),
        elapsedTime = state.playback.position?.currentPositionInMs?.milliseconds ?: 0.milliseconds,
        totalTime = state.playback.position?.totalLengthInMs?.milliseconds ?: 0.milliseconds,
        chapterIndex = mode.index,
    )
}
