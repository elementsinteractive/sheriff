package nl.elements.podwalks.domain.podwalk

data class PodwalkSeason(
    val id: String,
    val name: String,
    val index: Int,
    val coverImageUrl: String,
    val tourIds: List<String>,
)
