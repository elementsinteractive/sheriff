package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.domain.Url
import java.io.File

sealed interface DownloadResult {
    @JvmInline
    value class OnDisk(val file: File) : DownloadResult
    object Processed : DownloadResult
}

sealed interface DownloadStatus<out T : DownloadResult> {

    object NotDownloaded : DownloadStatus<Nothing>

    @JvmInline
    value class Downloaded<T : DownloadResult>(val result: T) : DownloadStatus<T>
}

@JvmInline
value class Filename(val value: String)

internal fun Filename.split() = value.split('.').let { strings -> strings.first() to strings[1] }

@JvmInline
value class Hash(val value: String)

interface Downloadable<T : DownloadResult> {
    val filename: Filename
    val hash: Hash
    val url: Url
    val downloadStatus: DownloadStatus<T>
}

sealed interface AudioFile : Downloadable<DownloadResult.OnDisk>

data class CheckpointTrack(
    override val filename: Filename,
    override val hash: Hash,
    override val url: Url,
    override val downloadStatus: DownloadStatus<DownloadResult.OnDisk>,
    val transcription: String?,
) : AudioFile

data class BackgroundTrack(
    override val filename: Filename,
    override val hash: Hash,
    override val url: Url,
    override val downloadStatus: DownloadStatus<DownloadResult.OnDisk>,
) : AudioFile

data class ArAsset(
    override val filename: Filename,
    override val hash: Hash,
    override val url: Url,
    override val downloadStatus: DownloadStatus<DownloadResult.OnDisk>,
) : Downloadable<DownloadResult.OnDisk>

@JvmInline
value class DownloadState(
    val files: List<Downloadable<*>>,
)

internal fun downloadState(podwalk: Podwalk, checkpoints: List<Checkpoint>) =
    DownloadState(downloadables(podwalk, checkpoints))

internal fun downloadables(podwalk: Podwalk, checkpoints: List<Checkpoint>): List<Downloadable<*>> =
    checkpoints.map { it.track } +
        listOf(podwalk.backgroundTrack) +
        checkpoints.mapNotNull { it.arScene?.assets }.flatten()

val DownloadStatus<*>.downloaded: Boolean
    get() = this is DownloadStatus.Downloaded

val DownloadState.downloaded: Boolean
    get() = files.all { it.downloadStatus is DownloadStatus.Downloaded<*> }

val DownloadState.progress: Float
    get() = files.filter { it.downloadStatus.downloaded }.size.toFloat() / files.size
