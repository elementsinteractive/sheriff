package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import javax.inject.Inject

interface DeleteProgress {
    suspend fun delete(id: Id)
}

@Reusable
class DefaultDeleteProgress @Inject constructor(
    private val progressRepository: PodwalkProgressRepository,
) : DeleteProgress {

    override suspend fun delete(id: Id) = progressRepository.deleteProgressForId(id)
}
