package nl.elements.podwalks.domain.storage

import dagger.Reusable
import kotlinx.coroutines.flow.first
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.domain.podwalk.ArAsset
import nl.elements.podwalks.domain.podwalk.ArRepository
import nl.elements.podwalks.domain.podwalk.BackgroundTrack
import nl.elements.podwalks.domain.podwalk.BackgroundTrackRepository
import nl.elements.podwalks.domain.podwalk.Checkpoint
import nl.elements.podwalks.domain.podwalk.CheckpointTrackRepository
import nl.elements.podwalks.domain.podwalk.Downloadable
import nl.elements.podwalks.domain.podwalk.Podwalk
import nl.elements.podwalks.domain.podwalk.PointRepository
import nl.elements.podwalks.domain.podwalk.split
import java.io.File
import javax.inject.Inject

fun interface PodwalkDownloader {
    suspend fun download(podwalk: Podwalk)
}

@Reusable
class DefaultPodwalkDownloader @Inject constructor(
    private val logger: Logger,
    private val sync: SyncDirectories,
    private val downloader: Downloader,
    private val backgroundTrackRepository: BackgroundTrackRepository,
    private val pointRepository: PointRepository,
    private val checkpointTrackRepository: CheckpointTrackRepository,
    private val arRepository: ArRepository,
    private val analyticsTracker: AnalyticsTracker,
) : PodwalkDownloader {

    override suspend fun download(podwalk: Podwalk) {
        logger.logPodwalkDownload(podwalk)
        download(podwalk.backgroundTrack)
        download(pointRepository.getCheckpoints(podwalk.id).first())
        download(arRepository.getArAssets(podwalk.id).first())

        analyticsTracker.track(AnalyticsEvent.DownloadPodwalk(podwalk.name.value))
    }

    private suspend fun download(backgroundTrack: BackgroundTrack) =
        downloader.download(
            output = backgroundTrack.resolve(sync.background),
            downloadable = backgroundTrack,
            onDownloaded = { track, file ->
                backgroundTrackRepository.updateDownloadState(track, file)
            },
        )

    @JvmName("downloadCheckpoints")
    private suspend fun download(checkpoints: List<Checkpoint>) =
        checkpoints.map { it.track }
            .forEach {
                downloader.download(
                    output = it.resolve(sync.checkpoint),
                    downloadable = it,
                    onDownloaded = { track, file ->
                        checkpointTrackRepository.updateDownloadState(track, file)
                    },
                )
            }

    @JvmName("downloadArAssets")
    private suspend fun download(assets: List<ArAsset>) =
        assets.forEach {
            downloader.download(
                output = it.resolve(sync.ar),
                downloadable = it,
                onDownloaded = { asset, file ->
                    arRepository.updateDownloadState(asset, file)
                },
            )
        }
}

private fun Downloadable<*>.resolve(directory: File): File {
    val (_, extension) = filename.split()
    return directory.resolve("${hash.value}.$extension")
}

private fun ArAsset.resolve(directory: File) = directory.resolve(filename.value)
