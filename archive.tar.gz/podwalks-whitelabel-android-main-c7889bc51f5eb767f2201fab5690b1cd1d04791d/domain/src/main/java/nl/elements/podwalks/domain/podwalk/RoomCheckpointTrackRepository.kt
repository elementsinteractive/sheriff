package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.first
import nl.elements.podwalks.data.podwalk.LocalFileDao
import nl.elements.podwalks.data.podwalk.PointDao
import nl.elements.podwalks.domain.Url
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RoomCheckpointTrackRepository @Inject constructor(
    private val localFileDao: LocalFileDao,
    private val pointDao: PointDao,
) : CheckpointTrackRepository {

    override suspend fun updateDownloadState(track: CheckpointTrack, file: File?) {
        requireNotNull(localFileDao.getByHash(track.hash.value).first())
            .let { entity -> localFileDao.update(entity.copy(path = file?.absolutePath)) }
    }

    override suspend fun delete(urls: List<Url>) {
        pointDao.deleteAudioFiles(urls.map { it.value })
    }
}
