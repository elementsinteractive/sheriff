package nl.elements.podwalks.domain.interactors

import dagger.Reusable
import nl.elements.podwalks.data.state.AppState
import javax.inject.Inject

@Reusable
class FinishOnboarding @Inject constructor(private val state: AppState) {
    suspend operator fun invoke() = state.updateOnboardingState(true)
}
