package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.data.podwalk.ArSceneWithAssets
import nl.elements.podwalks.data.podwalk.CheckpointAudioTrackWithLocalFile
import nl.elements.podwalks.data.podwalk.CheckpointWithFile
import nl.elements.podwalks.data.podwalk.PointEntity
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.Latitude
import nl.elements.podwalks.domain.Longitude
import nl.elements.podwalks.domain.Meters
import nl.elements.podwalks.domain.Url
import java.io.File

internal fun List<CheckpointWithFile>.toCheckpoints() = map { it.toCheckpoint() }

internal fun CheckpointWithFile.toCheckpoint() =
    combineToCheckpoint(
        checkpoint,
        requireNotNull(checkpoint.indexWithinPodwalk),
        track,
        arSceneWithAssets,
    )

internal fun combineToCheckpoint(
    checkpoint: PointEntity,
    index: Int,
    track: CheckpointAudioTrackWithLocalFile,
    arSceneWithAssets: ArSceneWithAssets?,
) = Checkpoint(
    index = CheckpointIndex(index),
    indexWithinRoute = CheckpointIndexWithinRoute(checkpoint.indexWithinRoute),
    name = ChapterName(checkpoint.name),
    triggerRadius = Meters(checkpoint.triggerRadiusInMeters),
    coordinates = Coordinate(
        latitude = Latitude(checkpoint.latitude),
        longitude = Longitude(checkpoint.longitude),
    ),
    track = track.toCheckpointTrack(),
    arScene = arSceneWithAssets?.toArScene(),
)

internal fun ArSceneWithAssets.toArScene() = ArScene(
    id = ArSceneIdentifier(scene.name),
    assets = assets.map { (asset, file) ->
        ArAsset(
            filename = Filename(asset.filename),
            hash = Hash(asset.hash),
            url = Url(asset.url),
            downloadStatus = file.path?.let {
                DownloadStatus.Downloaded(
                    DownloadResult.OnDisk(
                        File(it),
                    ),
                )
            } ?: DownloadStatus.NotDownloaded,
        )
    },
)

internal fun List<Checkpoint>.toEntities(podwalkId: Id) = map { it.toEntity(podwalkId) }

internal fun Point.toEntity(podwalkId: Id): PointEntity {
    return when (this) {
        is Checkpoint -> toEntity(podwalkId)
        is Waypoint -> toEntity(podwalkId)
        else -> throw IllegalArgumentException("Unknown Point type")
    }
}

private fun Checkpoint.toEntity(podwalkId: Id) = PointEntity(
    id = 0,
    name = name.value,
    latitude = coordinates.latitude.value,
    longitude = coordinates.longitude.value,
    indexWithinPodwalk = index?.value,
    indexWithinRoute = indexWithinRoute.value,
    triggerRadiusInMeters = triggerRadius.value,
    podwalkId = podwalkId.value,
)

private fun Waypoint.toEntity(podwalkId: Id) = PointEntity(
    id = 0,
    name = "",
    latitude = coordinates.latitude.value,
    longitude = coordinates.longitude.value,
    indexWithinPodwalk = null,
    indexWithinRoute = indexWithinRoute.value,
    triggerRadiusInMeters = 0,
    podwalkId = podwalkId.value,
)
