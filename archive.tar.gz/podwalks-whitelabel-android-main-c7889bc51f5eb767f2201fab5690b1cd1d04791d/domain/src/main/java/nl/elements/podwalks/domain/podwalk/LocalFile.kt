package nl.elements.podwalks.domain.podwalk

import java.io.File

data class LocalFile(val hash: Hash, val file: File?)
