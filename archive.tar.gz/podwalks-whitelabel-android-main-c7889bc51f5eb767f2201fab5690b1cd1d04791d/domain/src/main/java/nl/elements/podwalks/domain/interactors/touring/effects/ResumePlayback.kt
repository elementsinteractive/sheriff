package nl.elements.podwalks.domain.interactors.touring.effects

import dagger.Reusable
import nl.elements.podwalks.data.bus.TourGuidePlaybackEventBus
import javax.inject.Inject

@Reusable
class ResumePlayback @Inject constructor(
    private val eventBus: TourGuidePlaybackEventBus,
) {

    suspend operator fun invoke() = eventBus.emit(TourGuidePlaybackEventBus.Event.Play)
}
