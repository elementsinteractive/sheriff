package nl.elements.podwalks.domain.interactors.touring.effects

import dagger.Reusable
import nl.elements.podwalks.data.bus.TourGuidePlaybackEventBus
import javax.inject.Inject

@Reusable
class ReplayCheckpoint @Inject constructor(
    private val eventBus: TourGuidePlaybackEventBus,
) {

    suspend operator fun invoke(index: Int) {
        eventBus.emit(TourGuidePlaybackEventBus.Event.PlayNarratorTrackAtIndex(index))
    }
}
