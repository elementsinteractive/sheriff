package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

interface GetAllPodwalkProgress {
    fun get(): Flow<Map<Id, PodwalkProgress>>
}

@Reusable
class DefaultGetAllPodwalkProgress @Inject constructor(
    private val progressRepository: PodwalkProgressRepository,
) : GetAllPodwalkProgress {

    override fun get(): Flow<Map<Id, PodwalkProgress>> =
        progressRepository.getAllCheckpointsProgressState()
            .map { visitState -> visitState.mapValues { progress(it.value) } }
}
