package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.database.DatabaseTransactionRunner
import nl.elements.podwalks.data.model.response.TourDocument
import nl.elements.podwalks.data.network.PodwalksService
import javax.inject.Inject

interface SyncPodwalks {
    suspend fun sync()
}

class DefaultSyncPodwalks @Inject constructor(
    private val service: PodwalksService,
    private val podwalkRepository: PodwalkRepository,
    private val pointRepository: PointRepository,
    private val transactionRunner: DatabaseTransactionRunner,
) : SyncPodwalks {

    override suspend fun sync() {
        val diff = calculateSyncDiff()

        transactionRunner {
            if (diff.syncable) {
                val documents = getPodwalkDocuments(diff)
                val idsWithIndices = diff.newOrUpdated.map { Pair(it.first.value, it.second.value) }.toList()
                savePodwalks(documents, idsWithIndices)
            }

            deletePodwalks(diff.deleted)
        }
    }

    private suspend fun calculateSyncDiff(): SyncDiff {
        val new = mutableSetOf<Pair<Id, Index>>()
        val updated = mutableSetOf<Pair<Id, Index>>()

        val localUpdates = localUpdates()
        val remoteUpdates = remoteUpdates()

        for ((index, update) in remoteUpdates.toList().withIndex()) {
            val (id, updatedAt) = update
            val idWithIndex = Pair(id, Index(index))
            val localIndex = localUpdates[id]?.first?.value
            val localUpdatedAt = localUpdates[id]?.second
            when {
                !localUpdates.keys.contains(id) -> new.add(idWithIndex)
                localIndex != index || localUpdatedAt != updatedAt -> updated.add(idWithIndex)
            }
        }

        val deleted = localUpdates
            .filterNot { (id, _) -> remoteUpdates.contains(id) }
            .keys

        return SyncDiff(
            new = new,
            updated = updated,
            deleted = deleted,
        )
    }

    private suspend fun remoteUpdates() = podwalkRepository.getSyncUpdates()
        .first()

    private suspend fun localUpdates() = podwalkRepository.podwalks
        .map { podwalks -> podwalks.associate { it.id to Pair(it.index, it.updatedAt) } }
        .first()

    private suspend fun getPodwalkDocuments(diff: SyncDiff) =
        service.getTours(diff.newOrUpdated.map { it.first.value }.toList())

    private suspend fun savePodwalks(documents: List<TourDocument>, idsWithIndices: List<Pair<String, Int>>) {
        val indicesByIds = idsWithIndices.toMap()
        documents.forEach { document ->
            val podwalk = document.toPodwalk(indicesByIds.getOrDefault(document.id, 0))
            podwalkRepository.insertOrUpdate(podwalk)

            val points = mutableListOf<Point>()
            var checkpointCount: Int = 0
            document.route.points.forEach { p ->
                val indexWithinRoute = points.size
                if (p.isCheckpoint) {
                    points.add(p.toCheckpoint(indexWithinRoute, checkpointCount))
                    checkpointCount += 1
                } else {
                    points.add(p.toWaypoint(indexWithinRoute))
                }
            }
            pointRepository.insert(podwalk.id, points)
        }
    }

    private suspend fun deletePodwalks(ids: Set<Id>) {
        podwalkRepository.delete(ids.toList())
    }
}

private data class SyncDiff(
    val new: Set<Pair<Id, Index>>,
    val updated: Set<Pair<Id, Index>>,
    val deleted: Set<Id>,
)

private val SyncDiff.newOrUpdated
    get() = new + updated

private val SyncDiff.syncable
    get() = newOrUpdated.isNotEmpty()
