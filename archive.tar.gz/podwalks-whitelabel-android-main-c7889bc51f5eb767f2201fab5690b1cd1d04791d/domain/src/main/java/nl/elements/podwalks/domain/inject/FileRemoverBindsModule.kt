package nl.elements.podwalks.domain.inject

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import nl.elements.podwalks.domain.storage.DefaultDownloadableFileRemover
import nl.elements.podwalks.domain.storage.DefaultPodwalkFileRemover
import nl.elements.podwalks.domain.storage.DownloadableFileRemover
import nl.elements.podwalks.domain.storage.PodwalkFileRemover

@Module
@InstallIn(SingletonComponent::class)
abstract class FileRemoverBindsModule {

    @Binds
    abstract fun fileRemover(remover: DefaultDownloadableFileRemover): DownloadableFileRemover

    @Binds
    abstract fun podwalkFileRemover(remover: DefaultPodwalkFileRemover): PodwalkFileRemover
}
