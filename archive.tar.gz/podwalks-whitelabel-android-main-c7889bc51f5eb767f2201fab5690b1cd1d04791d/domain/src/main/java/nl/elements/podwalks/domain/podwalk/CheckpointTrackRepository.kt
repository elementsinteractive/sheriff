package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.domain.Url
import java.io.File

interface CheckpointTrackRepository {
    suspend fun updateDownloadState(track: CheckpointTrack, file: File?)
    suspend fun delete(urls: List<Url>)
}
