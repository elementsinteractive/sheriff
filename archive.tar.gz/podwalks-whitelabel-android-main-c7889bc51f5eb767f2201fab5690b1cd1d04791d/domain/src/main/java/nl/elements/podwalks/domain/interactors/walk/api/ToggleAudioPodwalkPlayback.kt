package nl.elements.podwalks.domain.interactors.walk.api

interface ToggleAudioPodwalkPlayback {
    suspend fun toggle()
}
