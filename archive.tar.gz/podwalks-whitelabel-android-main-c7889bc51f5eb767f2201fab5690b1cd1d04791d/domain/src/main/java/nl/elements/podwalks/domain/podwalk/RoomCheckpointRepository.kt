package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.database.DatabaseTransactionRunner
import nl.elements.podwalks.data.podwalk.ArSceneDao
import nl.elements.podwalks.data.podwalk.ArSceneEntity
import nl.elements.podwalks.data.podwalk.CheckpointAudioTrackEntity
import nl.elements.podwalks.data.podwalk.LocalFileDao
import nl.elements.podwalks.data.podwalk.LocalFileEntity
import nl.elements.podwalks.data.podwalk.PointDao
import javax.inject.Inject
import javax.inject.Singleton

@Suppress("TooManyFunctions")
@Singleton
class RoomCheckpointRepository @Inject constructor(
    private val transactionRunner: DatabaseTransactionRunner,
    private val pointDao: PointDao,
    private val arSceneDao: ArSceneDao,
    private val localFileDao: LocalFileDao,
) : PointRepository {

    override fun getCheckpoints(): Flow<Map<Id, List<Checkpoint>>> =
        pointDao.getCheckpoints()
            .map { map ->
                map
                    .mapKeys { (podwalk, _) -> Id(podwalk.id) }
                    .mapValues { (_, checkpoints) -> checkpoints.toCheckpoints() }
            }

    override fun getCheckpoints(podwalkId: Id): Flow<List<Checkpoint>> =
        pointDao.getCheckpoints(podwalkId.value)
            .map { it.toCheckpoints() }

    override fun getWaypoints(podwalkId: Id): Flow<List<Waypoint>> =
        pointDao.getPoints(podwalkId.value)
            .map { it.toWaypoints() }

    override suspend fun insert(podwalkId: Id, points: List<Point>) =
        transactionRunner.invoke {
            pointDao.deletePointForPodwalk(podwalkId.value)
            points.forEach { point -> insertPoint(podwalkId, point) }
        }

    private suspend fun insertPoint(podwalkId: Id, point: Point) {
        val pointId = pointDao.insertPoint(point.toEntity(podwalkId))
        if (point is Checkpoint) {
            insertCheckpointTrack(point, pointId)
            point.arScene?.let { insertArScene(it, pointId) }
        }
    }

    private suspend fun insertCheckpointTrack(checkpoint: Checkpoint, pointId: Long) {
        val localFileId = localFileDao.getByHash(checkpoint.track.hash.value).first()?.id
            ?: localFileDao.insert(LocalFileEntity(0, checkpoint.track.hash.value, null))

        pointDao.insertFile(
            CheckpointAudioTrackEntity(
                id = 0,
                filename = checkpoint.track.filename.value,
                hash = checkpoint.track.hash.value,
                url = checkpoint.track.url.value,
                localFileId = localFileId,
                pointId = pointId,
                transcription = checkpoint.track.transcription,
            ),
        )
    }

    private suspend fun insertArScene(scene: ArScene, checkpointId: Long) {
        val sceneId = arSceneDao.insertScene(ArSceneEntity(0, scene.id.value, checkpointId))

        for (asset in scene.assets) {
            val localFileId = localFileDao.getByHash(asset.hash.value).first()?.id
                ?: localFileDao.insert(LocalFileEntity(0, asset.hash.value, null))

            arSceneDao.insertAsset(asset.arAssetEntity(localFileId, sceneId))
        }
    }
}
