package nl.elements.podwalks.domain.storage

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.domain.podwalk.ArAsset
import nl.elements.podwalks.domain.podwalk.ArRepository
import nl.elements.podwalks.domain.podwalk.BackgroundTrack
import nl.elements.podwalks.domain.podwalk.BackgroundTrackRepository
import nl.elements.podwalks.domain.podwalk.Checkpoint
import nl.elements.podwalks.domain.podwalk.CheckpointTrackRepository
import nl.elements.podwalks.domain.podwalk.DownloadState
import nl.elements.podwalks.domain.podwalk.Downloadable
import nl.elements.podwalks.domain.podwalk.GetDownloadStates
import nl.elements.podwalks.domain.podwalk.Id
import nl.elements.podwalks.domain.podwalk.Podwalk
import nl.elements.podwalks.domain.podwalk.PointRepository
import nl.elements.podwalks.domain.podwalk.downloaded
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject

fun interface PodwalkFileRemover {
    suspend fun delete(podwalk: Podwalk)
}

class DefaultPodwalkFileRemover @Inject constructor(
    private val logger: Logger,
    private val dispatchers: AppCoroutineDispatchers,
    private val fileRemover: DownloadableFileRemover,
    private val backgroundTrackRepository: BackgroundTrackRepository,
    private val pointRepository: PointRepository,
    private val checkpointTrackRepository: CheckpointTrackRepository,
    private val arRepository: ArRepository,
    private val downloadStates: GetDownloadStates,
    private val analyticsTracker: AnalyticsTracker,
) : PodwalkFileRemover {

    override suspend fun delete(podwalk: Podwalk): Unit = withContext(dispatchers.io) {
        logger.logPodwalkFileDeletion(podwalk)

        val downloadStates = downloadStates.get().first()

        deleteBackgroundTrack(podwalk.backgroundTrack, podwalk, downloadStates)
        deleteCheckpointTracks(
            pointRepository.getCheckpoints(podwalk.id).first(),
            podwalk,
            downloadStates,
        )
        deleteArAssets(arRepository.getArAssets(podwalk.id).first(), podwalk, downloadStates)

        analyticsTracker.track(AnalyticsEvent.DeletePodwalk(podwalk.name.value))
    }

    private suspend fun deleteBackgroundTrack(
        backgroundTrack: BackgroundTrack,
        podwalk: Podwalk,
        downloadStates: Map<Id, DownloadState>,
    ) {
        if (!backgroundTrack.inUseByOtherDownloadedPodwalk(podwalk, downloadStates)) {
            fileRemover.delete(backgroundTrack) { track, file ->
                backgroundTrackRepository
                    .updateDownloadState(track, null)
            }
        } else {
            logger.logBackgroundTrackInUse(backgroundTrack)
        }
    }

    private suspend fun deleteCheckpointTracks(
        checkpoints: List<Checkpoint>,
        podwalk: Podwalk,
        downloadStates: Map<Id, DownloadState>,
    ) = checkpoints
        .map { it.track }
        .distinctBy { it.hash }
        .forEach {
            if (!it.inUseByOtherDownloadedPodwalk(podwalk, downloadStates)) {
                fileRemover.delete(it) { track, _ ->
                    checkpointTrackRepository.updateDownloadState(track, null)
                }
            } else {
                logger.logCheckpointTrackInUse(it)
            }
        }

    private suspend fun deleteArAssets(
        assets: List<ArAsset>,
        podwalk: Podwalk,
        downloadStates: Map<Id, DownloadState>,
    ) =
        assets
            .distinctBy { it.hash }
            .forEach {
                if (!it.inUseByOtherDownloadedPodwalk(podwalk, downloadStates)) {
                    fileRemover.delete(it) { asset, _ ->
                        arRepository.updateDownloadState(asset, null)
                    }
                } else {
                    logger.logArAssetInUse(it)
                }
            }

    private fun Downloadable<*>.inUseByOtherDownloadedPodwalk(
        podwalk: Podwalk,
        downloadStates: Map<Id, DownloadState>,
    ) = downloadStates
        .filterKeys { id -> id != podwalk.id }
        .filterValues { state -> state.downloaded }
        .any { (_, state) -> state.files.firstOrNull { it.hash == hash } != null }
}
