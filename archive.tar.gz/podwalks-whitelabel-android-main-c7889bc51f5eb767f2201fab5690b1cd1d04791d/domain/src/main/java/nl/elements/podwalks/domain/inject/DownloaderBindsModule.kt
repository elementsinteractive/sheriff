package nl.elements.podwalks.domain.inject

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import nl.elements.podwalks.domain.storage.DefaultDownloader
import nl.elements.podwalks.domain.storage.DefaultPodwalkDownloader
import nl.elements.podwalks.domain.storage.Downloader
import nl.elements.podwalks.domain.storage.PodwalkDownloader

@Module
@InstallIn(SingletonComponent::class)
abstract class DownloaderBindsModule {

    @Binds
    abstract fun downloader(downloader: DefaultDownloader): Downloader

    @Binds
    abstract fun podwalkDownloader(downloader: DefaultPodwalkDownloader): PodwalkDownloader
}
