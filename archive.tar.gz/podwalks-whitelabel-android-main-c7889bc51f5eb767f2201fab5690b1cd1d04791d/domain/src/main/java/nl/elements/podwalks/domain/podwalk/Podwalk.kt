package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.Meters
import nl.elements.podwalks.domain.Name
import nl.elements.podwalks.domain.Url
import kotlin.time.Duration

@JvmInline
value class Id(val value: String)

@JvmInline
value class Index(val value: Int)

@JvmInline
value class UpdatedAt(val value: String)

data class Location(
    val name: String,
    val coordinate: Coordinate,
)

@JvmInline
value class Description(val value: String)

data class Length(
    val distance: Meters,
    val duration: Duration,
)

@JvmInline
value class Address(val value: String)

@JvmInline
value class Tag(val value: String)

enum class StatusBarColor {
    LIGHT, DARK
}

data class Image(
    val hash: Hash,
    val url: Url,
    val statusBarColor: StatusBarColor,
)

data class PodwalkShare(
    val content: String,
    val invitationText: String,
)

data class Podwalk(
    val id: Id,
    val index: Index,
    val updatedAt: UpdatedAt,
    val name: Name,
    val location: Location,
    val description: Description,
    val length: Length,
    val startAddress: Address,
    val tags: Set<Tag>,
    val images: Set<Image>,
    val backgroundTrack: BackgroundTrack,
    val share: PodwalkShare,
    val coverImage: Image?,
)
