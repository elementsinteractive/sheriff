package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.data.podwalk.PointEntity
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.Latitude
import nl.elements.podwalks.domain.Longitude

internal fun List<PointEntity>.toWaypoints() = map { it.toWaypoint() }

internal fun PointEntity.toWaypoint() =
    Waypoint(
        indexWithinRoute = CheckpointIndexWithinRoute(indexWithinRoute),
        coordinates = Coordinate(
            latitude = Latitude(latitude),
            longitude = Longitude(longitude),
        ),
    )
