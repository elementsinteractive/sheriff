package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow
import java.io.File

interface ArRepository {
    fun getArAssets(id: Id): Flow<List<ArAsset>>
    suspend fun updateDownloadState(asset: ArAsset, file: File?)
    suspend fun delete(scenes: List<ArScene>)
}
