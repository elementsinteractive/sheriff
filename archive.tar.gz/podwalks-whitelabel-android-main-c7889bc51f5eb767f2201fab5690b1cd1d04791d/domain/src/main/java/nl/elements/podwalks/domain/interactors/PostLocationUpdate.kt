package nl.elements.podwalks.domain.interactors

import dagger.Reusable
import nl.elements.podwalks.data.bus.LastKnownLocationEventBus
import nl.elements.podwalks.data.model.domain.Coordinate
import javax.inject.Inject

@Reusable
class PostLocationUpdate @Inject constructor(
    private val lastKnownLocationEventBus: LastKnownLocationEventBus,
) {
    operator fun invoke(coordinate: Coordinate) =
        lastKnownLocationEventBus.post(coordinate)
}
