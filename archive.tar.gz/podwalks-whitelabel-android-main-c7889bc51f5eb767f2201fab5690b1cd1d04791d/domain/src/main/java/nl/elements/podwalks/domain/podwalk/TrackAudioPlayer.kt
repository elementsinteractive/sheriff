package nl.elements.podwalks.domain.podwalk

import androidx.media3.session.MediaSession
import kotlinx.coroutines.flow.SharedFlow

data class PlaybackPositionChanged(
    val positionInMs: Long,
    val durationInMs: Long,
)

sealed class TrackAudioPlayerEvent {

    data class IsPlaying(val isPlaying: Boolean) : TrackAudioPlayerEvent()

    object SeekingDone : TrackAudioPlayerEvent()

    data class NarratorTrackPlaying(val index: Int) : TrackAudioPlayerEvent()
    object BackgroundTrackPlaying : TrackAudioPlayerEvent()

    data class NarratorTrackPlayed(val index: Int, val count: Int) : TrackAudioPlayerEvent()

    object LastNarratorTrackPlayed : TrackAudioPlayerEvent()
}

interface TrackAudioPlayer {
    val mediaSession: MediaSession

    val playbackEvent: SharedFlow<TrackAudioPlayerEvent>
    val playbackPosition: SharedFlow<PlaybackPositionChanged>

    fun setup(podwalkGuide: PodwalkGuide)

    fun teardown()

    fun play()
    fun pause()
    fun seek(position: Float)

    fun playNextNarratorTrack(index: Int)

    fun playWhenReady(): Boolean
}
