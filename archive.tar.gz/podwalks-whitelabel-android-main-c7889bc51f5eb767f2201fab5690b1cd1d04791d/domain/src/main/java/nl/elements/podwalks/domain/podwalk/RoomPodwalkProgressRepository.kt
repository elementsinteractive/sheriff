package nl.elements.podwalks.domain.podwalk

import dagger.Reusable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import nl.elements.podwalks.data.podwalk.CheckpointWithFile
import nl.elements.podwalks.data.podwalk.PlayedDao
import nl.elements.podwalks.data.podwalk.PlayedEntity
import nl.elements.podwalks.data.podwalk.PointDao
import nl.elements.podwalks.data.podwalk.ProgressDao
import nl.elements.podwalks.data.podwalk.ProgressEntity
import javax.inject.Inject

@Reusable
class RoomPodwalkProgressRepository @Inject constructor(
    private val pointDao: PointDao,
    private val progressDao: ProgressDao,
    private val playedDao: PlayedDao,
) : PodwalkProgressRepository {

    override fun getAllCheckpointsProgressState(): Flow<Map<Id, Map<Checkpoint, CheckpointProgress>>> {
        return pointDao.getCheckpoints().map { checkpoints ->
            checkpoints
                .mapKeys { Id(it.key.id) }
                .mapValues { (_, checkpoints) ->
                    checkpoints.associate {
                        it.toCheckpoint() to
                            CheckpointProgress(it.progressEntity != null, it.playedEntity != null)
                    }
                }
        }
    }

    override fun getCheckpointsProgressState(id: Id): Flow<Map<Checkpoint, CheckpointProgress>> =
        pointDao.getCheckpoints(id.value)
            .map { entities ->
                entities.associate { entity: CheckpointWithFile ->
                    entity.toCheckpoint() to
                        CheckpointProgress(entity.progressEntity != null, entity.playedEntity != null)
                }
            }

    override suspend fun visit(podwalkId: Id, checkpoint: Checkpoint) {
        val entity = pointDao
            .getCheckpointByIndex(
                index = checkpoint.index.value,
                podwalkId = podwalkId.value,
            )

        requireNotNull(entity) { "Cannot visit checkpoint which does not exist." }

        progressDao.insertOrUpdateProgress(ProgressEntity(entity.id))
    }

    override suspend fun played(
        podwalkId: Id,
        indexWithinRoute: Int,
    ) {
        val entity = pointDao
            .getCheckpointByIndex(
                index = indexWithinRoute,
                podwalkId = podwalkId.value,
            )

        requireNotNull(entity) { "Cannot visit checkpoint which does not exist." }

        playedDao.insertOrUpdateProgress(PlayedEntity(entity.id))
    }

    override suspend fun deleteProgressForId(id: Id) {
        progressDao.deleteAllForId(id.value)
        playedDao.deleteAllForId(id.value)
    }
}
