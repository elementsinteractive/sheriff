package nl.elements.podwalks.domain

@JvmInline
value class Meters(val value: Int)

@JvmInline
value class Latitude(val value: Double)

@JvmInline
value class Longitude(val value: Double)

data class Coordinate(
    val latitude: Latitude,
    val longitude: Longitude,
)

@JvmInline
value class Name(val value: String)

@JvmInline
value class Url(val value: String)
