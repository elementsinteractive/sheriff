package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.data.bus.LastKnownLocationEventBus
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.utils.inject.LegacyPodwalkApi
import nl.elements.podwalks.data.model.domain.Coordinate as LegacyCoordinate

@OptIn(LegacyPodwalkApi::class)
fun LastKnownLocationEventBus.post(coordinate: Coordinate) {
    post(LegacyCoordinate(coordinate.latitude.value, coordinate.longitude.value))
}
