package nl.elements.podwalks.domain.storage

import dagger.Reusable
import kotlinx.coroutines.withContext
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.data.network.PodwalksService
import nl.elements.podwalks.domain.podwalk.DownloadResult
import nl.elements.podwalks.domain.podwalk.Downloadable
import nl.elements.podwalks.domain.podwalk.downloaded
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import java.io.File
import javax.inject.Inject

interface Downloader {
    suspend fun <T : Downloadable<DownloadResult.OnDisk>> download(
        output: File,
        downloadable: T,
        onDownloaded: suspend (T, File) -> Unit,
    )
}

@Reusable
class DefaultDownloader @Inject constructor(
    private val logger: Logger,
    private val dispatchers: AppCoroutineDispatchers,
    private val service: PodwalksService,
) : Downloader {
    override suspend fun <T : Downloadable<DownloadResult.OnDisk>> download(
        output: File,
        downloadable: T,
        onDownloaded: suspend (T, File) -> Unit,
    ) = withContext(dispatchers.io) {
        if (downloadable.downloadStatus.downloaded) {
            logger.logAlreadyDownloaded(downloadable)
            return@withContext
        }

        output.prepare()

        logger.logDownload(downloadable)
        service.downloadFile(downloadable.url.value, output)

        onDownloaded(downloadable, output)
    }

    private fun File.prepare() {
        val parent = parentFile
        check(parent != null) { "Parent file was null." }
        check((parent.exists() && parent.isDirectory) || parent.mkdirs()) {
            "Parent file was not a directory or failed to create it."
        }

        if (exists()) delete()
        createNewFile()
    }
}
