package nl.elements.podwalks.domain

import android.database.Cursor
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.collections.shouldBeUnique
import io.kotest.matchers.collections.shouldHaveSize
import io.kotest.matchers.shouldBe
import io.kotest.runner.junit4.KotestTestRunner
import nl.elements.podwalks.data.database.PodwalksRoomDatabase
import nl.elements.podwalks.data.inject.RoomTransactionRunner
import nl.elements.podwalks.data.podwalk.ImageEntity
import nl.elements.podwalks.data.podwalk.TagEntity
import nl.elements.podwalks.domain.podwalk.RoomPodwalkRepository
import nl.elements.podwalks.domain.podwalk.Tag
import nl.elements.podwalks.test.repository.TestPodwalks
import nl.elements.podwalks.test.repository.podwalkRepositoryTest
import org.junit.runner.RunWith

@RunWith(KotestTestRunner::class)
class RoomPodwalkRepositoryTest : FunSpec({

    isolationMode = IsolationMode.InstancePerTest

    val database = Room
        .inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            PodwalksRoomDatabase::class.java,
        )
        .build()

    val transactionRunner = RoomTransactionRunner(database)

    val dao = database.podwalkDao()
    val updateDao = database.remoteUpdateDao()
    val backgroundTrackDao = database.backgroundTrackDao()
    val imageDao = database.imageDao()
    val localFileDao = database.localFileDao()

    val repository = RoomPodwalkRepository(
        transactionRunner = transactionRunner,
        podwalkDao = dao,
        imageDao = imageDao,
        localFileDao = localFileDao,
        backgroundTrackDao = backgroundTrackDao,
        remoteUpdateDao = updateDao,
    )

    include(podwalkRepositoryTest(repository))

    test("no duplicate TagEntities should exist when a podwalk is updated") {
        repeat(2) {
            repository.insertOrUpdate(TestPodwalks.beautifulAlmere)
            database.getTagEntities()
                .map { it.name }
                .shouldBeUnique()
                .shouldHaveSize(TestPodwalks.beautifulAlmere.tags.size)
        }
    }

    test("TagEntities that are not used should be deleted") {

        repository.insertOrUpdate(TestPodwalks.beautifulAlmere)

        val changedTags = setOf(Tag("stadswandeling"), Tag("kindvriendelijk"))
        repository.insertOrUpdate(
            TestPodwalks.beautifulAlmere.copy(tags = changedTags),
        )

        database.getTagEntities()
            .map { it.name }
            .shouldBe(changedTags.map { it.value })
    }
})

private fun PodwalksRoomDatabase.getTagEntities(): List<TagEntity> =
    query("SELECT * FROM TagEntity", null)
        .use { cursor -> cursor.entities(Cursor::toTagEntity) }

private fun PodwalksRoomDatabase.getImageEntities(): List<ImageEntity> =
    query("SELECT * FROM ImageEntity", null)
        .use { cursor -> cursor.entities(Cursor::toImageEntity) }

private fun Cursor.toTagEntity() = TagEntity(
    id = getLong(getColumnIndex("id")),
    name = getString(getColumnIndex("name")),
)

private fun Cursor.toImageEntity() = ImageEntity(
    id = getLong(getColumnIndex("id")),
    hash = getString(getColumnIndex("hash")),
    url = getString(getColumnIndex("url")),
    lightStatusBarIcons = getBoolean(getColumnIndex("lightStatusBarIcons")),
    podwalkId = getString(getColumnIndex("powdalkId")),
)

fun <T> Cursor.entities(block: (Cursor) -> T): List<T> =
    buildList {
        while (moveToNext()) {
            add(block(this@entities))
        }
    }

private fun Cursor.getBoolean(columnIndex: Int): Boolean {
    return when (val value = getInt(columnIndex)) {
        0 -> false
        1 -> true
        else -> error("$value cannot be mapped to a Boolean.")
    }
}
