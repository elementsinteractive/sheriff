package nl.elements.podwalks.domain

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.runner.junit4.KotestTestRunner
import nl.elements.podwalks.data.database.PodwalksRoomDatabase
import nl.elements.podwalks.data.inject.RoomTransactionRunner
import nl.elements.podwalks.domain.podwalk.RoomArRepository
import nl.elements.podwalks.domain.podwalk.RoomCheckpointRepository
import nl.elements.podwalks.domain.podwalk.RoomPodwalkRepository
import nl.elements.podwalks.test.repository.arScenePersistenceTest
import org.junit.runner.RunWith

@RunWith(KotestTestRunner::class)
class RoomArScenePersistenceTest : FunSpec() {

    private val database = Room
        .inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            PodwalksRoomDatabase::class.java,
        )
        .build()

    private val transactionRunner = RoomTransactionRunner(database)

    private val podwalkDao = database.podwalkDao()
    private val pointDao = database.pointDao()
    private val arSceneDao = database.arSceneDao()
    private val updateDao = database.remoteUpdateDao()
    private val backgroundTrackDao = database.backgroundTrackDao()
    private val imageDao = database.imageDao()
    private val localFileDao = database.localFileDao()

    private val podwalkRepository = RoomPodwalkRepository(
        transactionRunner = transactionRunner,
        podwalkDao = podwalkDao,
        imageDao = imageDao,
        localFileDao = localFileDao,
        backgroundTrackDao = backgroundTrackDao,
        remoteUpdateDao = updateDao,
    )
    private val checkpointRepository =
        RoomCheckpointRepository(
            transactionRunner = transactionRunner,
            pointDao = pointDao,
            arSceneDao = arSceneDao,
            localFileDao = localFileDao,
        )

    private val arRepository = RoomArRepository(localFileDao, arSceneDao)

    init {
        isolationMode = IsolationMode.InstancePerTest
        include(arScenePersistenceTest(arRepository, podwalkRepository, checkpointRepository))
    }
}
