package nl.elements.podwalks.domain.podwalk

import app.cash.turbine.test
import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkProgressRepository
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoints
import nl.elements.podwalks.test.repository.TestPodwalks

internal class GetPodwalkGuideByIdTest : FunSpec({

    isolationMode = IsolationMode.InstancePerTest

    val database = InMemoryDatabase()
    val podwalkRepository = InMemoryPodwalkRepository(database)
    val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)
    val progressRepository = InMemoryPodwalkProgressRepository(database, checkpointRepository)

    beforeEach {
        podwalkRepository.insertOrUpdate(TestPodwalks.beautifulAlmere)
        checkpointRepository.insert(
            podwalkId = TestPodwalks.beautifulAlmere.id,
            points = checkpoints,
        )
    }

    test("podwalk guide should be collected when queried by its ID") {
        val getProgress = DefaultGetProgress(progressRepository)

        DefaultGetGuideById(getProgress, podwalkRepository, checkpointRepository)
            .get(TestPodwalks.beautifulAlmere.id)
            .test {
                awaitItem().shouldBe(
                    PodwalkGuide(
                        podwalk = TestPodwalks.beautifulAlmere,
                        progress = PodwalkProgress(
                            visitedCheckpoints = emptyList(),
                            playedCheckpoints = emptyList(),
                            nextCheckpoint = checkpoints.first(),
                            completed = false,
                        ),
                        checkpoints = checkpoints,
                    ),
                )
                cancelAndIgnoreRemainingEvents()
            }
    }
})
