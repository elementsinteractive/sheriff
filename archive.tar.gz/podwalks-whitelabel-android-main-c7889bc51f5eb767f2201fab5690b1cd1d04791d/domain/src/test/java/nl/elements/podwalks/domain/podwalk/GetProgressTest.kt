package nl.elements.podwalks.domain.podwalk

import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkProgressRepository
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint1
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint2
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint3
import nl.elements.podwalks.test.repository.TestPodwalks.beautifulAlmere

internal class GetProgressTest : FunSpec({

    isolationMode = IsolationMode.InstancePerTest

    val checkpoints = listOf(checkpoint1, checkpoint2, checkpoint3)

    val database = InMemoryDatabase()
    val podwalkRepository = InMemoryPodwalkRepository(database)
    val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)
    val progressRepository = InMemoryPodwalkProgressRepository(database, checkpointRepository)
    val getProgress = DefaultGetProgress(progressRepository)

    beforeEach {
        podwalkRepository.insertOrUpdate(beautifulAlmere)
        checkpointRepository.insert(
            podwalkId = beautifulAlmere.id,
            points = checkpoints,
        )
    }

    test("progress should be uncompleted and empty by default") {
        getProgress.get(beautifulAlmere.id).first()
            .shouldBe(
                PodwalkProgress(
                    visitedCheckpoints = emptyList(),
                    playedCheckpoints = emptyList(),
                    nextCheckpoint = checkpoint1,
                    completed = false,
                ),
            )
    }

    test("progress should be returned when a checkpoint is visited") {
        progressRepository.visit(beautifulAlmere.id, checkpoint1)
        getProgress.get(beautifulAlmere.id).first()
            .shouldBe(
                PodwalkProgress(
                    visitedCheckpoints = listOf(checkpoint1),
                    playedCheckpoints = emptyList(),
                    nextCheckpoint = checkpoint2,
                    completed = false,
                ),
            )
    }

    test("progress should be completed and next chapter is null if all checkpoints are visited and played") {

        checkpoints.forEach { checkpoint ->
            progressRepository.visit(beautifulAlmere.id, checkpoint)
            progressRepository.played(beautifulAlmere.id, checkpoint.indexWithinRoute.value)
        }

        getProgress.get(beautifulAlmere.id).first()
            .shouldBe(
                PodwalkProgress(
                    visitedCheckpoints = checkpoints,
                    playedCheckpoints = checkpoints,
                    nextCheckpoint = null,
                    completed = true,
                ),
            )
    }
})
