package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import nl.elements.podwalks.data.state.AppState

class FakeAppState : AppState {

    private val _userIdentifier = MutableStateFlow<String?>(null)
    override val userIdentifier: Flow<String?>
        get() = _userIdentifier

    private val _hasFinishedOnboarding = MutableStateFlow<Boolean>(false)
    override val hasFinishedOnboarding: Flow<Boolean>
        get() = _hasFinishedOnboarding

    private val _remoteMinAppVersion = MutableStateFlow<Long?>(null)
    override val remoteMinAppVersion: Flow<Long?>
        get() = _remoteMinAppVersion

    override suspend fun updateUserIdentifier(userIdentifier: String) {
        _userIdentifier.value = userIdentifier
    }

    override suspend fun updateOnboardingState(hasFinished: Boolean) {
        _hasFinishedOnboarding.value = hasFinished
    }

    override suspend fun updateMinAppVersion(versionCode: Long) {
        _remoteMinAppVersion.value = versionCode
    }
}
