package nl.elements.podwalks.domain.podwalk

import app.cash.turbine.test
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.nulls.shouldBeNull
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestPodwalks.beautifulAlmere

internal class GetPodwalkByIdTest : FunSpec({

    test("podwalk should be collected when queried by its ID") {

        val database = InMemoryDatabase()
        val podwalkRepository = InMemoryPodwalkRepository(database)

        val podwalk = DefaultGetPodwalkById(podwalkRepository).get(beautifulAlmere.id)
        podwalk.first().shouldBeNull()
        podwalkRepository.insertOrUpdate(beautifulAlmere)
        podwalk.first().shouldBe(beautifulAlmere)
    }
})
