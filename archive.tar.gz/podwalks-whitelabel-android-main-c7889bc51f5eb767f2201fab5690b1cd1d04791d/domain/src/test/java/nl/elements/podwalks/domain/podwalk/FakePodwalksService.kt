package nl.elements.podwalks.domain.podwalk

import kotlinx.coroutines.flow.MutableStateFlow
import nl.elements.podwalks.data.model.response.ConfigDocument
import nl.elements.podwalks.data.model.response.TourDocument
import nl.elements.podwalks.data.model.response.TourUpdateDocument
import nl.elements.podwalks.data.network.PodwalksService
import nl.elements.podwalks.test.repository.TestPodwalkDocuments.beautifulAlmere
import nl.elements.podwalks.test.repository.TestPodwalkSeasons.winterIsComing
import java.io.File

class FakePodwalksService(
    initialConfig: ConfigDocument = initialConfigDocument,
    initialPodwalks: List<TourDocument> = initialPodwalkDocuments,
) : PodwalksService {

    val config = MutableStateFlow(initialConfig)
    val podwalks = MutableStateFlow(initialPodwalks)

    override suspend fun getConfig() = config.value

    override suspend fun getTours(ids: List<String>) = podwalks.value

    override suspend fun downloadFile(path: String, output: File) = Unit

    companion object {

        val initialConfigDocument
            get() = ConfigDocument(
                minAndroidVersion = 1,
                tours = listOf(
                    TourUpdateDocument(beautifulAlmere.id, beautifulAlmere.deepUpdateAt),
                ),
                seasons = listOf(
                    winterIsComing,
                ),
            )

        val initialPodwalkDocuments
            get() = listOf(beautifulAlmere)
    }
}
