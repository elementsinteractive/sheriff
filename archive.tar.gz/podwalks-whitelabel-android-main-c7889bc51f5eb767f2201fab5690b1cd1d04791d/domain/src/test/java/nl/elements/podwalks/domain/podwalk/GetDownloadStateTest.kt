package nl.elements.podwalks.domain.podwalk

import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.core.test.TestCaseOrder
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.nulls.shouldNotBeNull
import io.kotest.matchers.should
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.memory.InMemoryArRepository
import nl.elements.podwalks.memory.InMemoryBackgroundRepository
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryCheckpointTrackRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint1
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint2
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint3
import nl.elements.podwalks.test.repository.TestFiles
import nl.elements.podwalks.test.repository.TestPodwalks.beautifulAlmere

internal class GetDownloadStateTest : FunSpec({

    testOrder = TestCaseOrder.Sequential
    isolationMode = IsolationMode.SingleInstance

    val database = InMemoryDatabase()
    val podwalkRepository = InMemoryPodwalkRepository(database)
    val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)
    val checkpointTrackRepository = InMemoryCheckpointTrackRepository(database)
    val backgroundTrackRepository = InMemoryBackgroundRepository(database)
    val arRepository = InMemoryArRepository(database)

    val backgroundTrack = beautifulAlmere.backgroundTrack
    val checkpoints = listOf(checkpoint1, checkpoint2, checkpoint3)
    val arAssets = checkpoints.mapNotNull { it.arScene?.assets }.flatten()
    val downloadables = checkpoints.map { it.track } + listOf(backgroundTrack) + arAssets
    val expected = downloadables.toMutableList()

    val getDownloadState =
        DefaultGetDownloadState(DummyLogger, podwalkRepository, checkpointRepository)

    beforeTest {
        podwalkRepository.insertOrUpdate(beautifulAlmere)
        checkpointRepository.insert(
            podwalkId = beautifulAlmere.id,
            points = checkpoints,
        )
    }

    test("download state should not downloaded") {
        getDownloadState.get(beautifulAlmere.id).first()
            .shouldBe(DownloadState(expected))
            .should { state ->
                state.downloaded shouldBe false
                state.progress shouldBe 0f
            }
    }

    test("download state should update if background track is downloaded") {

        backgroundTrackRepository
            .updateDownloadState(
                track = beautifulAlmere.backgroundTrack,
                file = TestFiles.devNull,
            )

        expected[expected.indexOf(backgroundTrack)] = backgroundTrack.copyDownloaded()

        getDownloadState.get(beautifulAlmere.id).first()
            .should { state ->
                state.files.shouldContainExactly(expected)
                state.progress shouldBe (expected.downloadCount.toFloat() / downloadables.size)
                state.downloaded shouldBe false
            }
    }

    test("download state should update when checkpoints audio files are downloaded") {
        for (checkpoint in checkpoints) {

            checkpointTrackRepository
                .updateDownloadState(
                    track = checkpoint.track,
                    file = TestFiles.devNull,
                )

            expected[expected.indexOf(checkpoint.track)] = checkpoint.track.copyDownloaded()

            getDownloadState.get(beautifulAlmere.id).first()
                .should { state ->
                    state.files.shouldContainExactly(expected)
                    state.progress shouldBe (expected.downloadCount.toFloat() / downloadables.size)
                    state.downloaded shouldBe false
                }
        }
    }

    test("download state should update when AR audio assets are downloaded") {
        arAssets.shouldNotBeNull()

        for (asset in arAssets) {

            arRepository
                .updateDownloadState(
                    asset = asset,
                    file = TestFiles.devNull,
                )

            expected[expected.indexOf(asset)] = asset.copyDownloaded()

            getDownloadState.get(beautifulAlmere.id).first()
                .should { state ->
                    state.files.shouldContainExactly(expected)
                    state.progress shouldBe (expected.downloadCount.toFloat() / downloadables.size)
                }
        }
    }

    test("download state should be completed if all files are downloaded") {
        getDownloadState.get(beautifulAlmere.id).first()
            .should { state ->
                state.files.shouldContainExactly(expected)
                state.progress shouldBe 1f
                state.downloaded shouldBe true
            }
    }
})

private fun Checkpoint.copyDownloaded() =
    track.copy(
        downloadStatus = DownloadStatus.Downloaded(
            DownloadResult.OnDisk(TestFiles.devNull),
        ),
    )

private fun BackgroundTrack.copyDownloaded() =
    copy(
        downloadStatus = DownloadStatus.Downloaded(
            DownloadResult.OnDisk(TestFiles.devNull),
        ),
    )

private fun CheckpointTrack.copyDownloaded() =
    copy(
        downloadStatus = DownloadStatus.Downloaded(
            DownloadResult.OnDisk(TestFiles.devNull),
        ),
    )

private fun ArAsset.copyDownloaded() =
    copy(
        downloadStatus = DownloadStatus.Downloaded(
            DownloadResult.OnDisk(TestFiles.devNull),
        ),
    )

private val List<Downloadable<*>>.downloadCount: Int
    get() = count { it.downloadStatus is DownloadStatus.Downloaded }
