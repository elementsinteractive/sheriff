package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.data.model.response.ConfigDocument
import nl.elements.podwalks.data.model.response.TourDocument
import nl.elements.podwalks.data.model.response.TourUpdateDocument
import nl.elements.podwalks.data.network.PodwalksService
import nl.elements.podwalks.test.repository.TestPodwalkDocuments.beautifulAlmere
import java.io.File

class StubPodwalksService(
    private val config: ConfigDocument = defaultConfig,
    private val podwalks: List<TourDocument> = defaultPodwalks,
) : PodwalksService {

    override suspend fun getConfig() = config

    override suspend fun getTours(ids: List<String>) = podwalks

    override suspend fun downloadFile(path: String, output: File) = Unit

    companion object {

        val defaultConfig
            get() = ConfigDocument(
                minAndroidVersion = 1,
                tours = listOf(
                    TourUpdateDocument(beautifulAlmere.id, beautifulAlmere.deepUpdateAt),
                ),
            )

        val defaultPodwalks
            get() = listOf(beautifulAlmere)
    }
}
