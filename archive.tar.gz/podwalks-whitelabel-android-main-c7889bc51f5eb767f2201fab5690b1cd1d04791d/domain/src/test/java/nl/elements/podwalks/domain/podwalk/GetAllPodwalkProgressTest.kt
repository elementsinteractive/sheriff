package nl.elements.podwalks.domain.podwalk

import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkProgressRepository
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestCheckpoints
import nl.elements.podwalks.test.repository.TestPodwalks.beautifulAlmere

internal class GetAllPodwalkProgressTest : FunSpec({

    isolationMode = IsolationMode.InstancePerTest

    val database = InMemoryDatabase()
    val podwalkRepository = InMemoryPodwalkRepository(database)
    val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)
    val progressRepository = InMemoryPodwalkProgressRepository(database, checkpointRepository)
    val getProgress = DefaultGetAllPodwalkProgress(progressRepository)
    val progress = getProgress.get()

    val checkpoints = listOf(
        TestCheckpoints.checkpoint1,
        TestCheckpoints.checkpoint2,
        TestCheckpoints.checkpoint3,
    )

    beforeEach {
        podwalkRepository.insertOrUpdate(beautifulAlmere)
        checkpointRepository.insert(
            podwalkId = beautifulAlmere.id,
            points = checkpoints,
        )
    }

    test("progress should be collected as uncompleted") {
        progress.first().shouldBe(
            mapOf(
                beautifulAlmere.id to PodwalkProgress(
                    visitedCheckpoints = emptyList(),
                    playedCheckpoints = emptyList(),
                    nextCheckpoint = TestCheckpoints.checkpoint1,
                    completed = false,
                ),
            ),
        )
    }

    test("progress should be collected when a checkpoint is triggered") {
        progressRepository.visit(podwalkId = beautifulAlmere.id, TestCheckpoints.checkpoint1)
        progress.first().shouldBe(
            mapOf(
                beautifulAlmere.id to PodwalkProgress(
                    visitedCheckpoints = listOf(TestCheckpoints.checkpoint1),
                    playedCheckpoints = emptyList(),
                    nextCheckpoint = TestCheckpoints.checkpoint2,
                    completed = false,
                ),
            ),
        )
    }

    test("progress should be collected when checkpoint is visited and played") {
        progressRepository.visit(podwalkId = beautifulAlmere.id, TestCheckpoints.checkpoint3)
        progressRepository.played(podwalkId = beautifulAlmere.id, TestCheckpoints.checkpoint3.indexWithinRoute.value)

        progress.first().shouldBe(
            mapOf(
                beautifulAlmere.id to PodwalkProgress(
                    visitedCheckpoints = listOf(TestCheckpoints.checkpoint3),
                    playedCheckpoints = listOf(TestCheckpoints.checkpoint3),
                    nextCheckpoint = null,
                    completed = false,
                ),
            ),
        )
    }

    test("progress should be collected as complete if all checkpoints have been visited and played") {
        checkpoints.forEach {
            progressRepository.visit(podwalkId = beautifulAlmere.id, it)
            progressRepository.played(podwalkId = beautifulAlmere.id, it.indexWithinRoute.value)
        }

        progress.first().shouldBe(
            mapOf(
                beautifulAlmere.id to PodwalkProgress(
                    visitedCheckpoints = checkpoints,
                    playedCheckpoints = checkpoints,
                    nextCheckpoint = null,
                    completed = true,
                ),
            ),
        )
    }
})
