package nl.elements.podwalks.domain.podwalk

import nl.elements.podwalks.data.config.AppConfiguration
import nl.elements.podwalks.data.config.BuildType

data class StubAppConfiguration(
    override val applicationId: String = "",
    override val buildType: BuildType = BuildType.DEBUG,
    override val versionCode: Int = 1,
    override val podwalkAPIHost: String = "https://example.com",
    override val podwalkAPIKey: String = "ASDF1234",
    override val versionName: String = "debug",
) : AppConfiguration
