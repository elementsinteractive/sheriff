package nl.elements.podwalks.domain.podwalk

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.collections.shouldBeEmpty
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.data.database.DatabaseTransactionRunner
import nl.elements.podwalks.data.model.response.TourUpdateDocument
import nl.elements.podwalks.data.network.PodwalksService
import nl.elements.podwalks.domain.Name
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.memory.InMemorySeasonRepository
import nl.elements.podwalks.test.repository.TestPodwalks
import nl.elements.podwalks.test.repository.UpdateDates
import java.io.File
import java.io.IOException
import nl.elements.podwalks.test.repository.TestPodwalkDocuments.beautifulAlmere as beautifulAlmereDocument

internal class PodwalkSynchronizationTest : FunSpec() {

    private val state = FakeAppState()
    private val database = InMemoryDatabase()
    private val podwalkRepository = InMemoryPodwalkRepository(database)
    private val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)
    private val databaseTransactionRunner = object : DatabaseTransactionRunner {
        override suspend fun <T> invoke(block: suspend () -> T): T = block()
    }

    private val seasonRepository = InMemorySeasonRepository(database)

    private val service = FakePodwalksService()

    private val syncRemoteConfiguration
        get() = DefaultSyncRemoteConfiguration(
            service = service,
            appState = state,
            podwalkRepository = podwalkRepository,
            seasonRepository = seasonRepository,
        )

    private val syncPodwalks
        get() = DefaultSyncPodwalks(
            service = service,
            podwalkRepository = podwalkRepository,
            pointRepository = checkpointRepository,
            transactionRunner = databaseTransactionRunner,
        )

    init {

        isolationMode = IsolationMode.InstancePerTest

        test("podwalks should be created when syncing with service") {

            podwalkRepository.podwalks.first().shouldBeEmpty()

            syncRemoteConfiguration.sync()
            syncPodwalks.sync()

            podwalkRepository.podwalks.first().shouldBe(
                listOf(
                    TestPodwalks.beautifulAlmere,
                ),
            )
        }

        test("podwalk should be updated if version changed") {

            syncRemoteConfiguration.sync()
            syncPodwalks.sync()

            podwalkRepository.podwalks.first()
                .shouldBe(listOf(TestPodwalks.beautifulAlmere))

            service.apply {
                config.value = FakePodwalksService.initialConfigDocument.copy(
                    tours = listOf(
                        TourUpdateDocument(beautifulAlmereDocument.id, UpdateDates.DATE_3),
                    ),
                )
                podwalks.value = listOf(
                    beautifulAlmereDocument.copy(name = "Always Almere"),
                )
            }

            syncRemoteConfiguration.sync()
            syncPodwalks.sync()

            podwalkRepository.podwalks.first()
                .shouldBe(listOf(TestPodwalks.beautifulAlmere.copy(name = Name("Always Almere"))))
        }

        test("podwalk should not be updated if version didn't change") {

            syncRemoteConfiguration.sync()
            syncPodwalks.sync()

            podwalkRepository.podwalks.first()
                .shouldBe(listOf(TestPodwalks.beautifulAlmere))

            service.apply {
                podwalks.value = listOf(
                    beautifulAlmereDocument.copy(name = "Always Almere"),
                )
            }

            syncRemoteConfiguration.sync()
            syncPodwalks.sync()

            podwalkRepository.podwalks.first()
                .shouldBe(listOf(TestPodwalks.beautifulAlmere))
        }

        test("podwalk should not be collected if it was removed from the remote") {

            syncRemoteConfiguration.sync()
            syncPodwalks.sync()

            service.apply {
                config.value = FakePodwalksService.initialConfigDocument.copy(
                    tours = emptyList(),
                )
                podwalks.value = emptyList()
            }

            syncRemoteConfiguration.sync()
            syncPodwalks.sync()

            podwalkRepository.podwalks.first()
                .shouldBeEmpty()
        }

        test("podwalk syncing should propagate exception if an error occurs") {

            val service = object : PodwalksService {
                override suspend fun getConfig() = error("Not part of test.")

                override suspend fun getTours(ids: List<String>) =
                    throw IOException("No internet connection.")

                override suspend fun downloadFile(path: String, output: File) = Unit
            }

            syncRemoteConfiguration.sync()
            val syncPodwalks = DefaultSyncPodwalks(
                service = service,
                podwalkRepository = podwalkRepository,
                pointRepository = checkpointRepository,
                transactionRunner = databaseTransactionRunner,
            )

            shouldThrow<IOException> {
                syncPodwalks.sync()
            }
        }
    }
}
