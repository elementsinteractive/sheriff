package nl.elements.podwalks.domain.podwalk

import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.maps.shouldBeEmpty
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.data.model.domain.AppVersionQualification
import nl.elements.podwalks.data.model.response.TourUpdateDocument
import nl.elements.podwalks.domain.interactors.CheckMinimumAppVersionQualification
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.memory.InMemorySeasonRepository
import nl.elements.podwalks.test.repository.TestPodwalkDocuments
import nl.elements.podwalks.test.repository.TestPodwalkSeasons
import nl.elements.podwalks.test.repository.TestPodwalks
import nl.elements.podwalks.test.repository.UpdateDates

internal class RemoteConfigurationSynchronizationTest : FunSpec() {

    private val appState = FakeAppState()
    private val database = InMemoryDatabase()
    private val podwalkRepository = InMemoryPodwalkRepository(database)

    private val seasonRepository = InMemorySeasonRepository(database)

    init {

        isolationMode = IsolationMode.InstancePerTest

        test("remote podwalk updates should be collected when syncing with remote service") {

            val syncPodwalkVersions: SyncRemoteConfiguration = DefaultSyncRemoteConfiguration(
                service = StubPodwalksService(),
                appState = appState,
                podwalkRepository = podwalkRepository,
                seasonRepository = seasonRepository,
            )

            podwalkRepository.getSyncUpdates().first()
                .shouldBeEmpty()

            syncPodwalkVersions.sync()

            podwalkRepository.getSyncUpdates().first()
                .shouldBe(
                    mapOf(
                        TestPodwalks.beautifulAlmere.id to TestPodwalks.beautifulAlmere.updatedAt,
                    ),
                )
        }

        test("remote podwalk updates should be replaced when syncing for a second time") {

            val service = FakePodwalksService()

            val syncPodwalkVersions: SyncRemoteConfiguration = DefaultSyncRemoteConfiguration(
                service = service,
                appState = appState,
                podwalkRepository = podwalkRepository,
                seasonRepository = seasonRepository,
            )

            syncPodwalkVersions.sync()

            service.config.value = FakePodwalksService.initialConfigDocument.copy(
                tours = listOf(
                    TourUpdateDocument(TestPodwalkDocuments.beautifulAlmere.id, UpdateDates.DATE_4),
                ),
            )

            syncPodwalkVersions.sync()

            podwalkRepository.getSyncUpdates().first()
                .shouldBe(
                    mapOf(
                        TestPodwalks.beautifulAlmere.id to UpdatedAt(UpdateDates.DATE_4),
                    ),
                )
        }

        test("remote season updates should be collected when syncing with remote service") {
            val service = FakePodwalksService()

            val syncPodwalkVersions: SyncRemoteConfiguration = DefaultSyncRemoteConfiguration(
                service = service,
                appState = appState,
                podwalkRepository = podwalkRepository,
                seasonRepository = seasonRepository,
            )

            syncPodwalkVersions.sync()

            seasonRepository.getSeasons().first().shouldBe(
                listOf(
                    PodwalkSeason(
                        id = TestPodwalkSeasons.winterIsComing.id,
                        name = TestPodwalkSeasons.winterIsComing.name,
                        index = 0,
                        coverImageUrl = "",
                        tourIds = listOf(TestPodwalks.beautifulAlmere.id.value),
                    ),
                ),
            )
        }

        mapOf(
            40 to AppVersionQualification.PASSED,
            64 to AppVersionQualification.BELOW_MINIMUM,
        ).forEach { (remoteVersion, qualification) ->
            test("minimum version qualification should change to $qualification when syncing remote config") {

                val syncConfiguration: SyncRemoteConfiguration = DefaultSyncRemoteConfiguration(
                    service = StubPodwalksService(
                        config = StubPodwalksService.defaultConfig.copy(
                            minAndroidVersion = remoteVersion.toLong(),
                        ),
                    ),
                    appState = appState,
                    podwalkRepository = podwalkRepository,
                    seasonRepository = seasonRepository,
                )

                val checkVersion = CheckMinimumAppVersionQualification(
                    configuration = StubAppConfiguration(versionCode = 42),
                    state = appState,
                )

                checkVersion().first() shouldBe AppVersionQualification.UNKNOWN
                syncConfiguration.sync()
                checkVersion().first() shouldBe qualification
            }
        }
    }
}
