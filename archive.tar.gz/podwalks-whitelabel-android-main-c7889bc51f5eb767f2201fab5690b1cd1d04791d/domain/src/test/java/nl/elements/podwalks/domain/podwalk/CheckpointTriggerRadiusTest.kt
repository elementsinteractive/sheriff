package nl.elements.podwalks.domain.podwalk

import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.nulls.shouldBeNull
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.data.bus.LastKnownLocationEventBus
import nl.elements.podwalks.data.model.domain.LegacyCoordinate
import nl.elements.podwalks.domain.Coordinate
import nl.elements.podwalks.domain.Latitude
import nl.elements.podwalks.domain.Longitude
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestCheckpoints
import nl.elements.podwalks.test.repository.TestPodwalks.beautifulAlmere
import nl.elements.podwalks.utils.inject.LegacyPodwalkApi

@OptIn(LegacyPodwalkApi::class)
internal class CheckpointTriggerRadiusTest : FunSpec({

    isolationMode = IsolationMode.InstancePerTest

    val database = InMemoryDatabase()
    val podwalkRepository = InMemoryPodwalkRepository(database)
    val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)

    val locationBus = LastKnownLocationEventBus()
    val withinCheckpointRadius: WithinCheckpointRadius =
        DefaultWithinCheckpointRadius(
            locationBus = locationBus,
            repository = checkpointRepository,
        )

    beforeEach {
        podwalkRepository.insertOrUpdate(beautifulAlmere)
        checkpointRepository.insert(beautifulAlmere.id, TestCheckpoints.checkpoints)
    }

    test("checkpoint should be collected if user is within trigger radius") {

        val coordinate = Coordinate(
            latitude = Latitude(52.377520818125596),
            longitude = Longitude(5.220884512081847),
        )

        withinCheckpointRadius.withinRadius(beautifulAlmere.id)
            .first()
            .shouldBeNull()

        locationBus.post(coordinate)
        locationBus.location
            .value
            .shouldBe(LegacyCoordinate(coordinate.latitude.value, coordinate.longitude.value))

        withinCheckpointRadius.withinRadius(beautifulAlmere.id)
            .first()
            .shouldBe(TestCheckpoints.checkpoint1)
    }

    test("checkpoint should not be returned if user is not within trigger radius") {

        val coordinate = Coordinate(Latitude(0.0), Longitude(0.0))
        locationBus.post(coordinate)

        withinCheckpointRadius.withinRadius(beautifulAlmere.id)
            .first()
            .shouldBeNull()
    }
})
