package nl.elements.podwalks.domain.podwalk

import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.maps.shouldBeEmpty
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestCheckpoints
import nl.elements.podwalks.test.repository.TestPodwalks.beautifulAlmere

internal class GetDownloadStatesTest : FunSpec({

    isolationMode = IsolationMode.InstancePerTest

    test("download state should be collected") {

        val database = InMemoryDatabase()
        val podwalkRepository = InMemoryPodwalkRepository(database)
        val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)

        val downloadStates =
            DefaultGetDownloadStates(podwalkRepository, checkpointRepository).get()

        downloadStates.first().shouldBeEmpty()

        podwalkRepository.insertOrUpdate(beautifulAlmere)
        checkpointRepository.insert(
            podwalkId = beautifulAlmere.id,
            points = listOf(TestCheckpoints.checkpoint1, TestCheckpoints.checkpoint2),
        )

        downloadStates.first() shouldBe mapOf(
            beautifulAlmere.id to DownloadState(
                listOf(
                    TestCheckpoints.checkpoint1.track,
                    TestCheckpoints.checkpoint2.track,
                    beautifulAlmere.backgroundTrack,
                ) + requireNotNull(TestCheckpoints.checkpoint2.arScene?.assets),
            ),
        )
    }
})
