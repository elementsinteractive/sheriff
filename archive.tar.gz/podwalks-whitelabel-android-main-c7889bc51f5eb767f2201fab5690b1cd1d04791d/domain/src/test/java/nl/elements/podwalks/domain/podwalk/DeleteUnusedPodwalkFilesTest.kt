package nl.elements.podwalks.domain.podwalk

import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.core.test.TestScope
import io.kotest.matchers.collections.shouldBeEmpty
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.memory.InMemoryArRepository
import nl.elements.podwalks.memory.InMemoryBackgroundRepository
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryCheckpointTrackRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryLocalFileRepository
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestCheckpoints
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoints
import nl.elements.podwalks.test.repository.TestPodwalks.beautifulAlmere
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import java.io.File

@OptIn(ExperimentalStdlibApi::class)
internal class DeleteUnusedPodwalkFilesTest : FunSpec({

    isolationMode = IsolationMode.InstancePerTest

    val database = InMemoryDatabase()
    val podwalkRepository = InMemoryPodwalkRepository(database)
    val backgroundTrackRepository = InMemoryBackgroundRepository(database)
    val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)
    val checkpointTrackRepository = InMemoryCheckpointTrackRepository(database)
    val arRepository = InMemoryArRepository(database)
    val localFileRepository = InMemoryLocalFileRepository(database)

    val deleteUnusedPodwalkFiles: TestScope.() -> DeleteUnusedPodwalkFiles = {
        val dispatcher = requireNotNull(coroutineContext[CoroutineDispatcher.Key])
        DefaultDeleteUnusedPodwalkFiles(
            dispatchers = AppCoroutineDispatchers(
                io = dispatcher,
                computation = dispatcher,
                main = dispatcher,
            ),
            localFileRepository = localFileRepository,
            backgroundTrackRepository = backgroundTrackRepository,
        )
    }

    beforeEach {
        podwalkRepository.insertOrUpdate(beautifulAlmere)
        checkpointRepository.insert(beautifulAlmere.id, checkpoints)
    }

    test("!local unused checkpoint files should be deleted") {

        checkpoints.map { it.track }.forEach { track ->
            checkpointTrackRepository
                .updateDownloadState(track, File(track.filename.value))
        }

        podwalkRepository.delete(listOf(beautifulAlmere.id))
        deleteUnusedPodwalkFiles().delete()

        localFileRepository.getUnusedLocalFiles()
            .first()
            .shouldBeEmpty()
    }

    test("!local unused AR assets files should be deleted") {

        val asset = TestCheckpoints.checkpoint2.arScene!!.assets.first()
        arRepository.updateDownloadState(asset, File(asset.filename.value))

        podwalkRepository.delete(listOf(beautifulAlmere.id))
        deleteUnusedPodwalkFiles().delete()

        localFileRepository.getUnusedLocalFiles()
            .first()
            .shouldBeEmpty()
    }
})
