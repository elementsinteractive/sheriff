package nl.elements.podwalks.domain.podwalk

import app.cash.turbine.test
import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.collections.shouldBeEmpty
import io.kotest.matchers.collections.shouldNotContain
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.domain.Name
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestPodwalks

internal class GetPodwalksTest : FunSpec() {

    val database = InMemoryDatabase()
    val repository: PodwalkRepository = InMemoryPodwalkRepository(database)
    val getPodwalks: GetPodwalks = DefaultGetPodwalks(repository)

    init {
        isolationMode = IsolationMode.InstancePerTest

        test("podwalks should be collected when inserted") {

            val podwalks = getPodwalks.get()

            podwalks.first().shouldBeEmpty()
            repository.insertOrUpdate(TestPodwalks.beautifulAlmere)
            podwalks.first() shouldBe listOf(TestPodwalks.beautifulAlmere)
        }

        test("podwalk should be updated if the podwalk already exists") {
            val podwalks = getPodwalks.get()

            podwalks.first().shouldBeEmpty()

            repository.insertOrUpdate(TestPodwalks.beautifulAlmere)
            podwalks.first() shouldBe listOf(TestPodwalks.beautifulAlmere)

            val updated = TestPodwalks.beautifulAlmere
                .copy(name = Name("Wonderful Almere"))

            repository.insertOrUpdate(updated)
            podwalks.first() shouldBe listOf(updated)
        }

        test("podwalk should not be collected if it is removed") {
            val podwalks = getPodwalks.get()

            podwalks.first().shouldBeEmpty()

            repository.insertOrUpdate(TestPodwalks.beautifulAlmere)
            podwalks.first() shouldBe listOf(TestPodwalks.beautifulAlmere)

            repository.delete(listOf(TestPodwalks.beautifulAlmere.id))
            podwalks.first().shouldNotContain(TestPodwalks.beautifulAlmere)
        }
    }
}
