package nl.elements.podwalks.domain.podwalk

import io.kotest.core.spec.IsolationMode
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.collections.shouldBeEmpty
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.flow.first
import nl.elements.podwalks.memory.InMemoryCheckpointRepository
import nl.elements.podwalks.memory.InMemoryDatabase
import nl.elements.podwalks.memory.InMemoryPodwalkRepository
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint1
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint2
import nl.elements.podwalks.test.repository.TestCheckpoints.checkpoint3
import nl.elements.podwalks.test.repository.TestPodwalks.beautifulAlmere

internal class GetCheckpointsTest : FunSpec({

    isolationMode = IsolationMode.InstancePerTest

    val database = InMemoryDatabase()
    val podwalkRepository = InMemoryPodwalkRepository(database)
    val checkpointRepository = InMemoryCheckpointRepository(database, podwalkRepository)

    beforeEach {
        podwalkRepository.insertOrUpdate(beautifulAlmere)
    }

    test("checkpoints should be returned when inserted") {

        val getCheckpoints = DefaultGetCheckpoints(checkpointRepository)

        getCheckpoints.get(beautifulAlmere.id).first()
            .shouldBeEmpty()

        val checkpoints = listOf(checkpoint1, checkpoint2, checkpoint3)

        checkpointRepository.insert(
            podwalkId = beautifulAlmere.id,
            points = checkpoints,
        )

        getCheckpoints.get(beautifulAlmere.id).first() shouldBe checkpoints
    }
})
