package nl.elements.podwalks.domain.inject

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import nl.elements.podwalks.data.constant.SyncConstants
import nl.elements.podwalks.domain.storage.SyncDirectories

@Module
@InstallIn(SingletonComponent::class)
object StorageModule {

    @Provides
    fun directories(@ApplicationContext context: Context) =
        context.filesDir.resolve(SyncConstants.TOUR_DATA_DIR_NAME)
            .let { directory ->
                SyncDirectories(
                    root = directory,
                    checkpoint = directory,
                    background = directory,
                    ar = directory,
                )
            }
}
