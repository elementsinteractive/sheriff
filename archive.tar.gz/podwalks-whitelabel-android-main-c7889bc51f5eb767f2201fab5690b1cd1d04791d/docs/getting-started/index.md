

**Android Studio**

[Download Here](https://developer.android.com/studio/)


**Homebrew**

```
/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

**Fastlane**

```bash
brew install fastlane
```


## Install & start documentation

You will have to [install Python, mkdocs and mkdocs-material](https://squidfunk.github.io/mkdocs-material/getting-started/):

```shell
pip install mkdocs
pip install mkdocs-material
```

Run the development server:

```shell
mkdocs serve
```

Your site starts at `http://127.0.0.1:8000`.
