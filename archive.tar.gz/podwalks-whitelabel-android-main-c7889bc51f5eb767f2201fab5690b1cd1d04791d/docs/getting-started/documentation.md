> Ultimately, remember that _some_ documentation _always_ trumps no documentation.

This documentation is the result of hard work and passion from its creators. I know writing documentation can be tough, but as the quote above foretells, writing some is better than none.

To get familiar with writing technical documentation: Jacob Kaplan-Moss' series on [Writing Great Documentation](https://jacobian.org/series/great-documentation/) gives a brief intro on how to write technical documentation. After reading Jacob's series you will definitely become more confident to write great documentation yourself!

## Tips

The following general tips come in very handy:

- Write short paragraphs
- Write conversational, use you or we
- Use markdown code blocks for code samples
- Use diagrams - where needed - to visualize concepts
- Use a [cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) for Markdown syntax
