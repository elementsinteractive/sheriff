---
Use this file to track all dependencies required by this project.

| Dependency | Description | LICENSE
| --- | --- | --- |
| Kotlin | Since our preferred language is Kotlin we use the standard lib. | [Apache 2.0](https://github.com/JetBrains/kotlin/blob/master/license/LICENSE.txt) |
| Kotlin - Coroutines + Flow | Multithreading | [Apache 2.0](https://github.com/Kotlin/kotlinx.coroutines/blob/master/LICENSE.txt) |
| Kotlinx datetime | Datetime library | [Apache 2.0](https://github.com/Kotlin/kotlinx-datetime/blob/master/LICENSE.txt) |
| Kotlinx serialization | Json serialization library | [Apache 2.0](https://github.com/Kotlin/kotlinx.serialization/blob/master/LICENSE.txt) |
| Kotlin - Kapt | Annotation processing for certain libraries. | [Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| Compose UI | Declarative UI library | [Apache 2.0](https://cs.android.com/androidx/platform/frameworks/support/+/androidx-main:LICENSE.txt) |
| Google Support Libraries | Jetpack Libraries for various widgets / functionalities. | [Apache 2.0](https://cs.android.com/androidx/platform/frameworks/support/+/androidx-main:LICENSE.txt) |
| Google Tink | Open source library that provides cryptographic APIs | [Apache 2.0](https://github.com/google/tink/blob/master/LICENSE) |
| Ktor | Networking library | [Apache 2.0](https://github.com/ktorio/ktor/blob/main/LICENSE) |
| OkHttp with MockWebserver | A HTTP & SPDY client for Android and Java applications used as the HTTP client for Retrofit. | [Apache 2.0](https://github.com/square/okhttp/blob/master/LICENSE.txt) |
| Timber with TimberKt | Logger with small, extensible API which providing several utilities on top of Android's normal Log class. | [Apache 2.0](https://github.com/ajalt/timberkt/blob/master/LICENSE.txt) |
| Dagger2 + Hilt | Dagger is a fully static, compile-time dependency injection framework for both Java and Android. It is an adaptation of an earlier version created by Square and now maintained by Google. | [Apache 2.0](https://github.com/google/dagger/blob/master/LICENSE.txt) |
| Mockk | Most popular mocking framework for Kotlin. | [Apache 2.0](https://github.com/mockk/mockk/blob/master/LICENSE) |
| Espresso | Android's UI testing framework. | [Apache 2.0](https://cs.android.com/androidx/platform/frameworks/support/+/androidx-main:LICENSE.txt) |
| LeakCanary | A memory leak detection library for Android and Java. | [Apache 2.0](https://github.com/square/leakcanary/blob/main/LICENSE.txt) |
| Firebase | Analytics + Crashlytics + Performance. | [Apache 2.0](https://github.com/firebase/firebase-android-sdk/blob/master/LICENSE) |
| Detekt + KtLint + Spotless | Static analysis tools. | [Apache 2.0](https://github.com/detekt/detekt/blob/main/LICENSE) |
| Robolectric | Android Unit Testing Framework | [MIT License](https://github.com/robolectric/robolectric/blob/master/LICENSE) |
| ThreeTen | Date and time API. | [BSD 3-clause](https://github.com/ThreeTen/threetenbp/blob/master/LICENSE.txt) |
