---
id: architecture
title: Architecture
slug: architecture
hide_table_of_contents: false
---

> A building stands or falls with its base architecture

## Modern Architecture

For a common way of working across features this project follows (mostly) the [Modern Android App Architecture](https://developer.android.com/courses/pathways/android-architecture).

This methodology describes how to structure your code and how each part interacts with each other.

The code can roughly be split up into three layers:

- UI layer (see also [MVVM](/development/mvvm))
- Domain layer (optional)
- Data layer

This structuring has multiple advantages:

- Each layer has its own responsibility
- Each layer can be changed independently of other layers (through abstractions)
- Business rules can be tested without a UI / API / Database
- Communication between each layer is restricted by its contracts and cannot jump across layers

## Dependency Injection

> An object receives other objects that it depends on, also called dependencies

In this project we use [Hilt](https://dagger.dev/hilt/) on top of Dagger. Here are a few general rules:
- In most cases you would only have to define an `@Inject` constructor.
- `@Provides` methods are most of the time used for 3rd party libraries or delegation such as `db.customerDao()`.
- `@Binds` methods defined in an `abstract class` are commonly used to map an implementation to its interface abstraction.

## Domain layer

### Interactors / Observers

Interactors and observers contain important business logic to retrieve, manipulate and display data. This way the business logic can be tested independently from the UI.


#### Interactors

Interactors only retrieve data from a source (remote) and map it to another source (local) to be, typically, stored.

An interactor example:

```kotlin
/**
 * Retrieves data X and persists it
 */
@Reusable
class RefreshDataX @Inject constructor(
    private val dispatchers: AppCoroutineDispatchers, // used to switch between coroutine threads
    private val localSource: XLocalSOurce,
    private val service: PodwalksService,
) {
    /**
     * Performs the work and return a result
     * 
     * @return whether the work was successful or not
     */
    suspend operator fun invoke(): RefreshXResult {
        // Retrieve the data
        val result = service.getDataX()
        
        // Map it to another source
        val mapped = result.mapToLocal()
        
        // Store / persist it somewhere
        localSource.insertAll(mapped)
    }

    // Either enum or sealed class, prefer a local class over a general purpose class to be more interactor-specific
    enum class RefreshXResult {
        SUCCESS, FAILURE
    }
}
```

#### Observers

Observers aggregate data from different sources (usually local) to be used by the UI layer.

An observer example:

```kotlin
/**
 * Observes data from x and y
 */
class ObserverDataXWithY @Inject constructor(
    private val dispatchers: AppCoroutineDispatchers, // used to switch between coroutine threads
    private val xSource: XLocalSource,
    private val ySource: YLocalSource,
) {
    /**
     * Combines & reacts to changes in both sources and maps it to this observer's data result 
     */
    operator fun invoke(xSourceId: String): Flow<Tour> =
        combine(xSource.all(), ySource.getByIdX(xSourceId)) { x, y ->
            ResultXWithY()
        }

    data class ResultXWithY(val id: String)
}
```

## Folder structure

One part of the architecture is the folder structure. There are several folders within the root directory:

- `app`: glues all the features and code together. This module should contain as little code as possible to promote higher reusability of code.
- `data`: data entities, local (database/files) and remote (network) sources
- `documentation`: contains this documentation which can be run locally
- `domain`: use cases to either interact with the data sources or observe (and map) them in a reactive way
- `features`: one module per feature with its own set of screens and components
- `shared/presentation`: defines the app's theme and reusable components for each feature to rely on
- `shared/resources`: _only_ contains the app's resources: images, fonts, icons and translations
- `shared/utils`: a collection of utility functions
- `showkase`: design system preview application (see [Guides - Showkase](/guides/showkase) for more info)
- `fastlane`: fastlane configuration for easy CI/CD'
