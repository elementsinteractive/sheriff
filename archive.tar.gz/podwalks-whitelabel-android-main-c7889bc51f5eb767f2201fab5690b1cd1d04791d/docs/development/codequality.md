> All code is guilty, until proven innocent.

This project uses [Spotless](https://github.com/diffplug/spotless), [detekt](https://github.com/detekt/detekt) and Android Lint to ensure code quality stays as high as possible:
* Both can run from the CLI or as part of Android Studio.
* Android Lint checks common Android issues during development and is run as part of the [CI/CD](cicd.md) pipelines.
