## UI Layer

For the [UI layer](https://developer.android.com/jetpack/guide/ui-layer) to receive data and offload certain events we use the MVVM approach.

The `ViewModel` observes any changes in the `data` layer and handles any UI events in order to change the state.

[Mavericks](https://github.com/airbnb/mavericks) is our go to library for state management within the `ViewModel`.

### Defining the state

Describing the state of a screen is done through a `data class`.

By using a data class we ensure an immutable data flow and know the UI is only updated when there are actual changes within the state.

One example could be:

```kotlin
data class HomeUIState(
    val loading: Boolean = false, // every field must have a default value
    val items: List<NewsItem> = emptyList(),
) : MavericksState
```

### Observing data and updating the state

#### Update

By calling `setState { copy() }` you can update the state from within a `ViewModel`.

:::note
The lambda from `setState` is not called synchronously but queued and run on a background thread. See [threading](https://airbnb.io/mavericks/#/threading) for more info.
:::

#### Observe

When observing data from a database or other source you should update the state.

In some cases you can have a `UseCase` which aggregates / transforms the data before handing it over to the `ViewModel`.

To always observe data you can initialize the flows from the `init` block:

```kotlin
init {
    // Launch it in this viewModel's coroutine scope
    viewModelScope.launch {
        observeNewsItems() // calls the invoke of the use case
            // catches any possible errors
            .catch { throwable ->
                logger.e(throwable, "Failed to observe news items.")
            }
            // collects all updates, could also use collectLatest if necessary
            .collect { items ->
                setState {
                    copy(items = items)
                }
            }
    }
}
```


