## Workflow

In this project we follow `Common Flow` workflow. Read more about [Common Flow](https://commonflow.org/)

### Default branch

The default branch is set to be `main` and contains all tags & merges from `feature` and `release` branches.

### Branching Strategy

Based on the project git workflow, there is still rules to follow when naming a new branch:

- Feature branch → `feature/[$1]_[$2]`
    - `$1`: JIRA ticket id.
    - `$2`: Feature name in kebab-case.
    - Example → `feature/SKELETON-42-add-button`
- Hotfix branch → `hotfix/[$1]_[$2]`
    - `$1` (Optional): JIRA ticket id.
    - `$2`: Hotfix name in kebab-case.
    - Example → `hotfix/android-startup-crash`
    - Example → `hotfix/SKELETON-666-startup-crash`
- Release branch → `release/[$1]`
    - `$1`: Release version.
    - Example → `release/v1.0.2`
- Tag → `v1.0.2`
    - to release a specific version

### Commit Messages

Each commit message has to be descriptive enough to help developers review or debug your code.

Commits must follow this pattern:

```markdown
type: subject (JIRA ticket id)
```

Examples could be:

```markdown
chore: adds dummy screen (SKELETON-11)
```

```markdown
fix: format of http header (SKELETON-19)
```

```markdown
feat: new onboarding screen component (SKELETON-42)
```

#### Commit Types

- `build`: Changes that affect the build system or external dependencies (example scopes: gradle).
- `ci`: Changes to our CI configuration files and scripts (example scopes: Gitlab.yml / Fastlane).
- `chore`: Other changes that don't modify src or test files.
- `docs`: Documentation only changes.
- `feat`: A new feature.
- `fix`: A bug fix.
- `perf`: A code change that improves performance.
- `refactor`: A code change that neither fixes a bug nor adds a feature.
- `revert`: Reverts a previous commit.
- `style`: Changes that do not affect the meaning of the code (white-space, formatting, missing semi-colons, etc).
- `test`: Adding missing tests or correcting existing tests.

### Merge Request Strategy

Merge requests need to be reviewed and approved and pass all CI pipelines before they can be merged. While anyone has the ability to review and approve a merge request, we recommend asking seniors to approve it.

Merge requests must include the following before it can be considered ready to be reviewed:

- Descriptive Title
- Short Summary
- Test Plan
