Sometimes you need to persistent a certain value or complete database.

#### In this application we use:
* [DataStore](https://developer.android.com/topic/libraries/architecture/datastore) to store key-value pairs and small objects that don't need a relation.
* [Room](https://developer.android.com/training/data-storage/room) to store relational data with entities

#### How to abstract access to DataStore

In this app we provide an abstraction layer on top of `DataStore` through `AppState`.

For example:

```kotlin
interface AppState {
    var userIdentifier: Flow<String?> // returns a Flow<String?> with the user identifier
}
```

This way the implementation details are hidden:

```kotlin
@Singleton
class SkeletonState @Inject constructor(
    dataStore: DataStore<Preferences>
) : AppState {
    companion object {
        private val KEY_USER_IDENTIFIER = stringPreferencesKey("user_identifier")
    }

    override var userIdentifier = dataStore.data.map { it[KEY_USER_IDENTIFIER] }
}
```
