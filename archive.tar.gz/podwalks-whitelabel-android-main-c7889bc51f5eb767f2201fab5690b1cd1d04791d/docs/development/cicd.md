## Setup

There are various tools involved in our CI/CD pipelines.
* Gitlab is configured by the `.gitlab.yml` in the root folder. Our shared gitlab yml files can be found in the [Elements/Gitlab](https://git.elements.nl/elements/gitlab) repo.
* Fastlane is configured through the fastlane folder through .env files. The [unified fastfile](https://git.elements.nl/elements/unifiedfastfile) contains the `Fastfile` with predefined steps (Lint / Build). The `Fastfile` sets the correct build number and builds the Android app with the correct build types / flavor.
* Deploy+ is used for app distribution and in certain pipelines the Android apk/bundle are uploaded. The `DEPLOY_PLUS_APP_ID_ANDROID` variable in the `fastlane/.env.*` determines to which project to upload in Deploy+
* [Danger](https://github.com/elementsinteractive/danger) is used to ensure consistent [Way of Working](https://www.notion.so/msdevelopment/Development-cac40cb5091e494dbada3993cc40cf59) among projects


## Continuous Integration

To integrate continuously each push to a MR will trigger [quality](codequality.md) pipelines to be run.
After the pipelines pass successfully you will can (after getting an approval) merge it to the `main` branch.

To ensure we build secure applications we also perform [security checks](/security/checks) during MRs.

## Continuous Delivery

We make automatic builds on:

- After each merge to `main` a staging build will be created and uploaded

These builds can be found on [Deploy+](https://deployplus.com):
* Skeleton APKs can be found here: https://deployplus.com/project/14d07c47-665f-4267-a172-76e2679946be
* Skeleton bundles can be found here: https://deployplus.com/project/b86a4a84-612b-4033-8915-e983433e1ede
