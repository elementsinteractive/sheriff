---
id: flavor
title: Podwalk Flavor
slug: flavor
hide_table_of_contents: false
---

The Podwalk Whitelabel project consists of multiple flavors in one project. This document describes how to add a new flavor and what needs to be configured.

## Flavor

### 1. Create Firebase project

In the [Firebase console](https://console.firebase.google.com/) you will need to create two Firebase projects:

* `<CLIENT> - Podwalks - DEV`
* `<CLIENT> - Podwalks` (marked as Production)

Inside of the Firebase project you will also need to add Android apps:

* For the PRODUCTION project: 1 app with the production package name
![Production apps](./images/firebaseAppsProd.png)
* For the DEV project: 2 apps using the package name and suffixes `dev` and `staging`
![Development apps](./images/firebaseAppsDev.png)

After creating the both Firebase projects and all Android apps you will have to export the `google-services.json` for both projects.
Inside `app/src/debug`, `app/src/staging` and `app/src/release` you will have to create a new folder with the flavor name and copy the correct `google-services.json`.

### 2. Add new flavor

In `build-logic/convention/src/main/kotlin/nl/elements/podwalks/PodwalkFlavor.kt` you need to add a new flavor name with some configurations:

* `Application id`: the package identifier for the production build.

* `Podwal API Key`: set up a [cms account](https://podwalks.elements.nl) for the Podwalk client and get the api key from that account. Or contact the person responsible for setting up the account.

* `Google Maps API key`: can be found in the [Google Cloud developer console](https://console.cloud.google.com/google/maps-apis/) where you will need to enable `Maps SDK for Android`

* Signing configuration:
  * Create a new upload keystore inside `app/keystore` with filename `<flavor>.keystore` with the following command:
  ```shell
  $ keytool -genkey -v -keystore waalre.keystore -alias upload -keyalg RSA -sigalg SHA384withRSA -keysize 4096 -validity 10000 -storepass <store password>
  ```
  Make sure to store the passwords in Bitwarden.
  * Next you will have to add the `GPG private key for android runners` from Bitwarden into your GPG keychain and decrypt `keystore.properties` with:
  ```shell
  gpg --output keystore.properties --quiet --batch --use-agent --decrypt keystore.properties.gpg
  ```
  And add the following fields with the flavor name as prefix: `keyAlias`, `storePassword`, `keyPassword`
  * Then run `encrypt.sh keystore.properties` to update `keystore.properties.gpg`
  

### 3. Setup resources

* Inside `shared/resources/src/flavors` you will need to create a flavor folder.
* In [Phraseapp](https://app.phrase.com/accounts/elements/spaces) you will have to duplicate the `Podwalks White Label - Elements` project and use the flavor name instead of `Elements`
* Update `.phraseapp.yml` with the correct project ID and locale IDs and use the phrase CLI to pull with `phrase pull --access_token <token>`.
* Copy the necessary resources from another flavor

### 4. Setup CI/CD

* Request two Deploy+ projects with names: `<Flavor> - Podwalks - Android - APK` and `<Flavor> - Podwalks - Android - Bundle`. Note down their app ids to be used in the next step.
* Inside the `fastlane` directory you will have to create 2 new files.
`.env.<flavor>` with contents:
```
# DeployPlus
DEPLOY_PLUS_APP_ID_ANDROID=<deployplus app id>

# Android
ANDROID_BUILD_FLAVOR=<flavor>
ANDROID_GRADLE_TEST_TASK=test<Flavor>DebugUnitTestCoverage
```

`.env.<flavor>Bundle` with contents:

```
# DeployPlus
DEPLOY_PLUS_APP_ID_ANDROID=<deployplus app id>

# Android
ANDROID_BUILD_FLAVOR=waalre
ANDROID_GRADLE_TASK="app:bundle"
```


* Update `.gitlab-ci.yml` with:

Unit tests:
```yml
<Flavor> Unit Tests:
  extends: .unittests
  stage: Test
  variables:
    ENVIRONMENT: <flavor>
    JACOCO_CSV_FILE_DIRECTORY: test<Flavor>DebugUnitTest
```

Test build:
```yml
<Flavor> Test Build:
  extends: .testbuild
  variables:
    ENVIRONMENT: <flavor>
```

Release build:
```yml
<Flavor> Release App:
  extends:
    - .release
    - .manual
  variables:
    ENVIRONMENT: <flavor>
```

Bundle build:
```yml
<Flavor> Bundle App:
  extends:
   - .release
   - .manual
  variables:
    ENVIRONMENT: <flavor>Bundle
```

Staging build:
```yml
<Flavor> Staging App:
  extends:
    - .staging
    - .main
  variables:
    ENVIRONMENT: <flavor>
```
