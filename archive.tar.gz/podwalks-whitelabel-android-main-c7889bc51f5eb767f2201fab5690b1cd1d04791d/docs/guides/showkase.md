For sharing and displaying Compose components in our design application we use [Showkase](https://github.com/airbnb/Showkase).

There is a `showkase` module you can start as an Android application. 
