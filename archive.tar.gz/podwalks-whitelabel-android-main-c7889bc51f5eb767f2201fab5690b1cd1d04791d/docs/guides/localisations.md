> Nothing should get lost in translation.

From the start you should take localisation into account. In the `shared/resources` folder all localisations should be concentrated.

## How to provide localisations

You should start with a 3rd party tool like PhraseApp.

With PhraseApp both platforms have several benefits:

- you can download all the necessary translations (with CLI or the [gradle plugin](https://plugins.jetbrains.com/plugin/7686-phraseapp))
- update the translations in one place
- have consistent translation
