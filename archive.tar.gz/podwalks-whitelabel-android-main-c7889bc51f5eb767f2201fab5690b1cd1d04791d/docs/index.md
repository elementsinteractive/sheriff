# Welcome

Welcome to the Elements Android Skeleton project documentation!

## Configuration

Android configuration can be found in [build.gradle](/app/build.gradle) and contains the project's dependencies.

[Modules configuration](https://playground.diagram.codes/d/graph/base-%3Eapp%0A%22base-android%22-%3Eapp%0Adata-%3Eapp%0A%22data-android%22-%3Eapp%0Anetwork-%3E%20app%0A%0Abase-%3E%22base-android%22%0A%0Abase-%3E%22data-android%22%0A%22base-android%22-%3E%22data-android%22%0Adata-%3E%22data-android%22%0A%0Abase-%3Edata%0A%0Abase-%3Enetwork%0Adata-%3Enetwork)

##### Flavors

Some Gradle modules can have specific source sets the two flavors (`elements` and `makerstreet`). In this case the sources can found in `[module]/src/flavors/[flavor]`.

Examples:

```
/app/src/flavors/elements/
/app/src/flavors/makerstreet/
/features/ui-home/src/flavors/elements/
```

#### Fastlane

Fastlane is used for verification, building and deploying. See [fastlane's documentation](/fastlane/README.md)

#### Gitlab CI

Gitlab CI configuration can be found in `.gitlab-ci.yml` and uses docker to run on the gitlab runner.
The gitlab configuration consists of these stages:

- Quality (runs quality checks)
- Test (runs unit tests)
- Test builds (builds via gradle and deploys the apk)
- Release builds (builds via gradle and deploys the apk)

#### Requirements

- Android Studio
- Android SDK
- Android 5.0 (21) and above

## Privacy and Security

Information in this section are valuable for new developers that join the project and security audit.
The process of security development is always in improving state, In case of questions or advices please contact security guild.
First read [Project security guide](https://conf.elements.nl/display/SECURITY/Project+Security+Guide)

These are the main overarching guidelines that we have to be aware of:

- Apply privacy-by-design
- Security must be equivalent or better than the industry standard
- We do not collect any more information from the user than strictly needed to provide the service.
- For every extra information collected, we must ask explicit permission, and the app shall not break without it.
- The app will not make granting permission easier than either rejecting or revoking it.
- The privacy and security considerations made for this project will be documented (see below)
- Any cases where data is or can be leaked to unintended targets shall be reported immediately.

Describe:

- What sensitive data is being used?
- In what circumstances is this data used?
- How data is obtained
- How data is stored
- How session timeout is handled

#### Data collected

This is the place where you list what information is collected, and where it is stored, and for what reason. This is used in audits, and serves as a legal backup for incidents. Things to specifically consider:

- Anonymising and truncating data should be done with care, since hashes can be replayed, and enough data fragments make unique signatures. Birthdate and the numbers from the zipcode combined have more valid and likely combinations than the number of people in the country, and will thus uniquely identify a significant fraction of them.
- Tracking solutions also collect data, usually of their own accord.
- Apart from not collecting, data that stays on the device is generally safer than sending it to another party, since it can't be obtained by third parties without hostile means.

#### Encryption

Internet calls should use HTTPS without exception, as this is the industry-standard practice. Typical extra security measures can be done, such as:

- Certificate pinning
- Client authentication
- JWT tokens
  Since these have smaller or bigger implications for the upgrade path and app stability, these should be decided upon. Explain here which measures are used and why.

#### Persistency

Data stored on device should be encrypted to prevent other apps from spying on them. Explain here how that is performed, and why this approach was chosen.

By default, the Skeleton comes with a room database that is encrypted with [SQLCipher](https://github.com/commonsguy/cwac-saferoom) which uses a passphrase to encrypt the data. The passphrase is the device identifier.

#### Displaying the notices for the open source libraries

To comply with the license requirements of open source libraries, it is necessary to display the notices for the open-source libraries that the app uses.

The library [AboutLibraries](https://github.com/mikepenz/AboutLibraries) is used to simplify this process, allowing to display a [generated Fragment/Activity](https://github.com/mikepenz/AboutLibraries#basic-usage) with compile-time licenses collection or [iterate over the list of licenses](https://github.com/mikepenz/AboutLibraries#access-generated-library-details).

The access is highly dependent on the project, thus the implementation is not included by default in the skeleton project, although this is usually accessed via the _About this app section_ or similar.

#### Other considerations

Example:

- It has been advised the PO to schedule a external security audit by a third party on every major release.