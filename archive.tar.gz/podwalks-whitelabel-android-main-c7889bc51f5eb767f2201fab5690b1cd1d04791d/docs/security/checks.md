To ensure we deliver secure apps we perform various security checks.

## Dependency checks

See the [do-dependency-security](https://makerstreet-public.gitlab.io/ci-cd-library/common/#do-dependency-security) for more info.

The scanner makes use of the `gradle.lockfile` through Gradle's [Locking dependency versions](https://docs.gradle.org/current/userguide/dependency_locking.html) mechanism.

To update the existing lock file you should run:

```bash
JAVA_OPTS="-Xmx8g -Xms3g" gradle allDependencies --write-locks
```
Note: gradle wrapper gives OOM: https://github.com/gradle/gradle/issues/26228

## [Secret detection](https://makerstreet-public.gitlab.io/ci-cd-library/common/#secret_detection)

