# Project Security

## Introduction

This project security document is a record of security and privacy aspects associated with it. The
audience of this document includes, but is not limited to, current and future developers engaged in
the project, project managers and the project security lead.

The goal of this document is to provide a one-stop shop for all security and privacy related
considerations and measures taken for the project, where the information is presented in a
comprehensible way for its entire audience, especially for people not directly involved in the
project. This information can be used for various purposes, for example:

- As a developer's security and privacy check list during development process, learning curve
- Source of information about data processing activities, required for the data processing agreement
  between Elements and the clients/3rd parties
- Reference information on how security and privacy by design was implemented and can be copied for
  other projects
- Quick access to the taken security and privacy measures in case of an incident (data leak, for
  example)

## Data classification

The app processes several kinds of data. These are grouped into three categories:

A: Sensitive data, such as personally identifiable information or other kinds of data whose
disclosure leads to legal issues.

B: Private data, such as business information, that should not be publicly available but is not
bound by legal requirements.

C: Public data, which is intended to be available to all.

_Provide a overview of what of sensitive data is processed. Make sure every kind of information
processed is included since this information is needed for app submission. The following table
format is available._

_Feel free to merge rows if data is always processed together, e.g. if phone and home address are
always found on the same API call, data type, database table, etc._

### A - Restricted/sensitive data

| Data                      | Origin                              | Destination                                     | Usage                                  | Used by third parties? | Used for tracking? |
| ------------------------- | ----------------------------------- | ----------------------------------------------- | -------------------------------------- | ---------------------- | ------------------ |
| _i.e. User email address_ | _i.e. Filled in on the login page._ | _i.e. Only used for logging in. Not persisted._ | _i.e. Logging in on the login screen._ | _Yes or No_            | _Yes or No_        |

### B - Private data

| Data                | Origin                             | Destination                  | Usage                 | Used by third parties? | Used for tracking? |
| ------------------- | ---------------------------------- | ---------------------------- | --------------------- | ---------------------- | ------------------ |
| _i.e. Stack traces_ | _i.e. Errors from within the app._ | _i.e. Firebase Crashlytics._ | _i.e. Yes: Firebase._ | _Yes or No_            | _Yes or No_        |

### C - Public data

| Data                       | Origin                                    | Destination          | Usage                          | Used by third parties? | Used for tracking? |
| -------------------------- | ----------------------------------------- | -------------------- | ------------------------------ | ---------------------- | ------------------ |
| _i.e. Public phone number_ | _i.e. Public information on the website._ | _i.e. Stays in-app._ | _i.e. Is displayed in the UI._ | _Yes or No_            | _Yes or No_        |

## APIs and Endpoints

This section contains information about what services and endpoints are used.

_List all APIs, including the domains and the endpoints that are used that relate to data
classification A and B. Authentication is covered in a separate chapter. You can refer to that in
the relevant column, and add exceptions or extra information here._

### i.e. API host name

- i.e. Base URL (PROD) : https://myApi.net

| Endpoint                 | Description                              | Authentication | Security remarks             |
| ------------------------ | ---------------------------------------- | -------------- | ---------------------------- |
| i.e. `/sample-json.json` | i.e. Returns personal data about a user. | i.e. N\A       | i.e. Requires authentication |

## Sensitive Permissions

Mobile devices require specific user permission to perform privacy-sensitive operations.
Inappropriate use of these can range from negative reviews and user loss, to potential take-downs
and legal inquiries if user rights are knowingly being violated. The following lists the special
permissions used by the app.

| Permission    | How is it used?              | When is it used?                               | When is it requested?                   | How are denied permissions handled?                | Remarks |
| ------------- | ---------------------------- | ---------------------------------------------- | --------------------------------------- | -------------------------------------------------- | ------- |
| _e.g. Camera_ | _e.g. Make profile pictures_ | _e.g. when the user presses the camera button_ | _e.g. before opening the camera screen_ | _e.g. the user is redirected to the settings page_ |         |

When relevant, mention to which security criteria the permission relates to. Security criteria for
all platforms can be found here: Android, iOS and front-end.

## Persistence

This section contains information about the persistence - not just the processing - of sensitive
data that belong to data classification A and B. Important to note is that having data stored in
multiple places means that ALL of these places will have to be secured. Sometimes this is needed for
functionality such as offline support, or even as a form of redundancy. Without a legal basis
however, data should not be retained. Use this section to elaborate on the what, why and how of
persistence.

This section documents which data is stored within the context of the app.

### Private & Sensitive Data

_Answer the following questions:_

- What kind of data is stored?
- When is this data used?
- Why is it stored (e.g. caching or offline use)?
- Who has access to this data?

### Implementation

_Answer the following questions:_

- Which technologies are used to store information?
- Why is these technologies used (e.g. best practice or not maintained)?
- What are rejected alternatives (if relevant, also condiering from a security perspective)?

### Considerations

_Answer the following questions:_

- What measures are taken to secure this data (e.g. encryption) and how is this implemented?
- How is the data protected from unauthorized agents?
- What application data is backed up with Apple and Google (iCloud & Google)?

## Life cycle

This section contains all relevant information about the life cycle of sensitive data that falls
into data classification A and B.

See [Information Handling](https://www.notion.so/msdevelopment/Information-Handling-24a59610dfd94faab2eaf4b5bcc327c3?pvs=4)
for more details.

_Answer the following questions. Make sure you cover each data entity, but feel free to group them:_

- What is the lifespan of the data?
- How is the life cycle managed (e.g. background script, cache TTL)?
- How is the data deleted?
- How long are we allowed to keep the data (e.g. contractually and/or legally)?
- Where does the life cycle start and end for the data?

## Logging

Logging provides the ability to detect and correct issues in the project. This however also adds
extra attack surface to access sensitive information.

Logs can be kept on device where it's generally readable for everything on the device, but also sent
off to places like crashlytics, sentry, or other analytics tools. For each of these, answer the
following questions. If there are no plans to actually read the logs, such logging should be removed
instead.

- What data is being logged?
- Are sensitive fields masked?
- Where is the logged data being sent to?
- How are the logs checked?
- What is the logs expiration time?

## Authentication

_Answer the following questions:_

- How is authentication handled (e.g. passwords, OAuth, JWT)?
- How is authorization performed (who is allowed to do what)
- How is session timeout and refreshing handled?
- How is the security and integrity of authentication maintained (e.g. HTTPS, plain text passwords)?

For project documentation, also discuss what alternative options have been discussed, and why these
have been rejected.

## Third Party Services

This section contains information about and third parties (e.g. analytics, crash reporting) involved
with the project.

_Describe in details what parties are involved with the project and in what way. This would for
example include the client itself, Firebase, Google Maps, Adobe, Sentry, Postgres database and
Redis._

_It's often the case that the following questions have been answered before for other projects. For
example, the data that is shared with Firebase Crashlytics is often the same across projects. For
this reason, check if this Notion page doesn't already describe the required information._

_Information on that page can be included in this document provided it contains necessary
information to answer the following questions. However, don't just blindly copy/paste. Ensure that
the information you're importing is accurate, relevant and applicable to this project._

_Answer the following questions:_

- What user data is collected (e.g. analytics and Crashlytics)?
- With what parties is collected user shared and for what reason?
- How is collected user data shared with these third parties?
- How is this data secured (considerations)?
- What data is explicitly reported/collected on top of default behavior?
- Is the collected data used to track users?

## Inform and Consent

This section contains information about how the user is informed about what data collected about
them.

In this section you can address what the user knows about their data being used, and how the app
makes sure the user knows in time, as well as having a valid choice in the matter. Data that is
strictly necessary for functionality does not require consent, but the user might need to be
informed why it is included. Data that is not strictly necessary should not be made functionally
mandatory, and any such uses must be explicitly announced and approved. The checkbox+confirm button
combination is the legally sound way to do this.

_Answer the following questions:_

- Is the user informed about what data is collected and for what reason?
- How is the user informed about data collection (info. dialog or sign up EULA)?
- To what extend is the user allowed to opt out of data collection?
- Is the user informed about what parties have access to this data?

## Deployment

The following body is the default for mobile applications. Please update it taking into account the
following:

- How is deployment done (relevant to security)?
- How are secrets handled (database password, token secrets etc.)?

Builds are run from an internal build server, and the results are distributed through an in-house
build distribution service called Deploy+. Builds that are selected for production are taken from
here and then uploaded to their respective stores.

The store accounts are available to a selection of senior employees to limit the potential of abuse.

## Risk analysis and issues

The following security items have been discussed or are under discussion. A JIRA issue should be
available for every decision that hasn't been called.

This section is to document any and all security-related decisions that haven't been covered in the
topics above, as well as outstanding issues. Please describe per point:

- What's the issue at hand
- What are the probabilities this happens and the likely/possible consequences.
- What are the mitigations/alternatives.
- What has been decided on the subject and who accepted the (remaining) risk?
