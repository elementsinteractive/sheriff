fastlane documentation
================
# Installation

Make sure you have the latest version of the Xcode command line tools installed:

```
xcode-select --install
```

Install _fastlane_ using
```
[sudo] gem install fastlane -NV
```
or alternatively using `brew install fastlane`

# Available Actions
## iOS
### ios build
```
fastlane ios build
```
# Builds and deploys a new IPA version to Deployplus

To maintain backwards compatibility, this will check if there's CI software

running in the background. Please migrate to testbuild so this quirk can be removed

## Environment variables:

* **`IOS_MATCH_PROFILE`**: Match profile type used for fastlane match and fastlane gym.

* **`IOS_MATCH_ENABLED`**: Defines whether fastlane match should run.

* **`IOS_XCODE_WORKSPACE_PATH`**: Workspace path relative to the project (including file extension), default is `IOS_XCODE_PROJECT_PATH/PROJECT_NAME.xcworkspace`

* **`IOS_XCODE_PROJECT_PATH`**: Project path, default is `./`

* **`IOS_BUILD_SCHEME`**: Scheme to use, default is `PROJECT_NAME`

* **`IOS_BUILD_CONFIGURATION`**: Build configuration to use, default is `Release`

* **`IOS_EXPORT_METHOD`**: Method used to export the archive, valid are: ad-hoc or enterprise, default is `enterprise`,
### ios testbuild
```
fastlane ios testbuild
```
# Build without uploading to Deploy+

This makes a complete build for device with all associated checks without

causing noise on Deploy+. This is designed to be used in MR pipelines to

cover inconsistencies that aren't triggered through unit tests

## Environment variables:

* **`IOS_MATCH_PROFILE`**: Match profile type used for fastlane match and fastlane gym.

* **`IOS_MATCH_ENABLED`**: Defines whether fastlane match should run.

* **`IOS_XCODE_WORKSPACE_PATH`**: Workspace path relative to the project (including file extension), default is `IOS_XCODE_PROJECT_PATH/PROJECT_NAME.xcworkspace`

* **`IOS_XCODE_PROJECT_PATH`**: Project path, default is `./`

* **`IOS_BUILD_SCHEME`**: Scheme to use, default is `PROJECT_NAME`

* **`IOS_BUILD_CONFIGURATION`**: Build configuration to use, default is `Release`

* **`IOS_EXPORT_METHOD`**: Method used to export the archive, valid are: ad-hoc or enterprise, default is `enterprise`,
### ios lint
```
fastlane ios lint
```

### ios unit_tests
```
fastlane ios unit_tests
```
* **`IOS_TEST_COVERAGE_ENABLED`**: If enabled uses `xcov` to get the test coverage of main target.

----

## Android
### android build
```
fastlane android build
```
# Builds and deploys a new APK/Bundle to Deployplus

To maintain backwards compatibility, this will check if there's CI software

running in the background. Please migrate to testbuild so this quirk can be removed

## Environment variables:

* **`ANDROID_BUILD_TYPE`**: build type to use, default is release

* **`ANDROID_BUILD_FLAVOR`**: flavor to use, optional

* **`ANDROID_GRADLE_TASK`**: gradle task to run, default is assemble

* **`ANDROID_GRADLE_PATH`**: path to the main build.gradle, default is `./app/build.gradle`

* **`DEPLOY_PLUS_APP_ID_ANDROID`**: DeployPlus app to upload to

* **`DEPLOY_PLUS_APP_TYPE`**: DeployPlus app type

* **`CI_JOB_ID`**: to set the version code
### android testbuild
```
fastlane android testbuild
```
# Performs a full Android test build run without upload

This makes a complete build for device with all associated checks without

causing noise on Deploy+. This is designed to be used in MR pipelines to

cover inconsistencies that aren't triggered through unit tests

## Environment variables:

* **`ANDROID_BUILD_TYPE`**: build type to use, default is release

* **`ANDROID_BUILD_FLAVOR`**: flavor to use, optional

* **`ANDROID_GRADLE_TASK`**: gradle task to run, default is assemble

* **`ANDROID_GRADLE_PATH`**: path to the main build.gradle, default is `./app/build.gradle`

* **`DEPLOY_PLUS_APP_ID_ANDROID`**: DeployPlus app to upload to

* **`DEPLOY_PLUS_APP_TYPE`**: DeployPlus app type

* **`CI_JOB_ID`**: to set the version code
### android test
```
fastlane android test
```
# Runs all the unit tests

## Environment variables used:

* **`PROJECT_NAME`**: name of the project

* **`ANDROID_GRADLE_TEST_TASK`**: gradle test task to run, required

* **`CI_PROJECT_URL`**: Gitlab's project URL

* **`CI_JOB_ID`**: Gitlab's job ID
### android lint
```
fastlane android lint
```
Kotlin code quality checks

Requires both spotless and detekt setups
### android uitest
```
fastlane android uitest
```
# Runs all the UI tests with Espresso in Firebase's Test Lab

## Environment variables used:

* **`ANDROID_GRADLE_APP_TASK`**: task to generate the application

* **`ANDROID_GRADLE_APP_TEST_TASK`**: task to generate the *test* application

* **`GCLOUD_PROJECT_ID`**: project ID used in google cloud

* **`GCLOUD_JSON_FILE`**: json file from google cloud

* **`GCLOUD_DEVICES_PARAMS`**: extra params when running gcloud, e.g. which devices to run

 

See [Firebase Test lab config](https://firebase.google.com/docs/test-lab/command-line)

[Espresso guide on confluence](https://conf.elements.nl/display/DEV/Android+-+Automated+UI+Testing)

[Gitlab CI guide on confluence](https://conf.elements.nl/display/DEV/Gitlab+CI+set-up)

----

This README.md is auto-generated and will be re-generated every time [fastlane](https://fastlane.tools) is run.
More information about fastlane can be found on [fastlane.tools](https://fastlane.tools).
The documentation of fastlane can be found on [docs.fastlane.tools](https://docs.fastlane.tools).
