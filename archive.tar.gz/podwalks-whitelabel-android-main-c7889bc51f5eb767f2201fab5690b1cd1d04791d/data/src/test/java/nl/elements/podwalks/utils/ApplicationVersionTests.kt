package nl.elements.podwalks.utils

import nl.elements.podwalks.data.model.domain.ApplicationVersion
import nl.elements.podwalks.data.utils.ApplicationVersionParsing
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ApplicationVersionTests {

    @Test
    fun testEquality() {
        val version1 = ApplicationVersion(1, 0, 0)
        val version2 = ApplicationVersion(1, 0, 0)

        assertEquals(version1, version2)
    }

    @Test
    fun testLesserThan() {
        val version1 = ApplicationVersion(3, 2, 2)
        val version2 = ApplicationVersion(4, 1, 9)

        assertTrue(version1 < version2)
    }

    @Test
    fun testGreaterThan() {
        val version1 = ApplicationVersion(7, 1, 1)
        val version2 = ApplicationVersion(3, 9, 9)

        assertTrue(version1 > version2)
    }

    @Test
    fun testParsing() {
        val stringVersion1 = "1.0.0"
        val stringVersion2 = "3.1.9"
        val stringVersion3 = "9.11.0"

        val parsedVersion1 = ApplicationVersionParsing.parse(stringVersion1)
        val parsedVersion2 = ApplicationVersionParsing.parse(stringVersion2)
        val parsedVersion3 = ApplicationVersionParsing.parse(stringVersion3)

        assertEquals(parsedVersion1, ApplicationVersion(1, 0, 0))
        assertEquals(parsedVersion2, ApplicationVersion(3, 1, 9))
        assertEquals(parsedVersion3, ApplicationVersion(9, 11, 0))
    }

    @Test
    fun testFailedParsing() {
        val shortVersion = "1.0"
        val invalidCharVersion = "1.0.a"
        val noNumberVersion = "STABLE"

        // Assert exceptions
        assertFailsWith(IllegalStateException::class) { ApplicationVersionParsing.parse(shortVersion) }
        assertFailsWith(NumberFormatException::class) { ApplicationVersionParsing.parse(invalidCharVersion) }
        assertFailsWith(NumberFormatException::class) { ApplicationVersionParsing.parse(noNumberVersion) }

        // Assert nulls
        assertNull(ApplicationVersionParsing.parseOrNull(shortVersion))
        assertNull(ApplicationVersionParsing.parseOrNull(invalidCharVersion))
        assertNull(ApplicationVersionParsing.parseOrNull(noNumberVersion))
    }
}
