package nl.elements.podwalks.utils

import nl.elements.podwalks.data.database.DatabaseTransactionRunner

internal object TestTransactionRunner : DatabaseTransactionRunner {
    override suspend fun <T> invoke(block: suspend () -> T): T = block()
}
