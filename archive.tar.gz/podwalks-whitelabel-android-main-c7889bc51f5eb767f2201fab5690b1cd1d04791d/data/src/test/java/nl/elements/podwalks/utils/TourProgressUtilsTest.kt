package nl.elements.podwalks.utils

import nl.elements.podwalks.data.utils.TourProgressUtils
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

internal class TourProgressUtilsTest {

    @Test
    fun `isNextChapter returns true for the next checkpoint`() {
        val checkpointIndices = listOf(0, 1, 2, 3, 4)
        val visitedIndices = listOf(0, 1, 2)

        val isNextChapter = TourProgressUtils.isNextChapter(checkpointIndices, visitedIndices, checkpointIndices[3])

        assertTrue(isNextChapter)
    }

    @Test
    fun `isNextChapter returns false for non subsequent checkpoint`() {
        val checkpointIndices = listOf(0, 1, 2, 3, 4)
        val visitedIndices = listOf(0, 1, 2)

        val isNextChapter = TourProgressUtils.isNextChapter(checkpointIndices, visitedIndices, checkpointIndices[2])

        assertFalse(isNextChapter)
    }

    @Test
    fun `isNextChapter returns correctly for when a checkpoint is skipped`() {
        val checkpointIndices = listOf(0, 1, 2, 3, 4)
        val visitedIndices = listOf(0, 2)

        val notNext = TourProgressUtils.isNextChapter(checkpointIndices, visitedIndices, checkpointIndices[1])
        val next = TourProgressUtils.isNextChapter(checkpointIndices, visitedIndices, checkpointIndices[3])

        assertFalse(notNext)
        assertTrue(next)
    }

    @Test
    fun `isNextChapter returns true for the first checkpoint when none are visited`() {
        val checkpointIndices = listOf(0, 1, 2, 3, 4)
        val visitedIndices = listOf<Int>()

        val isNextChapter = TourProgressUtils.isNextChapter(checkpointIndices, visitedIndices, checkpointIndices[0])

        assertTrue(isNextChapter)
    }

    @Test
    fun `determineNextChapter returns null when checkpoints are empty`() {
        val checkpointIndices = emptyList<Int>()
        val visitedIndices = emptyList<Int>()

        val nextChapter = TourProgressUtils.determineNextChapter(checkpointIndices, visitedIndices)

        assertNull(nextChapter)
    }

    @Test
    fun `determineNextChapter returns next chapter when in the middle of tour`() {
        val checkpointIndices = listOf(0, 1, 2, 3, 4)
        val visitedIndices = listOf(0, 1, 2)

        val nextChapter = TourProgressUtils.determineNextChapter(checkpointIndices, visitedIndices)

        assertEquals(nextChapter, 3)
    }

    @Test
    fun `determineNextChapter returns 0 when no checkpoints are visited`() {
        val checkpointIndices = listOf(0, 1, 2, 3, 4)
        val visitedIndices = emptyList<Int>()

        val nextChapter = TourProgressUtils.determineNextChapter(checkpointIndices, visitedIndices)

        assertEquals(nextChapter, 0)
    }

    @Test
    fun `determineNextChapter returns null when all checkpoints are visited`() {
        val checkpointIndices = listOf(0, 1, 2, 3, 4)
        val visitedIndices = listOf(0, 1, 2, 3, 4)

        val nextChapter = TourProgressUtils.determineNextChapter(checkpointIndices, visitedIndices)

        assertNull(nextChapter)
    }

    @Test
    fun `determineNextChapter returns next checkpoint when a checkpoint is skipped`() {
        val checkpointIndices = listOf(0, 1, 2, 3, 4)
        val visitedIndices = listOf(0, 2)

        val nextChapter = TourProgressUtils.determineNextChapter(checkpointIndices, visitedIndices)

        assertEquals(nextChapter, 3)
    }

    @Test
    fun `determineCurrentChapter returns null when no checkpoints are visited`() {
        val visitedIndices = emptyList<Int>()

        val currentChapter = TourProgressUtils.determineCurrentChapter(visitedIndices)

        assertNull(currentChapter)
    }

    @Test
    fun `determineCurrentChapter returns correct checkpoint when in the middle of tour`() {
        val visitedIndices = listOf(0, 1, 2)

        val currentChapter = TourProgressUtils.determineCurrentChapter(visitedIndices)

        assertEquals(currentChapter, 2)
    }

    @Test
    fun `determineCurrentChapter returns correct checkpoint when a checkpoint is skipped`() {
        val visitedIndices = listOf(0, 3)

        val currentChapter = TourProgressUtils.determineCurrentChapter(visitedIndices)

        assertEquals(currentChapter, 3)
    }
}
