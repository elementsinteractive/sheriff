package nl.elements.podwalks.utils

import kotlin.random.Random

private val alphanumericCharpool: List<Char> = ('a'..'z') + ('A'..'Z') + ('0'..'9')

fun Random.Default.nextAlphaNumericString(
    length: Int,
    charPool: List<Char> = alphanumericCharpool,
): String = (1..length)
    .map { nextInt(0, charPool.size) }
    .map(charPool::get)
    .joinToString("")

fun Random.Default.nextLatitude() = nextDouble(-90.0, 90.0)

fun Random.Default.nextLongitude() = nextDouble(-180.0, 180.0)

fun Random.Default.nextLongOrNull(until: Long) = if (nextBoolean()) {
    nextLong(until)
} else {
    null
}

fun Random.Default.nextIntOrNull(until: Int) = if (nextBoolean()) {
    nextInt(until)
} else {
    null
}
fun <E : Any> Random.Default.nextFromListOrNull(list: List<E>) = list.getOrNull(nextInt(list.size))
