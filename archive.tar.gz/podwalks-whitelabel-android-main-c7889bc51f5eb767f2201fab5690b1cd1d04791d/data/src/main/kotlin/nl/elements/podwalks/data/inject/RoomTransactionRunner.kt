package nl.elements.podwalks.data.inject

import androidx.room.withTransaction
import nl.elements.podwalks.data.database.DatabaseTransactionRunner
import nl.elements.podwalks.data.database.PodwalksRoomDatabase
import javax.inject.Inject

class RoomTransactionRunner @Inject constructor(
    private val db: PodwalksRoomDatabase,
) : DatabaseTransactionRunner {
    override suspend operator fun <T> invoke(block: suspend () -> T): T = db.withTransaction {
        block()
    }
}
