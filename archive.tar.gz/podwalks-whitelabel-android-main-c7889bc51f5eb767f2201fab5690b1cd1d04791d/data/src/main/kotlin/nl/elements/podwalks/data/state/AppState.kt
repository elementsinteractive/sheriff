package nl.elements.podwalks.data.state

import kotlinx.coroutines.flow.Flow

interface AppState {
    val userIdentifier: Flow<String?>
    val hasFinishedOnboarding: Flow<Boolean>
    val remoteMinAppVersion: Flow<Long?>
    suspend fun updateUserIdentifier(userIdentifier: String)
    suspend fun updateOnboardingState(hasFinished: Boolean)
    suspend fun updateMinAppVersion(versionCode: Long)
}
