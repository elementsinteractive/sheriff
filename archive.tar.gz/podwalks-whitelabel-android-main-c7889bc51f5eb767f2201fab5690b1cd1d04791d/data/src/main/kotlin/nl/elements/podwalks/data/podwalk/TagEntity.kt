package nl.elements.podwalks.data.podwalk

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import nl.elements.podwalks.data.constant.DatabaseConstants

@Entity
data class TagEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = DatabaseConstants.ID)
    val id: Long,
    val name: String,
)

@Entity(
    indices = [
        Index(DatabaseConstants.TAG_ID),
    ],
    primaryKeys = [
        DatabaseConstants.PODWALK_ID,
        DatabaseConstants.TAG_ID,
    ],
    foreignKeys = [
        ForeignKey(
            entity = PodwalkEntity::class,
            parentColumns = [DatabaseConstants.ID],
            childColumns = [DatabaseConstants.PODWALK_ID],
            onDelete = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = TagEntity::class,
            parentColumns = [DatabaseConstants.ID],
            childColumns = [DatabaseConstants.TAG_ID],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class TagCrossReference(
    @ColumnInfo(name = DatabaseConstants.PODWALK_ID)
    val podwalkId: String,
    @ColumnInfo(name = DatabaseConstants.TAG_ID)
    val tagId: Long,
)
