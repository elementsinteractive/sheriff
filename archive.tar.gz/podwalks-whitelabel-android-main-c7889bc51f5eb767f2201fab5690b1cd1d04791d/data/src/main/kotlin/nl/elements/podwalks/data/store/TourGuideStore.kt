package nl.elements.podwalks.data.store

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import nl.elements.podwalks.data.state.PlaybackMode
import nl.elements.podwalks.data.state.PlaybackPosition
import nl.elements.podwalks.data.state.PlaybackState
import nl.elements.podwalks.data.state.TourGuideState
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TourGuideStore @Inject constructor() {

    private val mutex = Mutex()

    private val _state = MutableStateFlow<TourGuideState?>(null)
    val state: StateFlow<TourGuideState?>
        get() = _state

    suspend fun setup(tourId: String) = mutex.withLock {
        _state.value = TourGuideState(
            tourId = tourId,
            startTimeInMs = System.currentTimeMillis(),
            playback = PlaybackState(
                isPlaying = false,
                mode = null,
                position = PlaybackPosition(0, 0),
            ),
        )
    }

    suspend fun teardown() = mutex.withLock {
        _state.emit(null)
    }

    suspend fun setIsPlayingState(isPlaying: Boolean) = mutex.withLock {
        val snapshot = _state.value
        if (snapshot != null) {
            _state.value = snapshot.copy(
                playback = snapshot.playback.copy(isPlaying = isPlaying),
            )
        }
    }

    suspend fun setPlaybackPosition(
        positionMs: Long,
        trackDurationInMs: Long,
    ) = mutex.withLock {
        val snapshot = _state.value

        if (snapshot != null) {
            _state.value = snapshot.copy(
                playback = snapshot.playback.copy(
                    position = PlaybackPosition(
                        currentPositionInMs = positionMs,
                        totalLengthInMs = trackDurationInMs,
                    ),
                ),
            )
        }
    }

    suspend fun setCheckpointMode(index: Int) = mutex.withLock {
        val snapshot = _state.value

        if (snapshot != null) {
            _state.value = snapshot.copy(
                playback = snapshot.playback.copy(
                    mode = PlaybackMode.CheckpointMode(index),
                ),
            )
        }
    }

    suspend fun setBackgroundMode() = mutex.withLock {
        val snapshot = _state.value

        if (snapshot != null) {
            _state.value = snapshot.copy(
                playback = snapshot.playback.copy(
                    mode = PlaybackMode.BackgroundMode,
                ),
            )
        }
    }
}
