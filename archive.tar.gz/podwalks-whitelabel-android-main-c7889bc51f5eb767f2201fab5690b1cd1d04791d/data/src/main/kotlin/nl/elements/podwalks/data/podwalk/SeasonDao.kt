package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow
import nl.elements.podwalks.data.database.PodwalkSeasonCrossReference

@Dao
interface SeasonDao {
    // Getters
    @Query("SELECT * FROM SeasonEntity")
    @Transaction
    fun getSeasons(): Flow<List<SeasonEntityMetadata>>

    // Setters
    @Insert
    suspend fun insert(season: List<SeasonEntity>)

    @Query("DELETE FROM SeasonEntity")
    suspend fun deleteSeasons(): Int

    @Insert
    suspend fun insertPodwalkSeasonCrossReferences(references: List<PodwalkSeasonCrossReference>)

    @Query("DELETE FROM podwalkseasoncrossreference")
    suspend fun deletePodwalkSeasonCrossReferences()
}
