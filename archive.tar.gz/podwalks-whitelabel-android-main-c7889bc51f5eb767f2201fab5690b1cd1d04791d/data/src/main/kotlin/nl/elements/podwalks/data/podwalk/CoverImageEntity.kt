package nl.elements.podwalks.data.podwalk

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    foreignKeys = [
        ForeignKey(
            entity = PodwalkEntity::class,
            parentColumns = ["id"],
            childColumns = ["podwalkId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class CoverImageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long,
    val hash: String,
    val url: String,
    val podwalkId: String,
)
