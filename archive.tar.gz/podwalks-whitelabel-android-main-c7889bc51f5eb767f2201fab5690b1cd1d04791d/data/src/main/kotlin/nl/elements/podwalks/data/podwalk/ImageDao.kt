package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface ImageDao {

    @Insert
    suspend fun insert(images: List<ImageEntity>)

    @Insert
    suspend fun insert(image: CoverImageEntity)

    @Transaction
    @Query("DELETE FROM ImageEntity WHERE podwalkId = :podwalkId")
    suspend fun deleteAllForPodawlk(podwalkId: String)

    @Transaction
    @Query("DELETE FROM CoverImageEntity WHERE podwalkId = :podwalkId")
    suspend fun deleteCoverImageForPodwalk(podwalkId: String)
}
