package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity
data class RemotePodwalkUpdate(
    @PrimaryKey val podwalkId: String,
    val updatedAt: String,
)

@Dao
interface RemotePodwalkUpdateDao {

    @Query("DELETE FROM RemotePodwalkUpdate")
    suspend fun delete()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUpdates(versions: List<RemotePodwalkUpdate>)

    @Query("SELECT * FROM RemotePodwalkUpdate")
    fun getUpdates(): Flow<List<RemotePodwalkUpdate>>
}
