package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LocalFileDao {

    @Query("SELECT * FROM LocalFileEntity WHERE hash = :hash")
    fun getByHash(hash: String): Flow<LocalFileEntity?>

    @Insert
    suspend fun insert(file: LocalFileEntity): Long

    @Update
    suspend fun update(file: LocalFileEntity)

    @Query(
        """
            SELECT LocalFileEntity.* FROM LocalFileEntity
                LEFT JOIN CheckpointAudioTrackEntity ON LocalFileEntity.id = CheckpointAudioTrackEntity.localFileId
                LEFT JOIN BackgroundAudioTrackEntity ON LocalFileEntity.id = BackgroundAudioTrackEntity.localFileId
                LEFT JOIN ArAssetEntity ON LocalFileEntity.id = ArAssetEntity.localFileId
            WHERE CheckpointAudioTrackEntity.localFileId IS NULL
                    AND BackgroundAudioTrackEntity.localFileId IS NULL
                    AND ArAssetEntity.localFileId IS NULL
        """,
    )
    fun getUnusedFiles(): Flow<List<LocalFileEntity>>

    @Query("DELETE FROM LocalFileEntity WHERE hash IN (:hashes)")
    fun deleteByHashes(hashes: List<String>)
}
