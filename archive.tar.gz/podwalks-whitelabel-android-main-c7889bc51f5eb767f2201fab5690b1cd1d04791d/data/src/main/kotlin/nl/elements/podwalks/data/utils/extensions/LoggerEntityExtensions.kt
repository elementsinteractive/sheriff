package nl.elements.podwalks.data.utils.extensions

import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.data.podwalk.PodwalkEntity
import nl.elements.podwalks.data.utils.UpdateStatusResult.AFFECTED_TOO_MANY_ROWS
import nl.elements.podwalks.data.utils.UpdateStatusResult.FAILURE
import nl.elements.podwalks.data.utils.UpdateStatusResult.SUCCESS
import nl.elements.podwalks.data.utils.didUpdateSucceed
import nl.elements.podwalks.data.utils.extensions.EntityType.BACKGROUND_TRACK
import nl.elements.podwalks.data.utils.extensions.EntityType.NARRATOR_TRACK
import nl.elements.podwalks.data.utils.extensions.EntityType.TOUR
import nl.elements.podwalks.data.utils.extensions.EntityType.TOUR_ROUTE

internal fun Logger.logUpdateTourRouteDownloadState(
    affectedRows: Int,
    id: String,
    isDownloaded: Boolean,
) {
    val message = "isDownloaded=$isDownloaded"

    when (didUpdateSucceed(affectedRows)) {
        SUCCESS -> logUpdate(TOUR_ROUTE, id, message)
        AFFECTED_TOO_MANY_ROWS -> logUpdatedTooManyRows(TOUR_ROUTE, id, message)
        FAILURE -> logUpdateFailed(TOUR_ROUTE, id, message)
    }
}

internal fun Logger.logTourUpdate(affectedRows: Int, entity: PodwalkEntity) {
    when (didUpdateSucceed(affectedRows)) {
        SUCCESS -> logUpdate(TOUR, entity.id)
        FAILURE -> logUpdatedTooManyRows(TOUR, entity.id)
        AFFECTED_TOO_MANY_ROWS -> logUpdateFailed(TOUR, entity.id)
    }
}

internal fun Logger.logBackgroundTrackDownloadState(
    affectedRows: Int,
    id: String,
    isDownloaded: Boolean,
) {
    val message = "isDownloaded=$isDownloaded"

    when (didUpdateSucceed(affectedRows)) {
        SUCCESS -> logUpdate(BACKGROUND_TRACK, id, message)
        AFFECTED_TOO_MANY_ROWS -> logUpdatedTooManyRows(BACKGROUND_TRACK, id, message)
        FAILURE -> logUpdateFailed(BACKGROUND_TRACK, id, message)
    }
}

internal fun Logger.logNarratorTrackDownloadState(
    affectedRows: Int,
    tourId: String,
    isDownloaded: Boolean,
) {
    val message = "isDownloaded=$isDownloaded"

    when (didUpdateSucceed(affectedRows)) {
        SUCCESS -> logUpdate(NARRATOR_TRACK, tourId, message)
        FAILURE -> logUpdateFailed(NARRATOR_TRACK, tourId, message)
        AFFECTED_TOO_MANY_ROWS -> logUpdatedTooManyRows(NARRATOR_TRACK, tourId, message)
    }
}
