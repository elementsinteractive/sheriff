package nl.elements.podwalks.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class ConfigDocument(
    val minAndroidVersion: Long,
    val tours: List<TourUpdateDocument>,
    val seasons: List<SeasonDocument> = emptyList(),
)

@Serializable
data class TourUpdateDocument(
    val id: String,
    val updatedAt: String,
)
