package nl.elements.podwalks.data.podwalk

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.Companion.CASCADE
import androidx.room.PrimaryKey

@Entity(
    foreignKeys = [
        ForeignKey(
            entity = PodwalkEntity::class,
            parentColumns = ["id"],
            childColumns = ["podwalkId"],
            onDelete = CASCADE,
        ),
    ],
)
data class ImageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long,
    val hash: String,
    val url: String,
    val lightStatusBarIcons: Boolean,
    val podwalkId: String,
)
