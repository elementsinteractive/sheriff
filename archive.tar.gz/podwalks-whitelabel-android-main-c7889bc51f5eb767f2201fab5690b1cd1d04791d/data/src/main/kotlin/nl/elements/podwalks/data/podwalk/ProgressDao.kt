package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ProgressDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertOrUpdateProgress(progress: ProgressEntity)

    @Query(
        """DELETE FROM ProgressEntity WHERE pointId IN (
        SELECT ProgressEntity.pointId FROM ProgressEntity
            LEFT JOIN PointEntity ON PointEntity.podwalkId = :id
        )
        """,
    )
    suspend fun deleteAllForId(id: String)
}
