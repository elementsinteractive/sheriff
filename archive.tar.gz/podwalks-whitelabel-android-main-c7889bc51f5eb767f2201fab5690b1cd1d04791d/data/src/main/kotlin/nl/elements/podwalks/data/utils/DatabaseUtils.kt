@file:Suppress("MatchingDeclarationName")

package nl.elements.podwalks.data.utils

import nl.elements.podwalks.data.utils.UpdateStatusResult.AFFECTED_TOO_MANY_ROWS
import nl.elements.podwalks.data.utils.UpdateStatusResult.FAILURE
import nl.elements.podwalks.data.utils.UpdateStatusResult.SUCCESS

internal enum class UpdateStatusResult {
    SUCCESS, AFFECTED_TOO_MANY_ROWS, FAILURE
}

internal fun didUpdateSucceed(
    affectedRows: Int,
    expectedAffectedRows: Int = 1,
): UpdateStatusResult = when {
    affectedRows < expectedAffectedRows -> FAILURE
    affectedRows > expectedAffectedRows -> AFFECTED_TOO_MANY_ROWS
    else -> SUCCESS
}

internal fun didAffectRows(affectedRows: Int, minExpectedRows: Int = 1) = affectedRows >= minExpectedRows

internal fun isInvalidEntityId(id: Long): Boolean = id < 1
