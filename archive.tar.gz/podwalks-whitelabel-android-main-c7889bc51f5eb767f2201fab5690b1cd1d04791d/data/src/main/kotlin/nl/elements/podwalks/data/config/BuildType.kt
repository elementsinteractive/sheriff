package nl.elements.podwalks.data.config

enum class BuildType {
    DEBUG, STAGING, RELEASE
}
