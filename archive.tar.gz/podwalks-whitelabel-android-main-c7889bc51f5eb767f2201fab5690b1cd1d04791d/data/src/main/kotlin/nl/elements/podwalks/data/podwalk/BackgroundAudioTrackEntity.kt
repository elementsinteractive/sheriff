package nl.elements.podwalks.data.podwalk

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(
    foreignKeys = [
        ForeignKey(
            entity = LocalFileEntity::class,
            parentColumns = ["id"],
            childColumns = ["localFileId"],
        ),
    ],
)
data class BackgroundAudioTrackEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long,
    val filename: String,
    val hash: String,
    val url: String,
    val localFileId: Long,
)

data class BackgroundAudioTrackWithLocalFile(
    @Embedded val track: BackgroundAudioTrackEntity,
    @Relation(
        parentColumn = "localFileId",
        entityColumn = "id",
    )
    val file: LocalFileEntity,
)
