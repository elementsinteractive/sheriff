package nl.elements.podwalks.data.source.remote

import nl.elements.podwalks.data.model.response.ConfigDocument
import nl.elements.podwalks.data.model.response.TourDocuments
import retrofit2.http.GET
import retrofit2.http.Query

interface PodwalkAPIClient {
    @GET("globals/appContent/config")
    suspend fun getConfig(@Query("environment") environment: String): ConfigDocument

    @GET("tours?draft=false")
    suspend fun getTours(@Query("where[id][in]") ids: String): TourDocuments
}
