package nl.elements.podwalks.data.podwalk

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Junction
import androidx.room.PrimaryKey
import androidx.room.Relation
import nl.elements.podwalks.data.constant.DatabaseConstants

@Entity(
    foreignKeys = [
        ForeignKey(
            entity = BackgroundAudioTrackEntity::class,
            parentColumns = ["id"],
            childColumns = ["backgroundAudioTrackId"],
        ),
    ],
)
data class PodwalkEntity(
    @PrimaryKey
    @ColumnInfo(name = DatabaseConstants.ID)
    val id: String,
    @ColumnInfo(defaultValue = "")
    val updatedAt: String,
    val index: Int,
    val name: String,
    val description: String,
    val locationName: String,
    val startAddress: String,
    val durationInMinutes: Int,
    val lengthInMeters: Int,
    val backgroundAudioTrackId: Long,
    val shareContent: String,
    val shareInvitationText: String,
)

data class PodwalkEntityMetadata(
    @Embedded
    val podwalk: PodwalkEntity,
    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.PODWALK_ID,
        entity = ImageEntity::class,
    )
    val images: List<ImageEntity>,
    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.ID,
        entity = TagEntity::class,
        associateBy = Junction(
            value = TagCrossReference::class,
            parentColumn = DatabaseConstants.PODWALK_ID,
            entityColumn = DatabaseConstants.TAG_ID,
        ),
    )
    val tags: List<TagEntity>,
    @Relation(
        entity = BackgroundAudioTrackEntity::class,
        parentColumn = DatabaseConstants.BACKGROUND_AUDIO_TRACK_ID,
        entityColumn = DatabaseConstants.ID,
    )
    val backgroundAudioFile: BackgroundAudioTrackWithLocalFile,
    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.PODWALK_ID,
        entity = CoverImageEntity::class,
    )
    val coverImage: CoverImageEntity?,
    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.PODWALK_ID,
        entity = PointEntity::class,
    )
    val points: List<PointEntity>,
)
