package nl.elements.podwalks.data.podwalk

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.Companion.CASCADE
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(
    foreignKeys = [
        ForeignKey(
            entity = LocalFileEntity::class,
            parentColumns = ["id"],
            childColumns = ["localFileId"],
        ),
        ForeignKey(
            entity = PointEntity::class,
            parentColumns = ["id"],
            childColumns = ["pointId"],
            onDelete = CASCADE,
        ),
    ],
)
data class CheckpointAudioTrackEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long,
    val filename: String,
    val hash: String,
    val url: String,
    val localFileId: Long,
    val pointId: Long,
    val transcription: String?,
)

data class CheckpointAudioTrackWithLocalFile(
    @Embedded val track: CheckpointAudioTrackEntity,
    @Relation(
        parentColumn = "localFileId",
        entityColumn = "id",
    )
    val file: LocalFileEntity,
)
