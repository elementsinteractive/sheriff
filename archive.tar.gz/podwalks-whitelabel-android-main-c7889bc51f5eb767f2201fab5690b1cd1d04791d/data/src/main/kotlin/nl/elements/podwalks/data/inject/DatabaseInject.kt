package nl.elements.podwalks.data.inject

import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.Reusable
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import nl.elements.podwalks.data.database.DatabaseTransactionRunner
import nl.elements.podwalks.data.database.PodwalksRoomDatabase
import nl.elements.podwalks.data.database.PodwalksRoomDatabaseBuilder
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RoomDatabaseModule {
    @Singleton
    @Provides
    fun database(
        builder: PodwalksRoomDatabaseBuilder,
    ) = builder.build()
}

@Module
@InstallIn(SingletonComponent::class)
@Suppress("TooManyFunctions")
object DatabaseDaoModule {

    @Reusable
    @Provides
    fun podwalkDao(db: PodwalksRoomDatabase) = db.podwalkDao()

    @Reusable
    @Provides
    fun pointDao(db: PodwalksRoomDatabase) = db.pointDao()

    @Reusable
    @Provides
    fun progressDao(db: PodwalksRoomDatabase) = db.progressDao()

    @Reusable
    @Provides
    fun playedDao(db: PodwalksRoomDatabase) = db.playedDao()

    @Reusable
    @Provides
    fun remoteVersionDao(db: PodwalksRoomDatabase) = db.remoteUpdateDao()

    @Reusable
    @Provides
    fun backgroundTrackDao(db: PodwalksRoomDatabase) = db.backgroundTrackDao()

    @Reusable
    @Provides
    fun arSceneDao(db: PodwalksRoomDatabase) = db.arSceneDao()

    @Reusable
    @Provides
    fun imageDao(db: PodwalksRoomDatabase) = db.imageDao()

    @Reusable
    @Provides
    fun localFileDao(db: PodwalksRoomDatabase) = db.localFileDao()

    @Reusable
    @Provides
    fun seasonDao(db: PodwalksRoomDatabase) = db.seasonDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class DatabaseModuleBinds {
    @Singleton
    @Binds
    abstract fun transactionRunner(runner: RoomTransactionRunner): DatabaseTransactionRunner
}
