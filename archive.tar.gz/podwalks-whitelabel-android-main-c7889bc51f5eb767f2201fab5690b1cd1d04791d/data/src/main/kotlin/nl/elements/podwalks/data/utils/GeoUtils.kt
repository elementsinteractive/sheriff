package nl.elements.podwalks.data.utils

import nl.elements.podwalks.data.model.domain.Coordinate
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

@Suppress("MagicNumber")
object GeoUtils {

    private const val EARTH_RADIUS = 6371

    fun calculateDistanceInMeters(first: Coordinate, second: Coordinate): Double {
        val latDistance = Math.toRadians(second.latitude - first.latitude)
        val lonDistance = Math.toRadians(second.longitude - first.longitude)

        val a = (
            sin(latDistance / 2) * sin(latDistance / 2) +
                (
                    cos(Math.toRadians(first.latitude)) * cos(Math.toRadians(second.latitude)) *
                        sin(lonDistance / 2) * sin(lonDistance / 2)
                    )
            )

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        val distance = (EARTH_RADIUS * c * 1000).pow(2.0)

        return sqrt(distance)
    }
}
