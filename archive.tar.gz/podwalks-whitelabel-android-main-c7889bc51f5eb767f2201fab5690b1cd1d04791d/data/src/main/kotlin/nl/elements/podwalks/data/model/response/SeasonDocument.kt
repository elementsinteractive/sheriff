package nl.elements.podwalks.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class SeasonDocument(
    val id: String,
    val name: String,
    val seasonCover: SeasonCoverDocument,
    val tourIds: List<String>,
)

@Serializable
data class SeasonCoverDocument(
    val url: String,
)
