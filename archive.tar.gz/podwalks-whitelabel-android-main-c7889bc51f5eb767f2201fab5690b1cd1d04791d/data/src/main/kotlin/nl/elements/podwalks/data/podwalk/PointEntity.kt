package nl.elements.podwalks.data.podwalk

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import nl.elements.podwalks.data.constant.DatabaseConstants

@Entity(
    indices = [
        Index(
            DatabaseConstants.INDEX,
            DatabaseConstants.PODWALK_ID,
            unique = true,
        ),
    ],
    foreignKeys = [
        ForeignKey(
            entity = PodwalkEntity::class,
            parentColumns = [DatabaseConstants.ID],
            childColumns = [DatabaseConstants.PODWALK_ID],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class PointEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(DatabaseConstants.ID)
    val id: Long,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val indexWithinPodwalk: Int?,
    @ColumnInfo(DatabaseConstants.INDEX)
    val indexWithinRoute: Int,
    val triggerRadiusInMeters: Int,
    @ColumnInfo(DatabaseConstants.PODWALK_ID)
    val podwalkId: String,
)

data class CheckpointWithFile(
    @Embedded val checkpoint: PointEntity,
    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.POINT_ID,
        entity = CheckpointAudioTrackEntity::class,
    )
    val track: CheckpointAudioTrackWithLocalFile,

    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.POINT_ID,
        entity = ProgressEntity::class,
    )
    val progressEntity: ProgressEntity?,

    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.POINT_ID,
        entity = PlayedEntity::class,
    )
    val playedEntity: PlayedEntity?,

    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.POINT_ID,
        entity = ArSceneEntity::class,
    )
    val arSceneWithAssets: ArSceneWithAssets?,
)
