package nl.elements.podwalks.data.model.domain

data class ApplicationVersion(val major: Int, val minor: Int, val patch: Int) {

    operator fun compareTo(other: ApplicationVersion): Int {
        val majorComp = major.compareTo(other.major)
        val minorComp = minor.compareTo(other.minor)

        return when {
            majorComp != 0 -> majorComp
            minorComp != 0 -> minorComp
            else -> patch.compareTo(other.patch)
        }
    }
}
