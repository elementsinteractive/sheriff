package nl.elements.podwalks.data.utils

import nl.elements.podwalks.data.model.domain.ApplicationVersion
import timber.log.Timber

@Suppress("MagicNumber")
object ApplicationVersionParsing {

    /**
     * Parses a [String] as an [ApplicationVersion].
     *
     * @param version The string that will be parsed as an [ApplicationVersion].
     *
     * @throws NumberFormatException in case a version name segment can't be parsed to an [Int].
     * @throws IllegalStateException in case not enough version name segments are parsed.
     */
    fun parse(version: String): ApplicationVersion {
        // Split the version name in segments based on a period and parse each segment to an Int
        val parsedVersions = version.split(".").map { it.toInt() }

        // Only continue all version name types (major, minor and patch) are present
        check(parsedVersions.size >= 3) { "Missing amount of version numbers." }

        return ApplicationVersion(parsedVersions[0], parsedVersions[1], parsedVersions[2])
    }

    fun parseOrNull(version: String): ApplicationVersion? = try {
        parse(version)
    } catch (ex: NumberFormatException) {
        Timber.e(ex, "Version contains non-numbers: $version")
        null
    } catch (ex: IllegalStateException) {
        Timber.e(ex, "Version contains insufficient numbers: $version")
        null
    }
}
