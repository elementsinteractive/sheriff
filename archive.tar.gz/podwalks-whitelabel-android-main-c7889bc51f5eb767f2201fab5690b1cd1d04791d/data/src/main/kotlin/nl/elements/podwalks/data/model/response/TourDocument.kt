package nl.elements.podwalks.data.model.response

import kotlinx.serialization.Serializable

@Serializable
data class TourDocuments(
    val docs: List<TourDocument>,
)

@Serializable
data class TourDocument(
    val id: String,
    val backgroundTrack: BackgroundTrack,
    val tags: List<Tag>,
    val route: Route,
    val description: String,
    val locationName: String,
    val images: List<Image>,
    val length: Length,
    val name: String,
    val startLocationAddress: String,
    val deepUpdateAt: String,
    val finishedTourScreen: FinishedTourScreen,
    val coverImage: CoverImageFile?,
) {
    @Serializable
    data class Tag(
        val tag: String,
    )

    @Serializable
    data class BackgroundTrack(
        val filename: String,
        val checksum: String,
        val url: String,
    )

    @Serializable
    data class Length(
        val inMeters: Long,
        val inMinutes: Long,
    )

    @Serializable
    data class Image(
        val file: ImageFile,
    )

    @Serializable
    data class ImageFile(
        val filename: String,
        val checksum: String,
        val url: String,
        val lightStatusBar: Boolean,
    )

    @Serializable
    data class CoverImageFile(
        val filename: String,
        val checksum: String,
        val url: String,
    )

    @Serializable
    data class Route(
        val points: List<Point>,
    )

    @Serializable
    data class Point(
        val location: List<Double>,
        val isCheckpoint: Boolean,
        val checkpoint: Checkpoint?,
    )

    @Serializable
    data class Checkpoint(
        val name: String?,
        val triggerRadiusInMeters: Long,
        val narratorTrack: NarratorTrack?,
        val arScene: ArScene?,
    )

    @Serializable
    data class ArScene(
        val sceneId: String?,
        val assets: List<ArAsset>?,
    )

    @Serializable
    data class ArAsset(
        val filename: String,
        val checksum: String,
        val url: String,
    )

    @Serializable
    data class NarratorTrack(
        val filename: String,
        val checksum: String,
        val url: String,
        val transcription: String?,
    )

    @Serializable
    data class FinishedTourScreen(
        val shareText: String,
        val content: String,
    )
}
