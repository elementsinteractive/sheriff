package nl.elements.podwalks.data.state

data class PlaybackPosition(
    val currentPositionInMs: Long,
    val totalLengthInMs: Long,
)

data class PlaybackState(
    val isPlaying: Boolean,
    val position: PlaybackPosition?,
    val mode: PlaybackMode?,
)

sealed class PlaybackMode {
    object BackgroundMode : PlaybackMode()
    data class CheckpointMode(val index: Int) : PlaybackMode()
}

data class TourGuideState(
    val tourId: String,
    val startTimeInMs: Long,
    val playback: PlaybackState,
)
