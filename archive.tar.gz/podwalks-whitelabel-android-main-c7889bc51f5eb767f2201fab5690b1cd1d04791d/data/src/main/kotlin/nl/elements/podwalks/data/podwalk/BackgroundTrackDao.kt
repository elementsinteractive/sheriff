package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BackgroundTrackDao {

    @Query(
        """
        SELECT BackgroundAudioTrackEntity.* FROM BackgroundAudioTrackEntity
            LEFT JOIN PodwalkEntity ON BackgroundAudioTrackEntity.id = PodwalkEntity.backgroundAudioTrackId
        WHERE PodwalkEntity.backgroundAudioTrackId IS NULL
        """,
    )
    fun getUnusedAudioFiles(): Flow<List<BackgroundAudioTrackWithLocalFile>>

    @Insert
    suspend fun insert(entity: BackgroundAudioTrackEntity): Long

    @Update
    suspend fun update(entity: BackgroundAudioTrackEntity)

    @Query(
        """
            SELECT BackgroundAudioTrackEntity.* FROM BackgroundAudioTrackEntity 
                INNER JOIN PodwalkEntity ON BackgroundAudioTrackEntity.id = PodwalkEntity.backgroundAudioTrackId
            WHERE PodwalkEntity.id = :podwalkId
        """,
    )
    fun getBackgroundTrackForPodwalk(podwalkId: String): Flow<BackgroundAudioTrackEntity?>

    @Query(
        """
            DELETE FROM BackgroundAudioTrackEntity WHERE id IN (
                SELECT BackgroundAudioTrackEntity.id FROM BackgroundAudioTrackEntity
                    LEFT JOIN PodwalkEntity ON PodwalkEntity.backgroundAudioTrackId = BackgroundAudioTrackEntity.id
                WHERE PodwalkEntity.backgroundAudioTrackId IS NULL
            )
        """,
    )
    suspend fun deleteUnused()
}
