package nl.elements.podwalks.data.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import nl.elements.podwalks.data.constant.DatabaseConstants
import nl.elements.podwalks.data.podwalk.SeasonEntity

@Entity(
    indices = [
        Index(DatabaseConstants.SEASON_ID),
    ],
    primaryKeys = [
        DatabaseConstants.PODWALK_ID,
        DatabaseConstants.SEASON_ID,
    ],
    foreignKeys = [
        ForeignKey(
            entity = SeasonEntity::class,
            parentColumns = [DatabaseConstants.ID],
            childColumns = [DatabaseConstants.SEASON_ID],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class PodwalkSeasonCrossReference(
    @ColumnInfo(name = DatabaseConstants.PODWALK_ID)
    val podwalkId: String,
    @ColumnInfo(name = DatabaseConstants.SEASON_ID)
    val seasonId: String,
)
