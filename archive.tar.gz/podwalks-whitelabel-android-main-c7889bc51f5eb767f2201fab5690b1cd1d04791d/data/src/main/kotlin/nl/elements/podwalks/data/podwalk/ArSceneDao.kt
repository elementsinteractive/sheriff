package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ArSceneDao {

    @Query("SELECT * FROM ArSceneEntity WHERE pointId = :pointId")
    fun getArSceneForCheckpoint(pointId: Long): Flow<ArSceneEntity?>

    @Insert
    suspend fun insertScene(entity: ArSceneEntity): Long

    @Update
    suspend fun updateScene(entity: ArSceneEntity)

    @Insert
    suspend fun insertAsset(entity: ArAssetEntity)

    @Query("DELETE FROM ArAssetEntity WHERE arSceneId = :sceneId")
    suspend fun deleteAllAssetsForScene(sceneId: Long)

    @Query("SELECT * FROM ArAssetEntity WHERE hash = :hash")
    fun getAsset(hash: String): Flow<ArAssetEntity?>

    @Query(
        """
            SELECT ArAssetEntity.* FROM ArAssetEntity
                INNER JOIN ArSceneEntity ON ArAssetEntity.arSceneId = ArSceneEntity.id
                INNER JOIN PointEntity ON ArSceneEntity.pointId = PointEntity.id
                INNER JOIN PodwalkEntity ON PointEntity.podwalkId = PodwalkEntity.id
            WHERE PodwalkEntity.id = :podwalkId
        """,
    )
    fun getAssets(podwalkId: String): Flow<List<ArAssetWithLocalFile>>

    @Query(
        """
        UPDATE ArAssetEntity
            SET filename = :filename, url = :url, arSceneId = :sceneId
        WHERE hash = :hash
            """,
    )
    suspend fun updateAsset(
        hash: String,
        filename: String,
        url: String,
        sceneId: String,
    )

    @Query("DELETE FROM ArSceneEntity WHERE id IN (:sceneIds)")
    suspend fun delete(sceneIds: List<String>)
}
