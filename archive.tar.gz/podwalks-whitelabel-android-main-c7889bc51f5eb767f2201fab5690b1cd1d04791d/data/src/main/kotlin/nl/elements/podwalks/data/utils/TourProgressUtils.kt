package nl.elements.podwalks.data.utils

import nl.elements.podwalks.utils.inject.LegacyPodwalkApi

@LegacyPodwalkApi
object TourProgressUtils {

    fun determineNextChapter(
        checkpoints: List<Int>,
        visitedChapterIndexes: List<Int>,
    ): Int? =
        when {
            visitedChapterIndexes.isEmpty() -> checkpoints.minOrNull()
            visitedChapterIndexes.containsAll(checkpoints) -> null
            else -> visitedChapterIndexes.max() + 1
        }

    fun determineCurrentChapter(visitedIndices: List<Int>): Int? =
        when {
            visitedIndices.isEmpty() -> null
            else -> visitedIndices.max()
        }

    fun isNextChapter(checkpointIndices: List<Int>, visitedIndices: List<Int>, chapterIndex: Int) =
        determineNextChapter(checkpointIndices, visitedIndices) == chapterIndex
}
