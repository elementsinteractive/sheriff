package nl.elements.podwalks.data.podwalk

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Junction
import androidx.room.PrimaryKey
import androidx.room.Relation
import nl.elements.podwalks.data.constant.DatabaseConstants
import nl.elements.podwalks.data.database.PodwalkSeasonCrossReference

@Entity
data class SeasonEntity(
    @PrimaryKey
    @ColumnInfo(name = DatabaseConstants.ID)
    val id: String,
    val index: Int,
    val name: String,
    val coverImageUrl: String,
)

data class SeasonEntityMetadata(
    @Embedded
    val season: SeasonEntity,

    @Relation(
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.ID,
        associateBy = Junction(
            value = PodwalkSeasonCrossReference::class,
            parentColumn = DatabaseConstants.SEASON_ID,
            entityColumn = DatabaseConstants.PODWALK_ID,
        ),
    )
    val podwalks: List<PodwalkEntity>,
)
