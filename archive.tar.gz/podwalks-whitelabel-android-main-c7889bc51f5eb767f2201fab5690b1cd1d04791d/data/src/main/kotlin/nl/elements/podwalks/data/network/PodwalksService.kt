package nl.elements.podwalks.data.network

import nl.elements.podwalks.data.model.response.ConfigDocument
import nl.elements.podwalks.data.model.response.TourDocument
import java.io.File

interface PodwalksService {
    suspend fun getConfig(): ConfigDocument
    suspend fun getTours(ids: List<String>): List<TourDocument>
    suspend fun downloadFile(path: String, output: File)
}
