package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
@Suppress("TooManyFunctions")
interface PointDao {

    @Query(
        """
        SELECT * FROM PointEntity as Points
            INNER JOIN PodwalkEntity ON Points.podwalkId = PodwalkEntity.id
            WHERE Points.indexWithinPodwalk IS NOT NULL
        """,
    )
    fun getCheckpoints(): Flow<Map<PodwalkEntity, List<CheckpointWithFile>>>

    @Query(
        """
        SELECT * FROM PointEntity as Points
            WHERE Points.indexWithinPodwalk IS NOT NULL AND Points.podwalkId = :podwalkId
        """,
    )
    fun getCheckpoints(podwalkId: String): Flow<List<CheckpointWithFile>>

    @Query("SELECT * FROM PointEntity WHERE PointEntity.podwalkId = :podwalkId")
    fun getPoints(podwalkId: String): Flow<List<PointEntity>>

    @Query("SELECT * FROM PointEntity WHERE indexWithinPodwalk = :index AND podwalkId = :podwalkId")
    suspend fun getCheckpointByIndex(index: Int, podwalkId: String): PointEntity?

    @Query(
        """
        UPDATE PointEntity 
            SET 
                name = :name,
                latitude = :latitude,
                longitude = :longitude,
                triggerRadiusInMeters = :triggerRadiusInMeters
        WHERE id = :id""",
    )
    suspend fun updatePoint(
        id: Long,
        name: String,
        latitude: Double,
        longitude: Double,
        triggerRadiusInMeters: Int,
    )

    @Insert
    suspend fun insertPoint(point: PointEntity): Long

    @Insert
    suspend fun insertFile(file: CheckpointAudioTrackEntity): Long

    @Query(
        """
            UPDATE CheckpointAudioTrackEntity SET
                filename = :filename,
                hash = :hash,
                url = :url,
                localFileId = :localFileId
            WHERE id = :id
        """,
    )
    suspend fun updateFile(
        id: Long,
        filename: String,
        hash: String,
        url: String,
        localFileId: Long,
    )

    @Query("SELECT * FROM CheckpointAudioTrackEntity WHERE pointId = :id")
    suspend fun getFileByPoint(id: Long): CheckpointAudioTrackEntity?

    @Query("DELETE FROM PointEntity WHERE podwalkId = :podwalkId")
    suspend fun deletePointForPodwalk(podwalkId: String)

    @Query("DELETE FROM PointEntity WHERE id IN (:ids)")
    suspend fun deletePointsByIndexes(ids: List<Long>)

    @Query("SELECT * FROM CheckpointAudioTrackEntity")
    fun getAudioFiles(): Flow<List<CheckpointAudioTrackWithLocalFile>>

    @Query("DELETE FROM CheckpointAudioTrackEntity WHERE url IN (:urls)")
    suspend fun deleteAudioFiles(urls: List<String>)
}
