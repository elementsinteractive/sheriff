package nl.elements.podwalks.data.model.domain

enum class AppVersionQualification {
    PASSED, BELOW_MINIMUM, UNKNOWN
}
