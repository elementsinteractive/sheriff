package nl.elements.podwalks.data.constant

object SyncConstants {

    const val TOUR_DATA_DIR_NAME = "tour_data"
    const val BACKGROUND_TRACKS_DIR_NAME = "background_tracks"
    const val NARRATOR_TRACKS_DIR_NAME = "narrator_tracks"
    const val TOURS_DIR_NAME = "tours"
    const val VOLUMETRICS_DIR = "volumetrics"

    object Tour {
        const val IMAGES_DIR_NAME = "images"
        const val ROUTES_DIR_NAME = "routes"
        const val TRACKS_DIR_NAME = "tracks"
    }
}
