package nl.elements.podwalks.data.source.remote

import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.data.config.AppConfiguration
import nl.elements.podwalks.data.config.BuildType
import nl.elements.podwalks.data.model.response.ConfigDocument
import nl.elements.podwalks.data.model.response.TourDocument
import nl.elements.podwalks.data.network.PodwalksService
import nl.elements.podwalks.data.utils.extensions.downloadFile
import okhttp3.OkHttpClient
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PodwalkAPIService @Inject constructor(
    private val apiClient: PodwalkAPIClient,
    private val httpClient: OkHttpClient,
    private val appConfig: AppConfiguration,
    private val logger: Logger,
) : PodwalksService {
    override suspend fun getConfig(): ConfigDocument {
        val environment = if (appConfig.buildType == BuildType.RELEASE) "production" else "staging"
        val configDocument = apiClient.getConfig(environment)

        logger.v("Successfully fetched configuration.")

        return configDocument
    }

    override suspend fun getTours(ids: List<String>): List<TourDocument> {
        return apiClient.getTours(ids.joinToString(",")).docs
    }

    override suspend fun downloadFile(path: String, output: File) {
        httpClient.downloadFile(path, output)
    }
}
