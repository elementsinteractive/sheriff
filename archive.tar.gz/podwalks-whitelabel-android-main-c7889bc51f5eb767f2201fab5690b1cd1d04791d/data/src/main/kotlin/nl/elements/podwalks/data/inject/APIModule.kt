package nl.elements.podwalks.data.inject

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import nl.elements.podwalks.data.config.AppConfiguration
import nl.elements.podwalks.data.source.remote.PodwalkAPIClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class APIModule {
    companion object {
        private const val OKHTTP_WITH_AUTHORIZATION = "OKHTTP_WITH_AUTHORIZATION"
    }

    @Provides
    @Singleton
    fun retrofit(
        @Named(OKHTTP_WITH_AUTHORIZATION) client: OkHttpClient,
        appConfig: AppConfiguration,
    ): Retrofit =
        Retrofit.Builder()
            .baseUrl("${appConfig.podwalkAPIHost}/api/")
            .client(client)
            .addConverterFactory(
                MoshiConverterFactory.create(
                    Moshi.Builder()
                        .addLast(KotlinJsonAdapterFactory())
                        .build(),
                ),
            )
            .addConverterFactory(Json.asConverterFactory("application/json".toMediaType()))
            .build()

    @Provides
    @Named(OKHTTP_WITH_AUTHORIZATION)
    @Singleton
    fun okHttpClientWithAuthorization(appConfig: AppConfiguration) = OkHttpClient.Builder()
        .apply {
            addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("Authorization", "users API-Key ${appConfig.podwalkAPIKey}")
                    .build()
                chain.proceed(request)
            }
        }.build()

    @Provides
    @Singleton
    fun okHttpClient() = OkHttpClient.Builder().build()

    @Provides
    @Singleton
    internal fun api(retrofit: Retrofit) = retrofit.create(PodwalkAPIClient::class.java)
}
