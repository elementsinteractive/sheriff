package nl.elements.podwalks.data.podwalk

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.Companion.CASCADE
import nl.elements.podwalks.data.constant.DatabaseConstants

@Entity(
    primaryKeys = [
        DatabaseConstants.POINT_ID,
    ],
    foreignKeys = [
        ForeignKey(
            entity = PointEntity::class,
            parentColumns = [DatabaseConstants.ID],
            childColumns = [DatabaseConstants.POINT_ID],
            onDelete = CASCADE,
        ),
    ],
)
data class PlayedEntity(
    @ColumnInfo(name = DatabaseConstants.POINT_ID)
    val pointId: Long,
)
