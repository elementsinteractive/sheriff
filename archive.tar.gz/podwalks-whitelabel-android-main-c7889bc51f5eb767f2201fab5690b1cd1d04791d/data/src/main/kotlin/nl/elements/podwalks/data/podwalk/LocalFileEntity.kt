package nl.elements.podwalks.data.podwalk

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    indices = [Index("hash", unique = true)],
)
data class LocalFileEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long,
    val hash: String,
    val path: String?,
)
