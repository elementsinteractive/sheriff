package nl.elements.podwalks.data.podwalk

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.Companion.CASCADE
import androidx.room.PrimaryKey
import androidx.room.Relation
import nl.elements.podwalks.data.constant.DatabaseConstants

@Entity(
    foreignKeys = [
        ForeignKey(
            entity = PointEntity::class,
            parentColumns = ["id"],
            childColumns = ["pointId"],
            onDelete = CASCADE,
        ),
    ],
)
data class ArSceneEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long,
    val name: String,
    val pointId: Long,
)

@Entity(
    foreignKeys = [
        ForeignKey(
            entity = ArSceneEntity::class,
            parentColumns = [DatabaseConstants.ID],
            childColumns = [DatabaseConstants.AR_SCENE_ID],
            onDelete = CASCADE,
        ),
        ForeignKey(
            entity = LocalFileEntity::class,
            parentColumns = ["id"],
            childColumns = ["localFileId"],
        ),
    ],
)
data class ArAssetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long,
    val hash: String,
    val filename: String,
    val url: String,
    val localFileId: Long,
    @ColumnInfo(DatabaseConstants.AR_SCENE_ID)
    val arSceneId: Long,
)

data class ArAssetWithLocalFile(
    @Embedded val asset: ArAssetEntity,
    @Relation(
        parentColumn = "localFileId",
        entityColumn = "id",
    )
    val file: LocalFileEntity,
)

data class ArSceneWithAssets(
    @Embedded val scene: ArSceneEntity,
    @Relation(
        entity = ArAssetEntity::class,
        parentColumn = DatabaseConstants.ID,
        entityColumn = DatabaseConstants.AR_SCENE_ID,
    )
    val assets: List<ArAssetWithLocalFile>,
)
