package nl.elements.podwalks.data.bus

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import nl.elements.podwalks.data.model.domain.Coordinate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LastKnownLocationEventBus @Inject constructor() {

    private val _location = MutableStateFlow<Coordinate?>(null)
    val location: StateFlow<Coordinate?>
        get() = _location

    fun post(coordinate: Coordinate) {
        _location.value = coordinate
    }
}
