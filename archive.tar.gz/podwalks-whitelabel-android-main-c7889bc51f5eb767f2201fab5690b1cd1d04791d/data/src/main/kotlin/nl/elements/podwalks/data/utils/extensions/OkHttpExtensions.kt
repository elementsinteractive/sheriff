package nl.elements.podwalks.data.utils.extensions

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.buffer
import okio.sink
import java.io.File
import java.io.IOException
import kotlin.coroutines.resumeWithException

/**
 * Suspend extension that allows suspend [Call] inside coroutine.
 *
 * @return Result of request or throw exception
 */
@Suppress("TooGenericExceptionCaught", "SwallowedException")
suspend fun Call.await(): Response {
    return suspendCancellableCoroutine { continuation ->
        enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                continuation.resume(response, null)
            }

            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isCancelled) return
                continuation.resumeWithException(e)
            }
        })

        continuation.invokeOnCancellation {
            try {
                cancel()
            } catch (ex: Throwable) {
                // Ignore cancel exception
            }
        }
    }
}

/**
 * Downloads a remote file.
 *
 * @param url source URL
 * @param output destination file
 *
 * @throws IOException in case of failed HTTP request
 */
suspend fun OkHttpClient.downloadFile(url: String, output: File) {
    val request = Request.Builder()
        .url(url)
        .build()

    val response = newCall(request).await()
    if (!response.isSuccessful) {
        throw IOException("Unexpected HTTP code $response")
    }

    response.body?.let { responseBody ->
        output.sink().buffer().use { sink ->
            sink.writeAll(responseBody.source())
        }
    }
}
