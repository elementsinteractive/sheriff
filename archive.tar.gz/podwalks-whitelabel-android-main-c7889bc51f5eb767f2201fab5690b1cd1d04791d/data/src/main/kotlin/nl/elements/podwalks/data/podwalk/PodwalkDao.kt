package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
@Suppress("TooManyFunctions")
interface PodwalkDao {

    @Query("SELECT * FROM PodwalkEntity WHERE id = :id")
    fun getPodwalk(id: String): Flow<PodwalkEntityMetadata?>

    @Query("SELECT * FROM PodwalkEntity WHERE id = :id")
    fun getPodwalkTemp(id: String): Flow<PodwalkEntity?>

    @Query("SELECT * FROM PodwalkEntity")
    fun getPodwalks(): Flow<List<PodwalkEntityMetadata>>

    @Insert
    suspend fun insert(podwalk: PodwalkEntity): Long

    @Update
    suspend fun update(podwalk: PodwalkEntity): Int

    @Query("DELETE FROM PodwalkEntity WHERE id IN (:ids)")
    suspend fun delete(ids: List<String>)

    @Query("SELECT * FROM TagEntity")
    suspend fun getTags(): List<TagEntity>

    @Insert
    suspend fun insertTags(tags: List<TagEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTagsCrossReferences(references: List<TagCrossReference>)

    @Query("DELETE FROM TagCrossReference WHERE podwalkId = :podwalkId AND tagId IN (:ids)")
    suspend fun deleteTagCrossReference(podwalkId: String, ids: List<Long>)

    @Query(
        """DELETE FROM TagEntity 
        WHERE id IN (
            SELECT id FROM TagEntity
                LEFT JOIN TagCrossReference ON TagCrossReference.tagId == TagEntity.id 
                WHERE TagCrossReference.podwalkId IS NULL
        )""",
    )
    suspend fun deleteUnreferencedTags()
}
