package nl.elements.podwalks.data.utils.extensions

import nl.elements.mobilization.logging.Logger

internal fun Logger.logCreates(type: EntityType, ids: List<String>, message: String? = null) {
    ids.forEach { logCreate(type, it, message) }
}

internal fun Logger.logCreate(type: EntityType, id: String, message: String? = null) {
    i("Created new ${type.name} with ID: $id. ${message.orEmpty()}".trim())
}

internal fun Logger.logCreateAlreadyExists(type: EntityType, id: String) {
    i("Did not create new ${type.name}, entity with ID \"$id\" already existed")
}

internal fun Logger.logUpdate(type: EntityType, id: String, message: String? = null) {
    i("Updated ${type.name} with ID: $id. ${message.orEmpty()}".trim())
}

internal fun Logger.logUpdateFailed(type: EntityType, id: String, message: String? = null) {
    i("Failed to update ${type.name} with ID: $id. ${message.orEmpty()}".trim())
}

internal fun Logger.logUpdatedTooManyRows(type: EntityType, id: String, message: String? = null) {
    w("Updated more than one record when updating ${type.name} with ID: $id. ${message.orEmpty()}".trim())
}

internal fun Logger.logDelete(type: EntityType, affectedRows: Int) {
    i("Deleted $affectedRows ${type.name}(S)")
}

internal enum class EntityType {
    TOUR,
    PODWALK_IMAGE,
    TOUR_PROGRESS,
    TOUR_ROUTE,
    POINT,
    BACKGROUND_TRACK,
    NARRATOR_TRACK,
    TOUR_VERSIONS,
}
