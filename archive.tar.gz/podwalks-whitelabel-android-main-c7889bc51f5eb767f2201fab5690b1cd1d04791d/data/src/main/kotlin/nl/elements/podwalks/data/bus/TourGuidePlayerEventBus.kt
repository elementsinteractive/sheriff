package nl.elements.podwalks.data.bus

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TourGuidePlayerEventBus @Inject constructor() {

    private val _events = MutableSharedFlow<Event>()
    val events: SharedFlow<Event>
        get() = _events

    suspend fun emit(event: Event) {
        _events.emit(event)
    }

    sealed class Event {
        object SeekingDone : Event()
        data class PlayingNarratorTrack(val checkpointIndex: Int) : Event()
        object EndOfPlaylist : Event()
    }
}
