package nl.elements.podwalks.data.podwalk

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface PlayedDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertOrUpdateProgress(progress: PlayedEntity)

    @Query(
        """DELETE FROM PlayedEntity WHERE pointId IN (
        SELECT PlayedEntity.pointId FROM PlayedEntity
            LEFT JOIN PointEntity ON PointEntity.podwalkId = :id
        )
        """,
    )
    suspend fun deleteAllForId(id: String)
}
