package nl.elements.podwalks.data.bus

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import nl.elements.podwalks.utils.inject.ProcessLifetime
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TourProgressEventBus @Inject constructor(
    @ProcessLifetime private val processScope: CoroutineScope,
) {

    private val _events = MutableSharedFlow<ProgressEvent>()
    val progressEvents: MutableSharedFlow<ProgressEvent>
        get() = _events

    fun post(event: ProgressEvent) {
        processScope.launch {
            _events.emit(event)
        }
    }

    data class ProgressEvent(val tourId: String, val checkpointIndex: Int)
}
