package nl.elements.podwalks.data.model.domain

import nl.elements.podwalks.utils.inject.LegacyPodwalkApi

typealias LegacyCoordinate = Coordinate

@LegacyPodwalkApi
data class Coordinate(val latitude: Double, val longitude: Double)
