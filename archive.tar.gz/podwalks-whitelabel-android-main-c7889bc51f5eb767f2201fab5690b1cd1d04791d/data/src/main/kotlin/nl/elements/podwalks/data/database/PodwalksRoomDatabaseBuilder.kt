package nl.elements.podwalks.data.database

import android.content.Context
import android.os.Debug
import androidx.room.Room
import dagger.hilt.android.qualifiers.ApplicationContext
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import nl.elements.podwalks.data.config.AppConfiguration
import nl.elements.podwalks.data.config.BuildType
import nl.elements.podwalks.utils.inject.DeviceIdentifier
import javax.inject.Inject

class PodwalksRoomDatabaseBuilder @Inject constructor(
    @ApplicationContext private val context: Context,
    @DeviceIdentifier private val identifier: String,
    private val configuration: AppConfiguration,
) {
    fun build(): PodwalksRoomDatabase {
        System.loadLibrary("sqlcipher")

        return Room.databaseBuilder(context, PodwalksRoomDatabase::class.java, "application.db").apply {
            // Don't encrypt the database for debug builds (allows usage of AS Database Inspector)
            if (configuration.buildType != BuildType.DEBUG) {
                openHelperFactory(SupportOpenHelperFactory(identifier.toByteArray()))
            }

            if (Debug.isDebuggerConnected()) {
                allowMainThreadQueries()
            }

            fallbackToDestructiveMigration()
        }.build()
    }
}
