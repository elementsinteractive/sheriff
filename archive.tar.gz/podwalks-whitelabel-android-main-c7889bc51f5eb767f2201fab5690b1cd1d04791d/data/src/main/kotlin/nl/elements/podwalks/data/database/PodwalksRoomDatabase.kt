package nl.elements.podwalks.data.database

import androidx.room.AutoMigration
import androidx.room.Database
import androidx.room.RoomDatabase
import nl.elements.podwalks.data.podwalk.ArAssetEntity
import nl.elements.podwalks.data.podwalk.ArSceneDao
import nl.elements.podwalks.data.podwalk.ArSceneEntity
import nl.elements.podwalks.data.podwalk.BackgroundAudioTrackEntity
import nl.elements.podwalks.data.podwalk.BackgroundTrackDao
import nl.elements.podwalks.data.podwalk.CheckpointAudioTrackEntity
import nl.elements.podwalks.data.podwalk.CoverImageEntity
import nl.elements.podwalks.data.podwalk.ImageDao
import nl.elements.podwalks.data.podwalk.ImageEntity
import nl.elements.podwalks.data.podwalk.LocalFileDao
import nl.elements.podwalks.data.podwalk.LocalFileEntity
import nl.elements.podwalks.data.podwalk.PlayedDao
import nl.elements.podwalks.data.podwalk.PlayedEntity
import nl.elements.podwalks.data.podwalk.PodwalkDao
import nl.elements.podwalks.data.podwalk.PodwalkEntity
import nl.elements.podwalks.data.podwalk.PointDao
import nl.elements.podwalks.data.podwalk.PointEntity
import nl.elements.podwalks.data.podwalk.ProgressDao
import nl.elements.podwalks.data.podwalk.ProgressEntity
import nl.elements.podwalks.data.podwalk.RemotePodwalkUpdate
import nl.elements.podwalks.data.podwalk.RemotePodwalkUpdateDao
import nl.elements.podwalks.data.podwalk.SeasonDao
import nl.elements.podwalks.data.podwalk.SeasonEntity
import nl.elements.podwalks.data.podwalk.TagCrossReference
import nl.elements.podwalks.data.podwalk.TagEntity

@Database(
    version = 5,
    entities = [
        PodwalkEntity::class,
        ImageEntity::class,
        CoverImageEntity::class,
        TagEntity::class,
        TagCrossReference::class,
        PointEntity::class,
        ProgressEntity::class,
        CheckpointAudioTrackEntity::class,
        BackgroundAudioTrackEntity::class,
        RemotePodwalkUpdate::class,
        ArSceneEntity::class,
        ArAssetEntity::class,
        LocalFileEntity::class,
        PlayedEntity::class,
        SeasonEntity::class,
        PodwalkSeasonCrossReference::class,
    ],
    autoMigrations = [
        AutoMigration(
            from = 2,
            to = 3,
            spec = PodwalksRoomDatabaseMigrations.UpdateToGraphQL::class,
        ),
    ],
)
@Suppress("TooManyFunctions")
abstract class PodwalksRoomDatabase : RoomDatabase() {
    abstract fun podwalkDao(): PodwalkDao
    abstract fun pointDao(): PointDao
    abstract fun progressDao(): ProgressDao
    abstract fun playedDao(): PlayedDao
    abstract fun remoteUpdateDao(): RemotePodwalkUpdateDao
    abstract fun backgroundTrackDao(): BackgroundTrackDao
    abstract fun arSceneDao(): ArSceneDao
    abstract fun imageDao(): ImageDao
    abstract fun localFileDao(): LocalFileDao

    abstract fun seasonDao(): SeasonDao
}
