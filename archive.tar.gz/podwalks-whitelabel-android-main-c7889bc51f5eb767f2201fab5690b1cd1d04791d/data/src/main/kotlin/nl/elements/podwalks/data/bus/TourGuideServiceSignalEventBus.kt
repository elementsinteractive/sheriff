package nl.elements.podwalks.data.bus

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import nl.elements.podwalks.utils.inject.ProcessLifetime
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TourGuideServiceSignalEventBus @Inject constructor(
    @ProcessLifetime private val processScope: CoroutineScope,
) {

    private val _serviceSignals = MutableSharedFlow<Signal>(1)
    val serviceSignals: SharedFlow<Signal>
        get() = _serviceSignals

    fun post(signal: Signal) {
        processScope.launch {
            _serviceSignals.emit(signal)
        }
    }

    sealed class Signal {
        data class Start(val tourId: String) : Signal()
        data class AlreadyRunning(val tourId: String) : Signal()

        object Stop : Signal()
    }
}
