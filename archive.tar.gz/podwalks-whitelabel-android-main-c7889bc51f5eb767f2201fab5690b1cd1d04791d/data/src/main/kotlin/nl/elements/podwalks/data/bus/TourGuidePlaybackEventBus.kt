package nl.elements.podwalks.data.bus

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TourGuidePlaybackEventBus @Inject constructor() {

    private val _events = MutableSharedFlow<Event>()
    val events: SharedFlow<Event>
        get() = _events

    suspend fun emit(event: Event) {
        _events.emit(event)
    }

    sealed class Event {
        object Play : Event()
        object Pause : Event()
        data class Seek(val position: Float) : Event()
        data class PlayNarratorTrackAtIndex(val index: Int) : Event()
    }
}
