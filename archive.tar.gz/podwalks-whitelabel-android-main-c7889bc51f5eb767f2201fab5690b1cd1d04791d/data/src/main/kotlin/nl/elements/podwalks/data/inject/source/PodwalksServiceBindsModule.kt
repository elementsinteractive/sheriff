package nl.elements.podwalks.data.inject.source

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import nl.elements.podwalks.data.network.PodwalksService
import nl.elements.podwalks.data.source.remote.PodwalkAPIService

@Module
@InstallIn(SingletonComponent::class)
abstract class PodwalksServiceBindsModule {

    @Binds
    abstract fun bindPodwalksService(service: PodwalkAPIService): PodwalksService
}
