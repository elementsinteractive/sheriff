package nl.elements.podwalks.data.constant

object DatabaseConstants {
    const val INDEX = "indexWithinRoute"
    const val ID = "id"
    const val POINT_ID = "pointId"
    const val PODWALK_ID = "podwalkId"
    const val BACKGROUND_AUDIO_TRACK_ID = "backgroundAudioTrackId"
    const val TAG_ID = "tagId"
    const val AR_SCENE_ID = "arSceneId"
    const val SEASON_ID = "seasonId"
}
