package nl.elements.podwalks.data.database

import androidx.room.DeleteColumn
import androidx.room.DeleteTable
import androidx.room.RenameColumn
import androidx.room.RenameTable
import androidx.room.migration.AutoMigrationSpec
import nl.elements.podwalks.data.constant.DatabaseConstants

class PodwalksRoomDatabaseMigrations {
    @RenameColumn.Entries(
        RenameColumn(
            tableName = "CheckpointEntity",
            fromColumnName = "indexWithinPodwalk",
            toColumnName = DatabaseConstants.INDEX,
        ),
        RenameColumn(
            tableName = "ProgressEntity",
            fromColumnName = "checkpointId",
            toColumnName = DatabaseConstants.POINT_ID,
        ),
        RenameColumn(
            tableName = "CheckpointAudioTrackEntity",
            fromColumnName = "checkpointId",
            toColumnName = DatabaseConstants.POINT_ID,
        ),
        RenameColumn(
            tableName = "ArSceneEntity",
            fromColumnName = "checkpointId",
            toColumnName = DatabaseConstants.POINT_ID,
        ),
    )
    @RenameTable(fromTableName = "CheckpointEntity", toTableName = "PointEntity")
    @DeleteColumn.Entries(
        DeleteColumn(tableName = "PodwalkEntity", columnName = "version"),
        DeleteColumn(tableName = "PodwalkEntity", columnName = "routeId"),
        DeleteColumn(tableName = "PodwalkEntity", columnName = "startLatitude"),
        DeleteColumn(tableName = "PodwalkEntity", columnName = "startLongitude"),
        DeleteColumn(tableName = "BackgroundAudioTrackEntity", columnName = "remotePath"),
        DeleteColumn(tableName = "CheckpointAudioTrackEntity", columnName = "remotePath"),
        DeleteColumn(tableName = "ArAssetEntity", columnName = "remotePath"),
    )
    @DeleteTable.Entries(
        DeleteTable(tableName = "RouteEntity"),
        DeleteTable(tableName = "RouteCoordinateEntity"),
        DeleteTable(tableName = "RemotePodwalkVersion"),
    )
    class UpdateToGraphQL : AutoMigrationSpec
}
