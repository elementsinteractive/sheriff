package nl.elements.podwalks.data.config

interface AppConfiguration {
    val applicationId: String
    val buildType: BuildType
    val versionCode: Int
    val podwalkAPIHost: String
    val podwalkAPIKey: String
    val versionName: String
}
