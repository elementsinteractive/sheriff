plugins {
    id("podwalks.android.library")
    kotlin("plugin.serialization")
}

android {
    namespace = "nl.elements.podwalks.data"

    defaultConfig {
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
        }
    }
}

dependencies {
    api(project(":shared:utils"))

    implementation(libs.androidx.room.runtime)
    implementation(libs.kotlin.reflect)
    implementation(libs.mobilization.loggingApi)
    implementation(libs.bundles.androidxDataStoreLib)

    api(libs.bundles.androidxMedia)
    api(libs.google.tink)

    api(libs.androidx.room.ktx)
    api("org.threeten:threetenbp:${libs.versions.threetenbp.get()}:no-tzdb")
    api(libs.kotlin.datetime)
    api(libs.kotlinxSerializationJson)

    ksp(libs.dagger.compiler)

    ksp(libs.androidx.room.compiler)

    implementation(libs.bundles.sqlcipher)

    implementation(libs.dagger.hilt.base)
    ksp(libs.dagger.hilt.compiler)

    api(libs.bundles.ktor)

    api(libs.timber)
    api(libs.timberkt)

    implementation(libs.retrofit.retrofit2)
    implementation(libs.retrofit.converterMoshi)
    implementation(libs.retrofit.serializationConverter)
    implementation(libs.moshi.kotlin)
}

// Test dependencies
dependencies {
    testImplementation(project(":shared:test"))

    testImplementation(libs.kotlin.test)
    testImplementation(libs.kotlin.testJunit)

    testImplementation(libs.junit.junit)
    testImplementation(libs.robolectric)
    testImplementation(libs.mockk)

    testImplementation(libs.kotlin.stdlib)
    testImplementation(libs.androidx.archCoreTesting)
    testImplementation(libs.androidx.test.core)
    testImplementation(libs.androidx.room.testing)
    testImplementation(libs.coroutines.test)

    testImplementation(libs.dagger.hilt.test)

    kspTest(libs.androidx.room.compiler)
    kspTest(libs.dagger.compiler)
    kspTest(libs.dagger.hilt.compiler)

    // Needed for Tzdb
    testImplementation(libs.threeTen.bp)
    // Needed for Main dispatcher to work
    testImplementation(libs.coroutines.android)
}
