const dangerElements = require("@makerstreet/danger").default;

dangerElements("android")