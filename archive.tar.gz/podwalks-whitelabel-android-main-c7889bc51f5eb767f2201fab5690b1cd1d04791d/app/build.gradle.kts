import com.google.firebase.crashlytics.buildtools.gradle.CrashlyticsExtension
import nl.elements.podwalks.BuildType.Companion.toName
import nl.elements.podwalks.BuildType.Debug
import nl.elements.podwalks.BuildType.Release
import nl.elements.podwalks.BuildType.Staging
import nl.elements.podwalks.Config.DEVELOPMENT_SIGNING_NAME

plugins {
    id("podwalks.android.application")
    id("de.mannodermaus.android-junit5")
    id("dagger.hilt.android.plugin")
    id("com.mikepenz.aboutlibraries.plugin")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    idea
    id("podwalks.android.application.flavors")
    id("podwalks.android.application.compose")

    alias(libs.plugins.podwalks.buildConfig)
}

apply("config/jacoco.gradle")

fun isCI() = System.getenv().containsKey("CI")

android {

    namespace = "nl.elements.podwalks"

    defaultConfig {
        applicationId = "nl.elements.podwalks"

        versionCode = 42
        versionName = "1.0.0"

        testInstrumentationRunner = "nl.elements.podwalks.PodwalksTestRunner"

        testHandleProfiling = true
        testFunctionalTest = true

        vectorDrawables.useSupportLibrary = true

        setProperty("archivesBaseName", "PodwalksKotlin-$versionName-$versionCode") // Enable again when using new DeployPlus
    }

    // Speeds up local development builds
    if (project.hasProperty("devBuild")) {
        splits.abi.isEnable = false
        splits.density.isEnable = false
        androidResources.noCompress.clear()
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        getByName(Debug.toName()) {
            applicationIdSuffix = ".dev"

            isDebuggable = true
            isMinifyEnabled = false
            enableUnitTestCoverage = isCI()

            configure<CrashlyticsExtension> {
                mappingFileUploadEnabled = false
            }

            matchingFallbacks.add("release")
            isJniDebuggable = true

            signingConfig = signingConfigs.getByName(DEVELOPMENT_SIGNING_NAME)
        }

        getByName(Staging.toName()) {
            initWith(getByName("release"))
            applicationIdSuffix = ".staging"

            isDebuggable = false
            isMinifyEnabled = true
            enableUnitTestCoverage = false

            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

            matchingFallbacks.add("release")

            signingConfig = signingConfigs.getByName(DEVELOPMENT_SIGNING_NAME)
        }

        getByName(Release.toName()) {
            isDebuggable = false
            isMinifyEnabled = true
            enableUnitTestCoverage = false

            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    packaging {
        resources {
            excludes.addAll(
                listOf(
                    "LICENSE.txt",
                    "NOTICE.txt",
                    "protobuf.meta",
                    "META-INF/LICENSE*",
                    "META-INF/rxjava.properties",
                    "META-INF/NOTICE",
                    "META-INF/MANIFEST.MF",
                    "META-INF/maven/com.google.guava/guava/pom.xml",
                    "META-INF/maven/com.google.guava/guava/pom.properties"
                )
            )
        }

        jniLibs.keepDebugSymbols.add(
            "*/arm64-v8a/*.so"
        )
    }

    configurations {
        testImplementation {
            exclude("org.jetbrains.kotlin", "kotlin-test-junit")
        }
        all {
            resolutionStrategy {
                force(libs.androidx.room.runtime)
                force(libs.androidx.fragment)
                force(libs.androidx.annotation)
            }
        }
    }
}

apply(plugin = "idea")

idea {
    module {
        isDownloadJavadoc = true
        isDownloadSources = true
    }
}

// App dependencies
dependencies {

    // Core
    implementation(project(":data"))
    implementation(project(":domain"))
    implementation(project(":shared:utils"))
    implementation(project(":shared:resources"))
    implementation(project(":shared:presentation"))
    implementation(project(":shared:analytics"))
    implementation(project(":shared:notifications"))
    implementation(project(":tasks"))

    // UI features
    implementation(project(":features:ui-splash"))
    implementation(project(":features:ui-onboarding"))
    implementation(project(":features:ui-walk-share"))
    implementation(project(":features:ui-list"))
    implementation(project(":features:ui-info"))
    implementation(project(":features:ui-walk"))
    implementation(project(":features:ui-details"))
    implementation(project(":features:notification-tour"))

    // Waalre
    "waalreImplementation"(project(":features:waalre:ui-ar"))

    // VRT
    "vrtImplementation"(project(":features:ui-login"))

    implementation(libs.kotlin.stdlib)

    implementation(libs.bundles.mobilization)

    implementation(libs.bundles.coroutines)
    implementation(libs.bundles.google)

    implementation(platform(libs.google.firebaseBom))
    implementation(libs.bundles.firebase)

    implementation(libs.google.gsm.maps)
    implementation(libs.google.location)

    compileOnly(libs.androidx.annotation)
    implementation(libs.bundles.androidx)
    implementation(libs.bundles.compose)
    implementation(libs.androidx.compose.navigation)
    implementation(libs.bundles.lifecycle)
    implementation(libs.bundles.navigationFragment)
    implementation(libs.androidx.work.runtimeKtx)
    implementation(libs.androidx.hilt.work)
    implementation(libs.bundles.androidxMedia)
    implementation(libs.dagger.dagger)
    implementation(libs.dagger.hilt.base)
    implementation(libs.dagger.androidSupport)
    implementation(libs.timber)
    implementation(libs.timberkt)
    implementation(libs.threeTen.abp)
    implementation(libs.kotlin.datetime)
    implementation(libs.bundles.mavericks)
    implementation(libs.bundles.aboutLibraries)

    implementation(platform(libs.google.firebaseBom))
    implementation(libs.bundles.firebase)

    implementation(libs.bundles.androidxDataStoreLib)
    implementation(libs.google.tink)

    ksp(libs.androidx.lifecycle.compiler)
    ksp(libs.dagger.compiler)
    ksp(libs.dagger.hilt.compiler)
    ksp(libs.dagger.androidProcessor)
}

// Waalre dependencies
dependencies {
    waalreImplementation(libs.google.ar.core)
}

// VRT dependencies
dependencies {
    vrtImplementation(libs.vrt.login)
    vrtImplementation(libs.play.services.auth)
    vrtImplementation(libs.vrt.consents.core)
    vrtImplementation(libs.vrt.consents.protector)
}

// Test dependencies
dependencies {
    testImplementation(project(":shared:test"))

    testImplementation(libs.kotlin.stdlib)
    testImplementation(libs.kotlin.test)
    testImplementation(libs.kotlin.testJunit)
    testImplementation(libs.coroutines.test)
    testImplementation(libs.dagger.hilt.test)

    testImplementation(libs.okhttpMockwebserver)
    testImplementation(libs.mockk)

    testImplementation(libs.junit.junit)
    testImplementation(libs.junit.jupiterApi)
    testRuntimeOnly(libs.junit.jupiterEngine)
    testRuntimeOnly(libs.junit.vintageEngine)
    testImplementation(libs.junit.jupiterParams)
}

// Android test dependencies
dependencies {
    androidTestImplementation(libs.androidx.compose.uiTest)
    androidTestImplementation(libs.kotlin.reflect)
    androidTestImplementation(libs.dagger.hilt.test)
    androidTestImplementation(libs.bundles.androidTestDependencies)
    kspAndroidTest(libs.dagger.hilt.compiler)
}
