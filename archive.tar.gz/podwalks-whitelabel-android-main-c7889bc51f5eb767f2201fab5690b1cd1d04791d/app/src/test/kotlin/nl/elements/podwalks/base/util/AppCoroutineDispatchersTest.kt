package nl.elements.podwalks.base.util

import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runTest
import nl.elements.podwalks.test.MainCoroutineRule
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import org.junit.Rule
import kotlin.test.Test
import kotlin.test.assertEquals

class AppCoroutineDispatchersTest {

    @get:Rule
    val testRule = MainCoroutineRule()

    private val dispatcher = testRule.testDispatcher

    @Test
    fun `Dispatchers are accessible`() = runTest {
        val dispatchers = AppCoroutineDispatchers(
            io = dispatcher,
            computation = dispatcher,
            main = dispatcher,
        )

        launch(dispatchers.io) {
            assertEquals(dispatcher, dispatchers.io)
        }

        launch(dispatchers.computation) {
            assertEquals(dispatcher, dispatchers.computation)
        }

        launch(dispatchers.main) {
            assertEquals(dispatcher, dispatchers.main)
        }
    }
}
