package nl.elements.podwalks.android.inject

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import nl.elements.podwalks.android.initializers.StartupInitializer
import nl.elements.podwalks.utils.initializers.AppInitializer

@Module
@InstallIn(SingletonComponent::class)
abstract class InitializersBinds {
    @Binds
    @IntoSet
    abstract fun startupInitializer(bind: StartupInitializer): AppInitializer
}
