package nl.elements.podwalks.android.initializers

import android.app.Application
import com.google.ar.core.ArCoreApk
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import nl.elements.podwalks.utils.initializers.AppInitializer
import nl.elements.podwalks.utils.inject.ProcessLifetime
import javax.inject.Inject

/**
 * Checks early if the device supports ARCore
 * Recommended here: https://developers.google.com/ar/develop/java/enable-arcore#check_if_arcore_is_supported
 */
class StartupInitializer @Inject constructor(
    @ProcessLifetime private val processScope: CoroutineScope,
) : AppInitializer {
    override fun init(application: Application) {
        processScope.launch {
            ArCoreApk.getInstance().checkAvailability(application)
        }
    }
}
