package nl.elements.podwalks.inject

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import nl.elements.podwalks.android.app.initializers.VrtInitializer
import nl.elements.podwalks.utils.initializers.AppInitializer

@Module
@InstallIn(SingletonComponent::class)
abstract class VrtInitializersBinds {
    @Binds
    @IntoSet
    abstract fun vrtInitializer(bind: VrtInitializer): AppInitializer
}
