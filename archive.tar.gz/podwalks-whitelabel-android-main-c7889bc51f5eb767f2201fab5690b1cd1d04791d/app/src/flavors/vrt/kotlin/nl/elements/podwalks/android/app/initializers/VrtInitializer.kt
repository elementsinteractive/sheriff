package nl.elements.podwalks.android.app.initializers

import android.app.Application
import be.vrt.consents.VrtConsents
import be.vrt.eba.Eba
import be.vrt.eba.schemas.TouchPointBrand
import be.vrt.login.core.VrtLogin
import be.vrt.login.core.analytics.VrtLoginTracker
import be.vrt.login.userservices.model.Env
import nl.elements.podwalks.BuildConfig
import nl.elements.podwalks.utils.initializers.AppInitializer
import javax.inject.Inject

class VrtInitializer @Inject constructor(
    private val eba: Eba,
) : AppInitializer {

    override fun init(application: Application) {
        val isRelease = BuildConfig.BUILD_TYPE.equals("release", true)
        VrtLogin.init(
            application,
            client = BuildConfig.VRT_CLIENT_ID,
            loginBff = BuildConfig.VRT_LOGIN_BFF,
            env = if (isRelease) Env.Production else Env.Staging,
            debugLog = true,
        )
        VrtLoginTracker.eba = eba
        VrtLoginTracker.touchPointBrand = TouchPointBrand.vrtPodwalks
        VrtConsents.init(
            application,
            sourcePointPropertyId = BuildConfig.SOURCEPOINT_ID,
            sourcePointPropertyName = BuildConfig.SOURCEPOINT_NAME,
            sourcePointPrivacyManagerId = BuildConfig.SOURCEPOINT_MANAGER_ID,
        )
    }
}
