package nl.elements.podwalks.inject

import com.airbnb.mvrx.hilt.AssistedViewModelFactory
import com.airbnb.mvrx.hilt.MavericksViewModelComponent
import com.airbnb.mvrx.hilt.ViewModelKey
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.multibindings.IntoMap
import nl.elements.podwalks.info.profile.ProfileViewModel

@Module
@InstallIn(MavericksViewModelComponent::class)
interface VrtViewModelsModule {
    @Binds
    @IntoMap
    @ViewModelKey(ProfileViewModel::class)
    fun profileViewModelFactory(factory: ProfileViewModel.Factory): AssistedViewModelFactory<*, *>
}
