package nl.elements.podwalks.android.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.navOptions
import nl.elements.podwalks.list.navigation.navigateToPodwalks
import nl.elements.podwalks.onboarding.navigation.navigateToOnboarding
import nl.elements.podwalks.splash.navigation.Splash
import nl.elements.podwalks.splash.navigation.splashScreen

fun NavGraphBuilder.flavorScreens(navController: NavController) {
    splashScreen(
        onOpenOnboarding = {
            navController.navigateToOnboarding(
                navOptions = navOptions {
                    popUpTo<Splash> {
                        inclusive = true
                    }
                },
            )
        },
        onOpenWalkList = {
            navController.navigateToPodwalks(
                navOptions = navOptions {
                    popUpTo<Splash> {
                        inclusive = true
                    }
                },
            )
        },
        onOpenLogin = {},
    )
}

fun NavController.navigateToAr(
    identifier: String,
    navOptions: NavOptions? = null,
) {
}
