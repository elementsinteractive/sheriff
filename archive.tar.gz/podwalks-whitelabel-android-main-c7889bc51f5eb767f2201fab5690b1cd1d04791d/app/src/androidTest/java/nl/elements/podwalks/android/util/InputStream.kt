package nl.elements.podwalks.android.util

import java.io.InputStream
import java.nio.charset.Charset

fun InputStream.readTextAndClose(charset: Charset = Charsets.UTF_8): String =
    bufferedReader(charset).use { it.readText() }
