package nl.elements.podwalks.android

import dagger.hilt.android.testing.CustomTestApplication
import nl.elements.podwalks.android.app.BaseApplication

@CustomTestApplication(BaseApplication::class)
class AndroidTestApplication
