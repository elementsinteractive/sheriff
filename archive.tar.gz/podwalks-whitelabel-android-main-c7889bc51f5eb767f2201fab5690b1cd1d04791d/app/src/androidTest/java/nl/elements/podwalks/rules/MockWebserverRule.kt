package nl.elements.podwalks.rules

import android.content.Context
import nl.elements.podwalks.network.mock.MockResponsesHandler
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import org.junit.rules.TestRule
import org.junit.runner.Description
import org.junit.runners.model.Statement
import java.io.IOException

class MockWebserverRule(context: Context) : TestRule {

    private val customDispatcher = object : Dispatcher() {
        override fun dispatch(request: RecordedRequest): MockResponse {
            handler.handleRequest(request)?.let {
                return it
            }

            return MockResponse().setResponseCode(RESPONSE_CODE_NOT_FOUND)
        }
    }

    val mockWebServer = MockWebServer().apply { dispatcher = customDispatcher }

    val handler: MockResponsesHandler = MockResponsesHandler(mockWebServer, context)

    private var started = false

    override fun apply(base: Statement, description: Description?): Statement =
        object : Statement() {
            override fun evaluate() {
                startOrThrow()
                try {
                    base.evaluate()
                } finally {
                    try {
                        mockWebServer.shutdown()
                    } catch (e: IOException) {
                    }
                }
            }
        }

    private fun startOrThrow() {
        if (started) return
        try {
            mockWebServer.start()
            started = true
        } catch (e: IOException) {
            throw RuntimeException(e)
        }
    }

    companion object {
        const val RESPONSE_CODE_NOT_FOUND = 404
    }
}
