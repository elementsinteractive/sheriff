package nl.elements.podwalks.robots.base

open class BaseRobot {
    // Place shared Robots logic here
}
