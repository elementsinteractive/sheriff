package nl.elements.podwalks.network.mock

import android.content.Context
import nl.elements.podwalks.android.util.readTextAndClose
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest

class MockResponsesHandler constructor(
    private val mockWebServer: MockWebServer,
    private val context: Context,
) {
    private val responses = mutableListOf<DispatchedResponse>()

    fun clear() = responses.clear()

    fun add(dispatchedResponse: DispatchedResponse) {
        responses.add(dispatchedResponse)
    }

    fun insertBefore(dispatchedResponse: DispatchedResponse) {
        responses.add(0, dispatchedResponse)
    }

    fun add(mockResponse: MockResponse) = mockWebServer.enqueue(mockResponse)

    fun handleRequest(recordedRequest: RecordedRequest): MockResponse? {
        val path = recordedRequest.path

        responses.forEach {
            val formattedPath = "/${it.path}"

            if (formattedPath == path) {
                return when (it) {
                    is DispatchedResponse.WithResource -> getMockResponseWithResource(it)
                    is DispatchedResponse.WithObject -> it.mockResponse
                }
            }
        }

        return null
    }

    private fun getMockResponseWithResource(response: DispatchedResponse.WithResource) =
        context.resources.openRawResource(response.resource).readTextAndClose().let { body ->
            response.mockResponse.setBody(body)
        }
}
