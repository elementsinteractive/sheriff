package nl.elements.podwalks.test.base

import androidx.test.core.app.ApplicationProvider
import dagger.hilt.android.testing.BindValue
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import nl.elements.podwalks.rules.MockWebserverRule
import okhttp3.mockwebserver.MockWebServer
import org.junit.Rule

@HiltAndroidTest
open class BaseNetworkTest {
    @get:Rule(order = 0)
    var hiltRule = HiltAndroidRule(this)

    @get:Rule(order = 1)
    val mockRule = MockWebserverRule(ApplicationProvider.getApplicationContext())

    @BindValue
    @JvmField
    val mockWebServer: MockWebServer = mockRule.mockWebServer
}
