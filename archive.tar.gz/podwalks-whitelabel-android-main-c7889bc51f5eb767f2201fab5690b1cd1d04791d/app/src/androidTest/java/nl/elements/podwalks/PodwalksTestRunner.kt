package nl.elements.podwalks

import android.app.Application
import android.content.Context
import androidx.test.runner.AndroidJUnitRunner
import nl.elements.podwalks.android.AndroidTestApplication_Application

class PodwalksTestRunner : AndroidJUnitRunner() {
    override fun newApplication(
        cl: ClassLoader?,
        className: String?,
        context: Context?,
    ): Application = super.newApplication(cl, AndroidTestApplication_Application::class.java.name, context)
}
