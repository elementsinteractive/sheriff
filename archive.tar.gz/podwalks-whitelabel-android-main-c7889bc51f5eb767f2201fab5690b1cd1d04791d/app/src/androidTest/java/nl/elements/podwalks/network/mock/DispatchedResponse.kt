package nl.elements.podwalks.network.mock

import androidx.annotation.RawRes
import okhttp3.mockwebserver.MockResponse

sealed class DispatchedResponse {
    data class WithResource(
        override val path: String,
        val mockResponse: MockResponse,
        @RawRes val resource: Int,
    ) : DispatchedResponse()

    data class WithObject(
        override val path: String,
        val mockResponse: MockResponse,
    ) : DispatchedResponse()

    abstract val path: String
}
