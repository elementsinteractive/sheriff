package nl.elements.podwalks.android.service

import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import nl.elements.podwalks.data.bus.TourGuideServiceSignalEventBus.Signal.AlreadyRunning
import nl.elements.podwalks.data.bus.TourGuideServiceSignalEventBus.Signal.Start
import nl.elements.podwalks.domain.interactors.touring.observers.ObserveTourPlaybackEvents.Event.Pause
import nl.elements.podwalks.domain.interactors.touring.observers.ObserveTourPlaybackEvents.Event.Play
import nl.elements.podwalks.domain.interactors.touring.observers.ObserveTourPlaybackEvents.Event.PlayNarratorTrackAtIndex
import nl.elements.podwalks.domain.interactors.touring.observers.ObserveTourPlaybackEvents.Event.Seek

@UnstableApi
internal fun TourGuideService.launchTourGuideServiceSignals(coroutineScope: CoroutineScope) =
    coroutineScope.launch {
        observeServiceSignals().collectLatest {
            when (it) {
                is AlreadyRunning -> setupPodwalkGuide(
                    it.tourId,
                )

                is Start -> setupPodwalkGuide(
                    it.tourId,
                )

                else -> {}
            }
        }
    }

internal fun TourGuideService.launchProcessPlayerEvents(coroutineScope: CoroutineScope) {
    coroutineScope.launch {
        // Collect the events emitted by the player and process them
        processPlayerEvents(audioPlayer.playbackEvent)
    }
}

internal fun TourGuideService.launchProgressPlaybackPosition(coroutineScope: CoroutineScope) {
    coroutineScope.launch {
        processPlaybackPositionEvents(audioPlayer.playbackPosition)
    }
}

internal fun TourGuideService.controlAudioPlayer(coroutineScope: CoroutineScope) {
    coroutineScope.launch {
        observeTourPlaybackEvents()
            .collect {
                withContext(dispatchers.main) {
                    // Map events/signals to method invocations on the player
                    when (it) {
                        Pause -> audioPlayer.pause()
                        Play -> audioPlayer.play()
                        is Seek -> audioPlayer.seek(it.position)
                        is PlayNarratorTrackAtIndex ->
                            audioPlayer.playNextNarratorTrack(it.index)
                    }
                }
            }
    }
}
