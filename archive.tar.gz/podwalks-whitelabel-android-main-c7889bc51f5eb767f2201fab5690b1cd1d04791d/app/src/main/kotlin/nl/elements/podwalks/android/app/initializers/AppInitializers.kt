package nl.elements.podwalks.android.app.initializers

import android.app.Application
import nl.elements.podwalks.utils.initializers.AppInitializer
import javax.inject.Inject

class AppInitializers @Inject constructor() : AppInitializer {
    @Inject
    lateinit var managers: Set<@JvmSuppressWildcards AppInitializer>

    override fun init(application: Application) {
        managers.forEach { m ->
            m.init(application)
        }
    }
}
