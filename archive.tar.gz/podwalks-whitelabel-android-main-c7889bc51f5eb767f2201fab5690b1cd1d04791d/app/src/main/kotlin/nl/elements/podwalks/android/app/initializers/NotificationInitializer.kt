package nl.elements.podwalks.android.app.initializers

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import nl.elements.podwalks.shared.resources.R
import nl.elements.podwalks.tourservice.android.notification.NotificationConstants
import nl.elements.podwalks.utils.initializers.AppInitializer
import javax.inject.Inject

class NotificationInitializer @Inject constructor(
    @ApplicationContext private val context: Context,
) : AppInitializer {

    override fun init(application: Application) {
        createPodwalkLocationNotificationChannel()
    }

    private fun createPodwalkLocationNotificationChannel() {
        val channelName = context.getString(R.string.android_tour_location_channel_name)
        val importance = NotificationManager.IMPORTANCE_DEFAULT

        val notificationChannel =
            NotificationChannel(NotificationConstants.CHANNEL_ID, channelName, importance).apply {
                description = context.getString(R.string.android_tour_location_channel_description)
            }

        context.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(notificationChannel)
    }
}
