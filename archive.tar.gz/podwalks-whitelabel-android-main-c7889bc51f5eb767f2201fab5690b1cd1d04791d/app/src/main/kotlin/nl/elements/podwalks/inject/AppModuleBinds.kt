package nl.elements.podwalks.inject

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import nl.elements.mobilization.logging.ElementsLogger
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.analytics.AnalyticsConfiguration
import nl.elements.podwalks.android.app.PodwalksAnalyticsConfiguration
import nl.elements.podwalks.android.app.PodwalksConfiguration
import nl.elements.podwalks.android.app.PodwalksState
import nl.elements.podwalks.data.config.AppConfiguration
import nl.elements.podwalks.data.state.AppState
import nl.elements.podwalks.domain.interactors.walk.api.GetWalkPlayerState
import nl.elements.podwalks.domain.interactors.walk.api.ToggleAudioPodwalkPlayback
import nl.elements.podwalks.domain.interactors.walk.impl.GetWalkPlayerStateImpl
import nl.elements.podwalks.domain.interactors.walk.impl.ToggleAudioPodwalkPlaybackImpl
import nl.elements.podwalks.domain.podwalk.ArRepository
import nl.elements.podwalks.domain.podwalk.BackgroundTrackRepository
import nl.elements.podwalks.domain.podwalk.CheckpointTrackRepository
import nl.elements.podwalks.domain.podwalk.DefaultDeleteProgress
import nl.elements.podwalks.domain.podwalk.DefaultGetAllPodwalkProgress
import nl.elements.podwalks.domain.podwalk.DefaultGetCheckpoints
import nl.elements.podwalks.domain.podwalk.DefaultGetDownloadState
import nl.elements.podwalks.domain.podwalk.DefaultGetDownloadStates
import nl.elements.podwalks.domain.podwalk.DefaultGetGuideById
import nl.elements.podwalks.domain.podwalk.DefaultGetPodwalkById
import nl.elements.podwalks.domain.podwalk.DefaultGetPodwalks
import nl.elements.podwalks.domain.podwalk.DefaultGetProgress
import nl.elements.podwalks.domain.podwalk.DefaultGetSeasons
import nl.elements.podwalks.domain.podwalk.DefaultGetWaypoints
import nl.elements.podwalks.domain.podwalk.DefaultSyncPodwalks
import nl.elements.podwalks.domain.podwalk.DefaultSyncRemoteConfiguration
import nl.elements.podwalks.domain.podwalk.DefaultWithinCheckpointRadius
import nl.elements.podwalks.domain.podwalk.DeleteProgress
import nl.elements.podwalks.domain.podwalk.GetAllPodwalkProgress
import nl.elements.podwalks.domain.podwalk.GetCheckpoints
import nl.elements.podwalks.domain.podwalk.GetDownloadState
import nl.elements.podwalks.domain.podwalk.GetDownloadStates
import nl.elements.podwalks.domain.podwalk.GetPodwalkById
import nl.elements.podwalks.domain.podwalk.GetPodwalkGuideById
import nl.elements.podwalks.domain.podwalk.GetPodwalks
import nl.elements.podwalks.domain.podwalk.GetProgress
import nl.elements.podwalks.domain.podwalk.GetSeasons
import nl.elements.podwalks.domain.podwalk.GetWaypoints
import nl.elements.podwalks.domain.podwalk.LocalFileRepository
import nl.elements.podwalks.domain.podwalk.PodwalkProgressRepository
import nl.elements.podwalks.domain.podwalk.PodwalkRepository
import nl.elements.podwalks.domain.podwalk.PointRepository
import nl.elements.podwalks.domain.podwalk.RoomArRepository
import nl.elements.podwalks.domain.podwalk.RoomBackgroundTrackRepository
import nl.elements.podwalks.domain.podwalk.RoomCheckpointRepository
import nl.elements.podwalks.domain.podwalk.RoomCheckpointTrackRepository
import nl.elements.podwalks.domain.podwalk.RoomLocalFileRepository
import nl.elements.podwalks.domain.podwalk.RoomPodwalkProgressRepository
import nl.elements.podwalks.domain.podwalk.RoomPodwalkRepository
import nl.elements.podwalks.domain.podwalk.RoomSeasonRepository
import nl.elements.podwalks.domain.podwalk.SeasonRepository
import nl.elements.podwalks.domain.podwalk.SyncPodwalks
import nl.elements.podwalks.domain.podwalk.SyncRemoteConfiguration
import nl.elements.podwalks.domain.podwalk.TrackAudioPlayer
import nl.elements.podwalks.domain.podwalk.WithinCheckpointRadius
import nl.elements.podwalks.tourservice.android.player.ExoTrackAudioPlayer

@Module
@InstallIn(SingletonComponent::class)
abstract class AppModuleBinds {
    @Binds
    abstract fun logger(logger: ElementsLogger): Logger

    @Binds
    abstract fun state(bind: PodwalksState): AppState

    @Binds
    abstract fun configuration(config: PodwalksConfiguration): AppConfiguration

    @Binds
    abstract fun analyticsConfiguration(config: PodwalksAnalyticsConfiguration): AnalyticsConfiguration

    @Binds
    abstract fun trackAudioPlayer(player: ExoTrackAudioPlayer): TrackAudioPlayer
}

@Suppress("TooManyFunctions")
@Module
@InstallIn(SingletonComponent::class)
abstract class PodwalkModuleBinds {

    @Binds
    abstract fun podwalkRepository(repository: RoomPodwalkRepository): PodwalkRepository

    @Binds
    abstract fun seasonRepository(repository: RoomSeasonRepository): SeasonRepository

    @Binds
    abstract fun checkpointRepository(repository: RoomCheckpointRepository): PointRepository

    @Binds
    abstract fun checkpointTrackRepository(repository: RoomCheckpointTrackRepository): CheckpointTrackRepository

    @Binds
    abstract fun backgroundTrackRepository(repository: RoomBackgroundTrackRepository): BackgroundTrackRepository

    @Binds
    abstract fun progressRepository(repository: RoomPodwalkProgressRepository): PodwalkProgressRepository

    @Binds
    abstract fun arRepository(impl: RoomArRepository): ArRepository

    @Binds
    abstract fun localFileRepository(impl: RoomLocalFileRepository): LocalFileRepository

    @Binds
    abstract fun getPodwalks(getPodwalks: DefaultGetPodwalks): GetPodwalks

    @Binds
    abstract fun getSeasons(getSeasons: DefaultGetSeasons): GetSeasons

    @Binds
    abstract fun getPodwalkProgress(getPodwalkProgress: DefaultGetAllPodwalkProgress): GetAllPodwalkProgress

    @Binds
    abstract fun getDownloadStates(getDownloadStates: DefaultGetDownloadStates): GetDownloadStates

    @Binds
    abstract fun getPodwalkById(getPodwalkById: DefaultGetPodwalkById): GetPodwalkById

    @Binds
    abstract fun getCheckpoints(getCheckpoints: DefaultGetCheckpoints): GetCheckpoints

    @Binds
    abstract fun getWaypoints(getCheckpoints: DefaultGetWaypoints): GetWaypoints

    @Binds
    abstract fun getDownloadState(getDownloadStates: DefaultGetDownloadState): GetDownloadState

    @Binds
    abstract fun getProgress(getProgress: DefaultGetProgress): GetProgress

    @Binds
    abstract fun deleteProgress(deleteProgress: DefaultDeleteProgress): DeleteProgress

    @Binds
    abstract fun getGuideById(getGuideById: DefaultGetGuideById): GetPodwalkGuideById

    @Binds
    abstract fun getSyncRemoteConfiguration(impl: DefaultSyncRemoteConfiguration): SyncRemoteConfiguration

    @Binds
    abstract fun getSyncPodwalks(impl: DefaultSyncPodwalks): SyncPodwalks

    @Binds
    abstract fun getWalkPlayerState(impl: GetWalkPlayerStateImpl): GetWalkPlayerState

    @Binds
    abstract fun toggleAudioPodwalkPlayback(impl: ToggleAudioPodwalkPlaybackImpl): ToggleAudioPodwalkPlayback

    @Binds
    abstract fun withinCheckpointRadius(impl: DefaultWithinCheckpointRadius): WithinCheckpointRadius
}
