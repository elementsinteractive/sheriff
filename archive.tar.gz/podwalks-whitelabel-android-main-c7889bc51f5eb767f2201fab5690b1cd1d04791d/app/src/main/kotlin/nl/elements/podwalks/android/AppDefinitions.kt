package nl.elements.podwalks.android

object AppDefinitions {
    // Place your constants here
}
