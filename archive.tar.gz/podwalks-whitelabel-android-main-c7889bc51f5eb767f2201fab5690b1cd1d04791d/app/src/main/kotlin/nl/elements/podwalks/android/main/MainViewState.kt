package nl.elements.podwalks.android.main

import com.airbnb.mvrx.MavericksState

data class MainViewState(val isLoading: Boolean = false) : MavericksState
