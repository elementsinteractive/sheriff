package nl.elements.podwalks.android.app.initializers

import android.app.Application
import com.airbnb.mvrx.Mavericks
import nl.elements.podwalks.utils.initializers.AppInitializer
import javax.inject.Inject

class MavericksInitializer @Inject constructor() : AppInitializer {

    override fun init(application: Application) {
        Mavericks.initialize(application.applicationContext)
    }
}
