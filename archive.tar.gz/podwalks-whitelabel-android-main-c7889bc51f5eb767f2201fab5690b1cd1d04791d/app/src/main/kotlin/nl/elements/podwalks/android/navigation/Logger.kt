package nl.elements.podwalks.android.navigation

import androidx.navigation.NavDestination
import nl.elements.mobilization.logging.Logger

fun Logger.logNavigationChange(
    currentDestination: NavDestination?,
    destination: NavDestination,
    arguments: String?,
) {
    i(">> Compose navigation from $currentDestination to $destination with arguments $arguments")
}
