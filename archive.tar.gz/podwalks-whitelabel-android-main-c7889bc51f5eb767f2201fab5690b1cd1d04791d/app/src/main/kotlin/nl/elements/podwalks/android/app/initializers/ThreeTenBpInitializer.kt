package nl.elements.podwalks.android.app.initializers

import android.app.Application
import com.jakewharton.threetenabp.AndroidThreeTen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import nl.elements.podwalks.utils.initializers.AppInitializer
import nl.elements.podwalks.utils.inject.ProcessLifetime
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import org.threeten.bp.zone.ZoneRulesProvider
import javax.inject.Inject

class ThreeTenBpInitializer @Inject constructor(
    private val dispatchers: AppCoroutineDispatchers,
    @ProcessLifetime val processScope: CoroutineScope,
) : AppInitializer {
    override fun init(application: Application) {
        // Init ThreeTenABP
        AndroidThreeTen.init(application)

        // Query the ZoneRulesProvider so that it is loaded on a background coroutine
        processScope.launch(dispatchers.io) {
            ZoneRulesProvider.getAvailableZoneIds()
        }
    }
}
