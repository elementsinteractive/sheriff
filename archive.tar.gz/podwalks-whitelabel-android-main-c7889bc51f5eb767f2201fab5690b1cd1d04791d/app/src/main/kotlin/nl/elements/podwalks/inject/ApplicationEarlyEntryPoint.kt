package nl.elements.podwalks.inject

import dagger.hilt.InstallIn
import dagger.hilt.android.EarlyEntryPoint
import dagger.hilt.components.SingletonComponent
import nl.elements.podwalks.android.app.initializers.AppInitializers

// Use EarlyEntryPoint rather than @Inject for these fields
// since they need to be accessed in onCreate in tests.
@EarlyEntryPoint
@InstallIn(SingletonComponent::class)
internal interface ApplicationEarlyEntryPoint {
    fun initializers(): AppInitializers
}
