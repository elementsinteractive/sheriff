package nl.elements.podwalks.android.service

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Looper
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.android.service.TourGuideConstants.LOCATION_UPDATE_INTERVAL
import nl.elements.podwalks.android.service.TourGuideConstants.LOCATION_UPDATE_MIN_DISTANCE_IN_METERS
import nl.elements.podwalks.data.model.domain.Coordinate
import nl.elements.podwalks.domain.interactors.PostLocationUpdate
import nl.elements.podwalks.extensions.permissionStatus
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TourGuideLocationProvider @Inject constructor(
    @ApplicationContext private val context: Context,
    private val postLocationUpdate: PostLocationUpdate,
    private val dispatchers: AppCoroutineDispatchers,
    private val logger: Logger,
) {
    private var fusedLocationProviderClient: FusedLocationProviderClient? = null
    private var fusedLocationCallback: LocationCallback? = null

    private val fineLocationAccessStatus =
        context.permissionStatus(Manifest.permission.ACCESS_FINE_LOCATION)
            .distinctUntilChanged()
            .map { it == PackageManager.PERMISSION_GRANTED }

    private val locationRequest: LocationRequest = LocationRequest.Builder(
        LOCATION_UPDATE_INTERVAL.inWholeMilliseconds,
    ).setMinUpdateIntervalMillis(LOCATION_UPDATE_INTERVAL.inWholeMilliseconds)
        .setMinUpdateDistanceMeters(LOCATION_UPDATE_MIN_DISTANCE_IN_METERS)
        .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
        .build()

    suspend fun setup() = withContext(dispatchers.main) {
        logger.v("Setting up fused location provider client")

        fineLocationAccessStatus.collectLatest { isGranted ->
            if (isGranted) {
                startLocationTracking()
            } else {
                stopLocationTracking()
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startLocationTracking() {
        logger.v("Starting location tracking")

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context)
        fusedLocationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val lastLocation = result.lastLocation

                if (lastLocation != null) {
                    val coordinate = Coordinate(lastLocation.latitude, lastLocation.longitude)
                    postLocationUpdate(coordinate = coordinate)
                }
            }
        }

        val tmpLocationProviderClient = fusedLocationProviderClient
        val tmpLocationCallback = fusedLocationCallback

        if (tmpLocationProviderClient != null && tmpLocationCallback != null) {
            tmpLocationProviderClient.requestLocationUpdates(
                locationRequest,
                tmpLocationCallback,
                Looper.getMainLooper(),
            )
        }
    }

    fun stopLocationTracking() {
        logger.v("Cleaning up location tracker components.")

        val tmpLocationProviderClient = fusedLocationProviderClient
        val tmpLocationCallback = fusedLocationCallback

        if (tmpLocationProviderClient != null && tmpLocationCallback != null) {
            tmpLocationProviderClient.removeLocationUpdates(tmpLocationCallback)
        }

        fusedLocationProviderClient = null
        fusedLocationCallback = null
    }
}
