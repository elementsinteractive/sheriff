package nl.elements.podwalks.android.app.initializers

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import nl.elements.mobilization.logging.ElementsLogger
import nl.elements.mobilization.reporting.Breadcrumbs
import nl.elements.podwalks.BuildConfig
import nl.elements.podwalks.data.state.AppState
import nl.elements.podwalks.utils.initializers.AppInitializer
import nl.elements.podwalks.utils.inject.ProcessLifetime
import java.util.UUID
import javax.inject.Inject

class TimberInitializer @Inject constructor(
    @ProcessLifetime private val processScope: CoroutineScope,
    private val timberLogger: ElementsLogger,
    private val breadcrumbs: Breadcrumbs,
    private val appState: AppState,
) : AppInitializer {
    override fun init(application: Application) {
        timberLogger.setup(
            debugMode = BuildConfig.DEBUG,
            logsToCrashlytics = true,
        )

        with(timberLogger) {
            with(timberLogger) {
                setCustomKey(KEY_BUILD_TIME, BuildConfig.BUILD_TIME)
                setCustomKey(KEY_GIT_SHA, BuildConfig.GIT_SHA)
            }
        }

        updateUserIdentifier()

        application.registerActivityLifecycleCallbacks(breadcrumbs)
    }

    private fun updateUserIdentifier() {
        processScope.launch {
            val initialIdentifier = appState.userIdentifier.first()
            val userIdentifier = initialIdentifier ?: UUID.randomUUID().toString()

            timberLogger.setUserId(userIdentifier)
            if (initialIdentifier == null) {
                appState.updateUserIdentifier(userIdentifier)
            }
        }
    }

    companion object {
        const val KEY_BUILD_TIME = "Build time"
        const val KEY_GIT_SHA = "Git SHA"
    }
}
