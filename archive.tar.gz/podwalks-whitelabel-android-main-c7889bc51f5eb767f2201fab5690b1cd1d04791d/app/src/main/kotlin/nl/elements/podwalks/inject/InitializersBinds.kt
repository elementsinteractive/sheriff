package nl.elements.podwalks.inject

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import nl.elements.podwalks.android.app.initializers.MavericksInitializer
import nl.elements.podwalks.android.app.initializers.NotificationInitializer
import nl.elements.podwalks.android.app.initializers.ThreeTenBpInitializer
import nl.elements.podwalks.android.app.initializers.TimberInitializer
import nl.elements.podwalks.utils.initializers.AppInitializer

@Module
@InstallIn(SingletonComponent::class)
abstract class InitializersBinds {
    @Binds
    @IntoSet
    abstract fun threeTenAbpInitializer(bind: ThreeTenBpInitializer): AppInitializer

    @Binds
    @IntoSet
    abstract fun timberInitializer(bind: TimberInitializer): AppInitializer

    @Binds
    @IntoSet
    abstract fun mavericksInitializer(bind: MavericksInitializer): AppInitializer

    @Binds
    @IntoSet
    abstract fun notificationInitializer(bind: NotificationInitializer): AppInitializer
}
