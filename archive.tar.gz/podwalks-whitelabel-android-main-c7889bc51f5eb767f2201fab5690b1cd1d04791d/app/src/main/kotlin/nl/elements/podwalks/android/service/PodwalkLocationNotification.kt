package nl.elements.podwalks.android.service

import android.app.Notification
import android.app.Notification.FOREGROUND_SERVICE_IMMEDIATE
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import dagger.Reusable
import dagger.hilt.android.qualifiers.ApplicationContext
import nl.elements.podwalks.domain.Name
import nl.elements.podwalks.shared.resources.R
import nl.elements.podwalks.tourservice.android.notification.NotificationConstants
import javax.inject.Inject

@Reusable
class PodwalkLocationNotification @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    fun getNotification(podwalkName: Name? = null): Notification = NotificationCompat.Builder(
        context,
        NotificationConstants.CHANNEL_ID,
    )
        .setSmallIcon(
            R.drawable.ic_podwalk_notification,
        )
        .setContentTitle(context.getString(R.string.android_tour_location_notification_title))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setOngoing(true)
        .setTimeoutAfter(-1)
        .setAutoCancel(false)
        .apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                foregroundServiceBehavior = FOREGROUND_SERVICE_IMMEDIATE
            }

            if (podwalkName != null) {
                setContentText(
                    context.getString(
                        R.string.android_tour_location_notification_description,
                        podwalkName.value,
                    ),
                )
            }
        }
        .build()

    fun updateNotification(podwalkName: Name? = null) {
        context.notificationManager.notify(
            NotificationConstants.NOTIFICATION_ID,
            getNotification(podwalkName),
        )
    }
}

private val Context.notificationManager: NotificationManager
    get() = getSystemService(
        NotificationManager::class.java,
    )
