@file:Suppress("TooManyFunctions")

package nl.elements.podwalks.android.service

import android.annotation.SuppressLint
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ServiceLifecycleDispatcher
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import nl.elements.podwalks.domain.interactors.touring.collectors.ProcessPlaybackPositionEvents
import nl.elements.podwalks.domain.interactors.touring.collectors.ProcessPlayerEvents
import nl.elements.podwalks.domain.interactors.touring.observers.ObserveTourGuideServiceSignals
import nl.elements.podwalks.domain.interactors.touring.observers.ObserveTourPlaybackEvents
import nl.elements.podwalks.domain.podwalk.GetPodwalkGuideById
import nl.elements.podwalks.domain.podwalk.Id
import nl.elements.podwalks.domain.podwalk.PodwalkGuide
import nl.elements.podwalks.domain.podwalk.TrackAudioPlayer
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject

@UnstableApi
@SuppressLint("MissingPermission")
@AndroidEntryPoint
class TourGuideService : MediaSessionService(), LifecycleOwner {

    @Inject
    internal lateinit var dispatchers: AppCoroutineDispatchers

    @Inject
    internal lateinit var audioPlayer: TrackAudioPlayer

    @Inject
    internal lateinit var processPlayerEvents: ProcessPlayerEvents

    @Inject
    internal lateinit var processPlaybackPositionEvents: ProcessPlaybackPositionEvents

    @Inject
    internal lateinit var observeTourPlaybackEvents: ObserveTourPlaybackEvents

    @Inject
    internal lateinit var observePodwalkGuideById: GetPodwalkGuideById

    @Inject
    internal lateinit var observeServiceSignals: ObserveTourGuideServiceSignals

    private val dispatcher = ServiceLifecycleDispatcher(this)

    override val lifecycle: Lifecycle
        get() = dispatcher.lifecycle

    override fun onCreate() {
        dispatcher.onServicePreSuperOnCreate()
        super.onCreate()

        lifecycleScope.launch(dispatchers.io) {
            launchProcessPlayerEvents(this)
            launchProgressPlaybackPosition(this)

            controlAudioPlayer(this)

            launchTourGuideServiceSignals(this)
        }
    }

    override fun onDestroy() {
        dispatcher.onServicePreSuperOnDestroy()
        teardown()
        clearListener()
        super.onDestroy()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = audioPlayer.mediaSession

    private var podwalkGuideJob: Job? = null

    internal suspend fun setupPodwalkGuide(podwalkId: String) {
        podwalkGuideJob?.cancel()
        podwalkGuideJob = lifecycleScope.launch {
            val guide = observePodwalkGuideById.get(Id(podwalkId)).first()

            setupAudioPlayer(guide)
        }
    }

    private suspend fun setupAudioPlayer(podwalkGuide: PodwalkGuide) {
        withContext(dispatchers.main) {
            // Perform a one-time setup for the TrackAudioPlayer
            audioPlayer.setup(podwalkGuide)
        }
    }

    private fun teardown() {
        teardownAudioPlayer()
    }

    private fun teardownAudioPlayer() {
        audioPlayer.teardown()
    }
}
