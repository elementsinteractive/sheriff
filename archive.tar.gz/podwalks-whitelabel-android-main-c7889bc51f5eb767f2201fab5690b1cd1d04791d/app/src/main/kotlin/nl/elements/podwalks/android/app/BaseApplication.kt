package nl.elements.podwalks.android.app

import android.app.Application
import com.google.firebase.FirebaseApp
import dagger.hilt.android.EarlyEntryPoints
import nl.elements.podwalks.inject.ApplicationEarlyEntryPoint

open class BaseApplication : Application() {

    private val initializers by lazy {
        EarlyEntryPoints
            .get(this, ApplicationEarlyEntryPoint::class.java)
            .initializers()
    }

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        initializers.init(this)
    }
}
