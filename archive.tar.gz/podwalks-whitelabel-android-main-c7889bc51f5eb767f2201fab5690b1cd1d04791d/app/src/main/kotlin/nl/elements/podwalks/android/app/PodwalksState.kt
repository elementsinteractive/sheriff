package nl.elements.podwalks.android.app

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import nl.elements.podwalks.data.state.AppState
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PodwalksState @Inject constructor(
    private val dataStore: DataStore<Preferences>,
    private val dispatchers: AppCoroutineDispatchers,
) : AppState {
    companion object {
        private val KEY_USER_IDENTIFIER = stringPreferencesKey("user_identifier")
        private val KEY_HAS_FINISHED_ONBOARDING = booleanPreferencesKey("has_finished_onboarding")
        private val KEY_REMOTE_MIN_APP_VERSION = longPreferencesKey("remote_min_app_version")
    }

    override var userIdentifier = dataStore.data.map { it[KEY_USER_IDENTIFIER] }

    override val hasFinishedOnboarding: Flow<Boolean> = dataStore.data.map { it[KEY_HAS_FINISHED_ONBOARDING] ?: false }

    override val remoteMinAppVersion: Flow<Long?> =
        dataStore.data.map { it[KEY_REMOTE_MIN_APP_VERSION] }

    override suspend fun updateUserIdentifier(userIdentifier: String) {
        dataStore.edit { preferences ->
            preferences[KEY_USER_IDENTIFIER] = userIdentifier
        }
    }

    override suspend fun updateOnboardingState(hasFinished: Boolean): Unit =
        withContext(dispatchers.io) {
            dataStore.edit { preferences ->
                preferences[KEY_HAS_FINISHED_ONBOARDING] = hasFinished
            }
        }

    override suspend fun updateMinAppVersion(versionCode: Long) {
        withContext(dispatchers.io) {
            dataStore.edit { preferences ->
                preferences[KEY_REMOTE_MIN_APP_VERSION] = versionCode
            }
        }
    }
}
