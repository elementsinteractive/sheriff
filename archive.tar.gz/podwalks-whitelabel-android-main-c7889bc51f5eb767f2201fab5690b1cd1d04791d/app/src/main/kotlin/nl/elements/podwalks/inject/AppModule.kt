package nl.elements.podwalks.inject

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import android.provider.Settings.Secure.ANDROID_ID
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.coroutineScope
import com.google.firebase.crashlytics.FirebaseCrashlytics
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import nl.elements.mobilization.logging.ElementsLogger
import nl.elements.mobilization.reporting.Breadcrumbs
import nl.elements.podwalks.utils.inject.DeviceIdentifier
import nl.elements.podwalks.utils.inject.ProcessLifetime
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Singleton

@Module(includes = [AppModuleBinds::class])
@InstallIn(SingletonComponent::class)
object AppModule {

    @SuppressLint("HardwareIds")
    @Provides
    @DeviceIdentifier
    internal fun hardwareId(@ApplicationContext context: Context): String =
        Settings.Secure.getString(context.contentResolver, ANDROID_ID)

    @Singleton
    @Provides
    fun coroutineDispatchers(): AppCoroutineDispatchers = AppCoroutineDispatchers(
        io = Dispatchers.IO,
        computation = Dispatchers.Default,
        main = Dispatchers.Main,
    )

    @Provides
    @ProcessLifetime
    fun provideLongLifetimeScope(): CoroutineScope =
        ProcessLifecycleOwner.get().lifecycle.coroutineScope

    @Provides
    @Singleton
    fun firebaseCrashlytics(): FirebaseCrashlytics = FirebaseCrashlytics.getInstance()

    @Provides
    @Singleton
    fun elementsLogger(crashlytics: FirebaseCrashlytics): ElementsLogger = ElementsLogger(crashlytics)

    @Provides
    fun breadcrumbs(): Breadcrumbs = Breadcrumbs()
}
