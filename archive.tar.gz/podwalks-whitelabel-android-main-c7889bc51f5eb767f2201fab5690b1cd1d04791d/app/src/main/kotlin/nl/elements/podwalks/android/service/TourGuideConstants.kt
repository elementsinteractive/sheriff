package nl.elements.podwalks.android.service

import kotlin.time.Duration.Companion.seconds

object TourGuideConstants {
    val LOCATION_UPDATE_INTERVAL = 2.5.seconds

    // 0 meters in distance, in other words, don't set a requirement on distance
    // changed for location updates.
    const val LOCATION_UPDATE_MIN_DISTANCE_IN_METERS = 0f
}
