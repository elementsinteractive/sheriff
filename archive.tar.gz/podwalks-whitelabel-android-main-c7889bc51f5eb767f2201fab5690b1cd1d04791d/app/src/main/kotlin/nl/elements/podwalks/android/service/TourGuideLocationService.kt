package nl.elements.podwalks.android.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ServiceLifecycleDispatcher
import androidx.lifecycle.lifecycleScope
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import nl.elements.podwalks.data.bus.TourGuideServiceSignalEventBus
import nl.elements.podwalks.domain.interactors.touring.collectors.UnlockCheckpointsBasedOnLocation
import nl.elements.podwalks.domain.interactors.touring.observers.ObserveTourGuideServiceSignals
import nl.elements.podwalks.domain.podwalk.GetPodwalkGuideById
import nl.elements.podwalks.domain.podwalk.Id
import nl.elements.podwalks.tourservice.android.notification.NotificationConstants
import nl.elements.podwalks.utils.util.AppCoroutineDispatchers
import javax.inject.Inject

@SuppressLint("MissingPermission")
@AndroidEntryPoint
class TourGuideLocationService : Service(), LifecycleOwner {

    @Inject
    internal lateinit var dispatchers: AppCoroutineDispatchers

    @Inject
    internal lateinit var tourGuideLocationProvider: TourGuideLocationProvider

    @Inject
    internal lateinit var unlockCheckpoints: UnlockCheckpointsBasedOnLocation

    @Inject
    internal lateinit var observePodwalkGuideById: GetPodwalkGuideById

    @Inject
    internal lateinit var observeServiceSignals: ObserveTourGuideServiceSignals

    @Inject
    internal lateinit var notificationManager: PodwalkLocationNotification

    private val dispatcher = ServiceLifecycleDispatcher(this)

    override val lifecycle: Lifecycle
        get() = dispatcher.lifecycle

    private var podwalkLocationJob: Job? = null
    private var podwalkGuideJob: Job? = null

    override fun onCreate() {
        dispatcher.onServicePreSuperOnCreate()
        super.onCreate()

        lifecycleScope.launch(dispatchers.io) {
            tourGuideLocationProvider.setup()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        val notificationId = NotificationConstants.NOTIFICATION_ID
        val notification = notificationManager.getNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                notificationId,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST,
            )
        } else {
            startForeground(notificationId, notification)
        }

        podwalkLocationJob?.cancel()
        podwalkLocationJob = lifecycleScope.launch(dispatchers.io) {
            launchObserveServiceSignals()
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android bug: https://issuetracker.google.com/issues/307329994
            START_NOT_STICKY
        } else {
            START_STICKY
        }
    }

    private suspend fun launchObserveServiceSignals() {
        observeServiceSignals().collectLatest {
            when (it) {
                is TourGuideServiceSignalEventBus.Signal.AlreadyRunning -> setupPodwalkLocationTracker(
                    it.tourId,
                )

                is TourGuideServiceSignalEventBus.Signal.Start -> setupPodwalkLocationTracker(
                    it.tourId,
                )

                else -> {}
            }
        }
    }

    private suspend fun setupPodwalkLocationTracker(podwalkId: String) {
        podwalkGuideJob?.cancel()
        podwalkGuideJob = lifecycleScope.launch {
            val guide = observePodwalkGuideById.get(Id(podwalkId)).first()

            notificationManager.updateNotification(guide.podwalk.name)

            // Start unlocking checkpoints based on the user's location information
            unlockCheckpoints(podwalkId)
        }
    }

    override fun onDestroy() {
        dispatcher.onServicePreSuperOnDestroy()
        tourGuideLocationProvider.stopLocationTracking()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
