package nl.elements.podwalks.android.main

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.navigation.NavBackStackEntry
import com.airbnb.mvrx.viewModel
import com.google.common.util.concurrent.MoreExecutors
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import nl.elements.mobilization.logging.Logger
import nl.elements.podwalks.analytics.AnalyticsEvent
import nl.elements.podwalks.analytics.AnalyticsTracker
import nl.elements.podwalks.android.navigation.logNavigationChange
import nl.elements.podwalks.android.service.TourGuideLocationService
import nl.elements.podwalks.android.service.TourGuideService
import nl.elements.podwalks.android.ui.PodwalksApp
import nl.elements.podwalks.data.bus.TourGuideServiceSignalEventBus.Signal
import nl.elements.podwalks.domain.interactors.touring.observers.ObserveTourGuideServiceSignals
import nl.elements.podwalks.utils.util.PodwalksDateFormatter
import javax.inject.Inject

@UnstableApi
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    internal lateinit var dateFormatter: PodwalksDateFormatter

    private val viewModel: MainViewModel by viewModel()

    @Inject
    internal lateinit var observeServiceSignals: ObserveTourGuideServiceSignals

    @Inject
    internal lateinit var logger: Logger

    @Inject
    internal lateinit var analyticsTracker: AnalyticsTracker

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()

        super.onCreate(savedInstanceState)

        setContent {
            PodwalksApp(
                dateFormatter = dateFormatter,
                onDestinationChangedListener = { controller, destination, arguments ->
                    logger.logNavigationChange(
                        controller.currentDestination,
                        destination,
                        arguments?.toString(),
                    )
                },
                onDestinationChanged = ::trackScreen,
            )
        }

        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                collectServiceSignals()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        controller?.release()
    }

    private suspend fun collectServiceSignals() =
        observeServiceSignals().collect { operateTourService(it) }

    private var controller: MediaController? = null

    private fun operateTourService(update: Signal) {
        when (update) {
            is Signal.Start -> {
                startTourGuide()

                initializeMediaSession()
            }

            is Signal.AlreadyRunning -> {
                logger.i("Already running TourGuideService")

                cleanupMediaSession()
                initializeMediaSession()
            }

            Signal.Stop -> {
                stopTourGuide()

                cleanupMediaSession()
            }
        }
    }

    private fun startTourGuide() {
        logger.i("Starting TourGuideService")
        Intent(this@MainActivity, TourGuideService::class.java)
            .also(::startService)

        logger.i("Starting TourGuideLocationService")
        Intent(this@MainActivity, TourGuideLocationService::class.java)
            .also(::startForegroundService)
    }

    private fun stopTourGuide() {
        logger.i("Stopping TourGuideService")
        Intent(this@MainActivity, TourGuideService::class.java)
            .also(::stopService)

        logger.i("Stopping TourGuideLocationService")
        Intent(this@MainActivity, TourGuideLocationService::class.java)
            .also(::stopService)
    }

    private fun initializeMediaSession() {
        val sessionToken =
            SessionToken(this, ComponentName(this, TourGuideService::class.java))

        val controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()

        controllerFuture.addListener(
            { controller = controllerFuture.get() },
            MoreExecutors.directExecutor(),
        )
    }

    private fun cleanupMediaSession() {
        controller?.stop()
        controller?.release()
        controller = null
    }

    private fun trackScreen(entry: NavBackStackEntry) {
        logger.d("$entry")
        val routeName = getRouteName(entry)

        if (routeName !== null) {
            logger.d("Tracking screen with routeName: $routeName")

            analyticsTracker.track(AnalyticsEvent.ScreenView(routeName))
        }
    }

    private fun getRouteName(entry: NavBackStackEntry): String? =
        entry.arguments?.getString("route")
}
