package nl.elements.podwalks.android.app

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import nl.elements.podwalks.BuildConfig
import nl.elements.podwalks.analytics.AnalyticsConfiguration
import nl.elements.podwalks.analytics.AnalyticsEnvironment
import nl.elements.podwalks.data.config.AppConfiguration
import nl.elements.podwalks.data.config.BuildType
import nl.elements.podwalks.shared.resources.R
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PodwalksConfiguration @Inject constructor() : AppConfiguration {
    override val applicationId: String = BuildConfig.APPLICATION_ID
    override val buildType: BuildType = BuildConfig.BUILD_TYPE.asBuildType()
    override val versionCode: Int = BuildConfig.VERSION_CODE
    override val podwalkAPIHost: String = BuildConfig.PODWALK_API_HOST
    override val podwalkAPIKey: String = BuildConfig.PODWALK_API_KEY
    override val versionName: String = BuildConfig.VERSION_NAME
}

@Singleton
class PodwalksAnalyticsConfiguration @Inject constructor(
    @ApplicationContext val context: Context,
) : AnalyticsConfiguration {
    override val environment: AnalyticsEnvironment = BuildConfig.BUILD_TYPE.asAnalyticsEnvironment()
    override val locale: String
        get() = context.resources.getString(R.string.locale)
}

private fun String.asBuildType(): BuildType =
    when (this) {
        "debug" -> BuildType.DEBUG
        "staging" -> BuildType.STAGING
        "release" -> BuildType.RELEASE
        else -> throw IllegalArgumentException("Unknown build type found")
    }

private fun String.asAnalyticsEnvironment(): AnalyticsEnvironment =
    when (this) {
        "debug" -> AnalyticsEnvironment.DEBUG
        "staging" -> AnalyticsEnvironment.STAGING
        "release" -> AnalyticsEnvironment.RELEASE
        else -> throw IllegalArgumentException("Unknown build type found")
    }
