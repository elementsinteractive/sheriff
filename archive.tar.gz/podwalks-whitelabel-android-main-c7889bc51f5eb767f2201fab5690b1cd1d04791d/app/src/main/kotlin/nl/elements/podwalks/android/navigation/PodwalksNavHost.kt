package nl.elements.podwalks.android.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.navOptions
import nl.elements.podwalks.details.navigation.WalkDetails
import nl.elements.podwalks.details.navigation.detailsScreen
import nl.elements.podwalks.details.navigation.navigateToDetails
import nl.elements.podwalks.info.navigation.BackScreen
import nl.elements.podwalks.info.navigation.infoScreen
import nl.elements.podwalks.info.navigation.navigateToCallToAction
import nl.elements.podwalks.info.navigation.navigateToInfo
import nl.elements.podwalks.list.navigation.PodwalksList
import nl.elements.podwalks.list.navigation.navigateToPodwalks
import nl.elements.podwalks.list.navigation.podwalks
import nl.elements.podwalks.onboarding.navigation.Onboarding
import nl.elements.podwalks.onboarding.navigation.onboardingScreen
import nl.elements.podwalks.share.navigation.navigateToWalkShare
import nl.elements.podwalks.share.navigation.walkShareScreen
import nl.elements.podwalks.shared.resources.R
import nl.elements.podwalks.splash.navigation.Splash
import nl.elements.podwalks.walk.navigation.Walk
import nl.elements.podwalks.walk.navigation.navigateToWalk
import nl.elements.podwalks.walk.navigation.walkScreen

@Composable
@Suppress("LongMethod")
fun PodwalksNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
    startDestination: Any = Splash,
) {
    val context = LocalContext.current

    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier,
    ) {
        onboardingScreen(
            onFinishedOnboarding = {
                navController.navigateToPodwalks(
                    navOptions = navOptions {
                        popUpTo<Onboarding> {
                            inclusive = true
                        }
                    },
                )
            },
        )

        podwalks(
            onAboutClick = {
                navController.navigateToInfo(
                    fromScreen = BackScreen.LIST,
                    podwalkId = null,
                )
            },
            onWalkClick = { walk ->
                navController.navigateToDetails(walk.id)
            },
        )

        detailsScreen(
            onBackClick = {
                navController.popBackStack(PodwalksList, false, true)
            },
            onAboutClick = { podwalkId ->
                navController.navigateToInfo(
                    fromScreen = BackScreen.DETAILS,
                    podwalkId = podwalkId,
                )
            },
            onPodwalkStartClick = { podwalkId ->
                navController.navigateToWalk(podwalkId)
            },
        )

        infoScreen(
            callToActionUrl = context.getString(R.string.info_app_call_to_action_url),
            onCloseClicked = { fromScreen, podwalkId ->
                when (fromScreen) {
                    BackScreen.DETAILS -> if (podwalkId != null) {
                        navController.popBackStack(
                            route = WalkDetails(podwalkId = podwalkId),
                            inclusive = false,
                        )
                    }
                    BackScreen.WALK -> if (podwalkId != null) {
                        navController.popBackStack(
                            route = Walk(podwalkId = podwalkId),
                            inclusive = false,
                        )
                    }
                    else -> {
                        navController.popBackStack(
                            route = PodwalksList,
                            inclusive = false,
                        )
                    }
                }
            },
            onOpenCallToAction = navController::navigateToCallToAction,
        )

        walkScreen(
            onBackClick = { podwalkId ->
                navController.popBackStack(WalkDetails(podwalkId), false, true)
            },
            onAboutClick = { podwalkId ->
                navController.navigateToInfo(
                    fromScreen = BackScreen.WALK,
                    podwalkId = podwalkId,
                )
            },
            onOpenShare = { podwalkId ->
                navController.navigateToWalkShare(podwalkId)
            },
            onOpenAr = { identifier ->
                navController.navigateToAr(identifier)
            },
        )

        walkShareScreen(
            onCloseClick = { podwalkId ->
                navController.navigateToDetails(
                    podwalkId,
                    navOptions = navOptions {
                        popUpTo<WalkDetails> {
                        }
                    },
                )
            },
        )

        flavorScreens(navController)
    }
}
