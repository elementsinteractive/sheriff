package nl.elements.podwalks.inject

import com.airbnb.mvrx.hilt.AssistedViewModelFactory
import com.airbnb.mvrx.hilt.MavericksViewModelComponent
import com.airbnb.mvrx.hilt.ViewModelKey
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.multibindings.IntoMap
import nl.elements.podwalks.android.main.MainViewModel
import nl.elements.podwalks.details.DetailsViewModel
import nl.elements.podwalks.info.InfoViewModel
import nl.elements.podwalks.list.PodwalksListViewModel
import nl.elements.podwalks.playlist.compose.PlaylistViewModel
import nl.elements.podwalks.share.WalkShareViewModel
import nl.elements.podwalks.walk.WalkViewModel

@Module
@InstallIn(MavericksViewModelComponent::class)
interface ViewModelsModule {

    @Binds
    @IntoMap
    @ViewModelKey(PodwalksListViewModel::class)
    fun podwalksListViewModel(factory: PodwalksListViewModel.Factory): AssistedViewModelFactory<*, *>

    @Binds
    @IntoMap
    @ViewModelKey(PlaylistViewModel::class)
    fun playlistViewModel(factory: PlaylistViewModel.Factory): AssistedViewModelFactory<*, *>

    @Binds
    @IntoMap
    @ViewModelKey(MainViewModel::class)
    fun mainViewModelFactory(factory: MainViewModel.Factory): AssistedViewModelFactory<*, *>

    @Binds
    @IntoMap
    @ViewModelKey(InfoViewModel::class)
    fun infoViewModelFactory(factory: InfoViewModel.Factory): AssistedViewModelFactory<*, *>

    @Binds
    @IntoMap
    @ViewModelKey(DetailsViewModel::class)
    fun detailsViewModel(factory: DetailsViewModel.Factory): AssistedViewModelFactory<*, *>

    @Binds
    @IntoMap
    @ViewModelKey(WalkViewModel::class)
    fun walkViewModel(factory: WalkViewModel.Factory): AssistedViewModelFactory<*, *>

    @Binds
    @IntoMap
    @ViewModelKey(WalkShareViewModel::class)
    fun walkShareViewModel(factory: WalkShareViewModel.Factory): AssistedViewModelFactory<*, *>
}
