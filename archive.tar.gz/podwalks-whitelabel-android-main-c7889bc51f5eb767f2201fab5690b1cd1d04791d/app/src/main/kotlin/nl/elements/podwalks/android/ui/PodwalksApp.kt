package nl.elements.podwalks.android.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import nl.elements.podwalks.android.navigation.PodwalksNavHost
import nl.elements.podwalks.presentation.compose.LocalPodwalksDateFormatter
import nl.elements.podwalks.presentation.compose.theme.AppTheme
import nl.elements.podwalks.utils.util.PodwalksDateFormatter

@Composable
fun PodwalksApp(
    dateFormatter: PodwalksDateFormatter,
    onDestinationChangedListener: NavController.OnDestinationChangedListener,
    onDestinationChanged: (entry: NavBackStackEntry) -> Unit,
    navController: NavHostController = rememberNavController(),
) {
    val navigationState by navController.currentBackStackEntryAsState()

    LaunchedEffect(onDestinationChangedListener) {
        navController.addOnDestinationChangedListener(onDestinationChangedListener)
    }

    LaunchedEffect(navigationState?.destination) {
        val state = navigationState
        if (state !== null) {
            onDestinationChanged(state)
        }
    }

    AppTheme {
        CompositionLocalProvider(
            LocalPodwalksDateFormatter provides dateFormatter,
        ) {
            Scaffold { padding ->
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .windowInsetsPadding(
                            WindowInsets.safeDrawing.only(
                                WindowInsetsSides.Horizontal,
                            ),
                        ),
                ) {
                    PodwalksNavHost(
                        navController = navController,
                        modifier = Modifier
                            .fillMaxSize(),
                    )
                }
            }
        }
    }
}
