package nl.elements.podwalks

import android.os.StrictMode
import nl.elements.podwalks.android.app.BaseApplication

open class StagingApplication : BaseApplication() {
    override fun onCreate() {
        configureStrictMode()

        super.onCreate()
    }

    private fun configureStrictMode() {
        StrictMode.setThreadPolicy(
            StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build(),
        )
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().detectAll().penaltyLog().build())
    }
}
