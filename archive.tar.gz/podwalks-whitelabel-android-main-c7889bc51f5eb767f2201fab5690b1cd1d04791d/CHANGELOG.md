# Changelog
All notable changes to this project will be documented in this file.
 
The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

Types of changes:
- *Added* for new features
- *Changed* for changes in existing functionality
- *Deprecated* for soon-to-be removed features.
- *Removed* for now removed features.
- *Fixed* for any bug fixes.
- *Security* in case of vulnerabilities.
 
## [Unreleased]

## Added

- [CI] Danger set-up with @makerstreet/danger package
- New gradle module :shared:test for shared test code

## Changed

- Updated AGP to 7.2.0
- buildSrc plugins to use proper gradle APIs
- org.gradle.jvmargs to include `UseParallelGC`
- Bumps dagger to 2.42 due to https://github.com/google/dagger/issues/3201
- Migrates coroutine tests to use the new API with `runTest`

## 3.0.0 - 03-09-2021

## Added
- Jetpack Compose set-up
- Documentation set-up with docusaurus
- Showkase set-up
- Breadcrumbs logging
- Libraries:
  -- Ktor
  -- Kotlinx datetime + serialization


### Changed
- Complete architecture
- Moved dependencies list to `gradle/libs.versions.toml`

### Removed
- Retrofit
- Gradle modules `data-android` & `base-android`

## 2.0.0

### Added
- App initializers based on ContentProvider "hack"
- Pre push hook to detect no change to CHANGELOG.md
- Converted all gradle files to kts
- Unified fastlane
- Dagger Hilt
- Separate gradle modules for common-* and features-*
- Pages feature
- Mobilization dependencies

### Changed
- Updates dependency versions
- gitlab.yml format to support extends
- App icon
- Simplify gitlab yml
- dexcount only runs on CI
- Refactor Android SDK versions to root ext
- Target and compile API to SDK 30
- Updated dependencies
- Dagger to 2.31
- gitlab.yml to use `rules`

### Removed

- Shake feature from Staging Application

## 1.2.5

### Added
- Instructions for app signing with GPG

## 1.2.4

### Added
- Androidx navigation set-up

### Removed
- Paperparcel

## 1.2.3

### Changed
- Updated README with types of changes and Security considerations

## 1.2.2 - 2019-03-15

### Changed
- Fastlane template dependency

## 1.2.1 - 2019-02-12

### Changed
- Refactor buildSrc into a single file
- All dependencies are now read from buildSrc

### Removed
- Cache untracked flag

## 1.2.0 - 2019-01-28

###
- Make BaseViewModel abstract
- Event class for one time use with LiveData
- Result class with Success and Error
- Adds initial UseCase class

## [1.1.0] - 2018-09-17

### Changed
- Updated dependencies version

### Removed
- Realm
 
## [1.0.0] - 2018-07-016
### Added
- Initial changelog
