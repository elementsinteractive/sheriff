plugins {
    id("podwalks.android.library")
    id("podwalks.android.library.flavors")
}

android {
    namespace = "nl.elements.podwalks.benchmark"

    defaultConfig {
        testInstrumentationRunner = "androidx.benchmark.junit4.AndroidBenchmarkRunner"
    }
}

dependencies {
    androidTestImplementation(project(":data"))
    androidTestImplementation(project(":domain"))
    androidTestImplementation(project(":shared:utils"))
    androidTestImplementation(project(":shared:resources"))

    androidTestImplementation(libs.bundles.androidTestDependencies)

    androidTestImplementation(libs.androidx.benchmark)
}
